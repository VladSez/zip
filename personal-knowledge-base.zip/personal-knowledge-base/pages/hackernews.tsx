import { HackerNewsList } from "../features/hackerNews";

export default function HackerNews() {
  return <HackerNewsList />;
}
