import { google } from "googleapis";
import { NextApiRequest, NextApiResponse } from "next";
import { getSession } from "next-auth/react";
import { googleOAuth2 } from "../../../lib/googleOAuth2";

const WATCH_LATER_PLAYLIST_ID =
  "PLnRDbstoyFhUB-vmabKc2y_JERLMpf7eb";

const handler = async (
  req: NextApiRequest,
  res: NextApiResponse<any>, // TODO: fix type
) => {
  try {
    // https://vercel.com/docs/concepts/projects/environment-variables#system-environment-variables
    if (process.env.VERCEL_ENV === "preview") {
      return res.status(401).json({
        statusCode: 401,
        message:
          "Currently it's not possible to use Google oAuth2 on preview deploys. Please, track: https://github.com/nextauthjs/docs/issues/19 and https://github.com/nextauthjs/next-auth/issues/497",
      });
    }

    const session = await getSession({ req });
    const nextPageCursor = req.query?.cursor as string;

    if (!session) {
      return res.status(401).json({
        statusCode: 401,
        message: "Not authenticated",
      });
    }

    let auth = googleOAuth2;

    const accessToken = session?.accessToken;
    const refreshToken = session?.refreshToken;

    auth.setCredentials({
      access_token: accessToken as string,
      refresh_token: refreshToken as string,
    });

    try {
      const youtubeAuth = google.youtube({
        auth,
        version: "v3",
      });

      const watchLaterPlaylist =
        await youtubeAuth.playlistItems.list({
          part: ["snippet,contentDetails"],
          maxResults: 8,
          playlistId: WATCH_LATER_PLAYLIST_ID,
          pageToken: nextPageCursor,
        });

      const ids =
        (watchLaterPlaylist?.data?.items?.map(
          (item) => item?.contentDetails?.videoId,
        ) as string[]) || [];

      // get views from ids

      const videos = await youtubeAuth.videos.list({
        part: ["snippet,contentDetails,statistics"],
        id: ids,
      });

      const videosList = {
        ...videos?.data,
        nextPageToken:
          watchLaterPlaylist.data.nextPageToken,
      };

      return res.status(200).json({
        watchLaterPlaylist: videosList,
      });
    } catch (err) {
      console.error(err);
      res
        .status(500)
        .json({ statusCode: 500, message: err });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ statusCode: 500, message: err });
  }
};

export default handler;
