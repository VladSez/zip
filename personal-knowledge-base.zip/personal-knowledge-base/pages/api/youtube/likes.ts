import { GaxiosResponse } from "gaxios";
import { NextApiRequest, NextApiResponse } from "next";
import { getSession } from "next-auth/react";
import { google, youtube_v3 } from "googleapis";
import { googleOAuth2 } from "../../../lib/googleOAuth2";

export type youtubeLikedVideosType =
  GaxiosResponse<youtube_v3.Schema$VideoListResponse>["data"];

const handler = async (
  req: NextApiRequest,
  res: NextApiResponse<any>, // TODO: fix type
) => {
  try {
    // https://vercel.com/docs/concepts/projects/environment-variables#system-environment-variables
    if (process.env.VERCEL_ENV === "preview") {
      return res.status(401).json({
        statusCode: 401,
        message:
          "Currently it's not possible to use Google oAuth2 on preview deploys. Please, track: https://github.com/nextauthjs/docs/issues/19 and https://github.com/nextauthjs/next-auth/issues/497",
      });
    }

    const session = await getSession({ req });
    const nextPageCursor = req.query?.cursor as string;

    if (!session) {
      return res.status(401).json({
        statusCode: 401,
        message: "Not authenticated",
      });
    }

    let auth = googleOAuth2;

    const accessToken = session?.accessToken;
    const refreshToken = session?.refreshToken;

    auth.setCredentials({
      access_token: accessToken as string,
      refresh_token: refreshToken as string,
    });

    try {
      const youtubeAuth = google.youtube({
        auth,
        version: "v3",
      });

      const youtubeLikedVideos =
        await youtubeAuth.videos.list({
          part: ["snippet,contentDetails,statistics"],
          myRating: "like",
          maxResults: 8,
          pageToken: nextPageCursor,
        });

      return res.status(200).json({
        youtube: youtubeLikedVideos?.data,
      });
    } catch (err) {
      console.error(err);
      res
        .status(500)
        .json({ statusCode: 500, message: err });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ statusCode: 500, message: err });
  }
};

export default handler;
