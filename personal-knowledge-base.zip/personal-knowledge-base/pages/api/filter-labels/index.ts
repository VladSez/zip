import { NextApiRequest, NextApiResponse } from "next";
import { supabase } from "../../../lib/initSupabase";

const handler = async (
  _req: NextApiRequest,
  res: NextApiResponse<any>, // TODO: fix type, if possible
) => {
  try {
    const { method } = _req;

    if (method === "GET") {
      const from = Number(_req.query.from) | 0;
      const to = Number(_req.query.to);

      const { data: labels = [] } = await supabase
        .from("labels")
        .select("*")
        .or(String(_req.query?.id));

      if (!labels) {
        return res
          .status(200)
          .json({ items: null, canFetchNext: false });
      }

      const items = labels?.map((x) => x?.ids).flat();

      // TODO: below .filter is needed to remove duplicates
      // probably, the reason is poor db scheme design :)
      // investigate this
      // need to redesign db scheme
      // and probably use
      // many-to-many relations(https://github.com/VladSez/personal-knowledge-base/issues/12)*
      const filteredItems = items?.filter(
        (v, i, arr) =>
          arr.findIndex((t) => t?.id === v?.id) === i,
      );

      // reversed will return the most recent labelled items
      const reversedItems =
        filteredItems?.length > 0
          ? [...filteredItems]?.reverse()
          : [];

      const slicedItems = reversedItems?.slice(from, to);

      const canFetchNext = reversedItems
        ? reversedItems?.slice(from + 10, to + 10).length >
          0
        : false;

      const totalCountOfItems = reversedItems?.length;

      return res.status(200).json({
        items: slicedItems,
        canFetchNext,
        totalCountOfItems,
      });
    }

    return res
      .status(405)
      .end(`Method ${method} Not Allowed`);
  } catch (err) {
    if (err instanceof Error) {
      console.error(err);
      res
        .status(500)
        .json({ statusCode: 500, message: err.message });
    }
  }
};

export default handler;
