import { NextApiRequest, NextApiResponse } from "next";
import { TransformedTweetNullable } from "../../../features/twitter/types";
import { fetchTwitterBookmarks } from "../../../lib/twitter/fetchTwitterBookmarks";

type ResponseData = {
  data?: TransformedTweetNullable[];
  cursor?: string | null;
  statusCode?: number;
  message?: unknown;
};

const handler = async (
  _req: NextApiRequest,
  res: NextApiResponse<ResponseData>,
) => {
  try {
    const { data, cursor } = await fetchTwitterBookmarks({
      cursor: _req.query?.query as string,
    });

    res.status(200).json({
      data,
      cursor,
    });
  } catch (err) {
    if (err instanceof Error) {
      console.error({ err });
      res
        .status(500)
        .json({ statusCode: 500, message: err.message });
    }
  }
};

export default handler;
