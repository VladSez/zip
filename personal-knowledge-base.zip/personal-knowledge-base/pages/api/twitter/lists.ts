import axios from "axios";
import { NextApiRequest, NextApiResponse } from "next";
import { TransformedTweetNullable } from "../../../features/twitter/types";
import { getConfig } from "../../../lib/twitter/helpers";

type ResponseData = {
  data?: TransformedTweetNullable[];
  cursor?: string | null;
  statusCode?: number;
  message?: unknown;
};

const VARS = {
  count: 100,
  withSuperFollowsUserFields: true,
  withDownvotePerspective: false,
  withReactionsMetadata: false,
  withReactionsPerspective: false,
  withSuperFollowsTweetFields: true,
  __fs_responsive_web_like_by_author_enabled: false,
  __fs_dont_mention_me_view_api_enabled: true,
  __fs_interactive_text_enabled: true,
  __fs_responsive_web_uc_gql_enabled: false,
  __fs_responsive_web_edit_tweet_api_enabled: false,
};

// WIP
const handler = async (
  _req: NextApiRequest,
  res: NextApiResponse<ResponseData>,
) => {
  try {
    // TODO: use `fetchTwitterListById`
    const response = await axios(
      getConfig({
        url: "https://mobile.twitter.com/i/api/graphql/xadQAuth1MXWCgCFx7qd0g/ListsManagementPageTimeline?variables=",
        variables: VARS,
        cursor: _req.query?.query as string,
      }),
    );

    const data: any = response.data;

    const listIds =
      data.data.viewer.list_management_timeline.timeline.instructions[1].entries[0].content.items.map(
        (x: any) =>
          x.entryId.replace("pinnedListModule-", ""),
      );

    res.status(200).json({ data: listIds });
  } catch (err) {
    if (err instanceof Error) {
      console.error({ err });
      res
        .status(500)
        .json({ statusCode: 500, message: err.message });
    }
  }
};

export default handler;
