import {
  NextApiHandler,
  NextApiRequest,
  NextApiResponse,
} from "next";
import { array, object, string } from "yup";
import {
  ObjectShape,
  OptionalObjectSchema,
} from "yup/lib/object";
import { supabase } from "../../../lib/initSupabase";
import { labelsSchema } from "../../../schemas/manage-labels";

const handler = async (
  _req: NextApiRequest,
  res: NextApiResponse,
) => {
  try {
    const { method } = _req;

    // TODO: type supabase https://supabase.io/docs/reference/javascript/generating-types

    if (method === "GET") {
      const { data: labels } = await supabase
        .from("labels")
        .select("*")
        .order("id");

      return res.status(200).json({ labels });
    }

    if (method === "POST") {
      const { data, error } = await supabase
        .from("labels")
        .insert([
          {
            label: _req.body?.label,
            description: _req.body?.description,
            color: _req.body?.color,
            ids: [],
            type: _req.body?.type,
          },
        ]);

      console.error(error);

      return res.status(200).json({ data });
    }

    if (method === "PUT") {
      const { data, error } = await supabase
        .from("labels")
        .update({
          label: _req.body?.label,
          description: _req.body?.description,
          color: _req.body?.color,
          updated_at: new Date(),
          ids: _req.body?.ids ? _req.body?.ids : [],
          type: _req.body?.type,
        })
        .eq("id", _req.body?.id);

      console.error(error);

      return res.status(200).json({ data });
    }

    if (method === "DELETE") {
      const { data, error } = await supabase
        .from("labels")
        .delete()
        .eq("id", _req.body?.id);

      console.error(error);

      return res.status(200).json({ data });
    }

    return res
      .status(405)
      .end(`Method ${method} Not Allowed`);
  } catch (err) {
    if (err instanceof Error) {
      res
        .status(500)
        .json({ statusCode: 500, message: err.message });
    }
  }
};

// TODO: extract to separate file
export function validate(
  schema: OptionalObjectSchema<ObjectShape>,
  handler: NextApiHandler,
) {
  return async (
    _req: NextApiRequest,
    res: NextApiResponse,
  ) => {
    const METHODS_TO_BE_VALIDATED = [
      "POST",
      "PUT",
      "DELETE",
    ];

    if (
      METHODS_TO_BE_VALIDATED.includes(
        _req.method as string,
      )
    ) {
      try {
        let newSchema: OptionalObjectSchema<ObjectShape>;

        if (_req.method === "POST") {
          newSchema = schema;
        } else if (_req.method === "PUT") {
          // TODO: check this scheme
          newSchema = object({
            id: string().required(),
            ids: array(object()).optional(),
            label: string().optional(),
            description: string().nullable().optional(),
            color: string().optional(),
            type: string().required(),
          });
        } else {
          // DELETE mehtod
          newSchema = object({
            id: string().required(),
          });
        }

        _req.body = await newSchema.validate(_req.body, {
          abortEarly: false,
          // stripUnknown: true,
        });
      } catch (error) {
        return res.status(400).json(error);
      }
    }
    await handler(_req, res);
  };
}

export default validate(labelsSchema, handler as any);
