import { GithubTabs } from "../features/github";
import { FeedContainer } from "../components/FeedContainer";

export default function Github() {
  return (
    <FeedContainer>
      <GithubTabs />
    </FeedContainer>
  );
}
