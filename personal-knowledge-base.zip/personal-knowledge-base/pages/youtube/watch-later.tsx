import clsx from "clsx";
import { GaxiosResponse } from "gaxios";
import { youtube_v3 } from "googleapis";

import { useEffect } from "react";
import { useInView } from "react-intersection-observer";

import { Button } from "../../components/Button";
import { LoaderWithText } from "../../components/Loader";

import { Auth } from "../../features/youtube/components/Auth";
import { ColToggleGroup } from "../../features/youtube/components/ColToggleGroup";
import { YouTubeEmbed } from "../../features/youtube/components/YouTubeEmbed";
import { useColumns } from "../../features/youtube/hooks/useColumns";
import { useYoutubeWatchLaterVideos } from "../../features/youtube/hooks/useYouTubeWatchLaterVideos";
import { useBoolean } from "../../hooks/useBoolean";

type WatchLaterPlaylist =
  GaxiosResponse<youtube_v3.Schema$VideoListResponse>["data"];

export default function YoutubeWatchLater() {
  const {
    value: isFetchingMoreTweets,
    setValue: setFetchingMoreTweets,
  } = useBoolean();

  const { data, size, setSize, error } =
    useYoutubeWatchLaterVideos();

  const { column, setColumn } = useColumns();

  const { ref, inView } = useInView({
    // adjust if needed
    rootMargin: "500px",
  });

  useEffect(() => {
    if (inView) {
      setSize((size) => size + 1);
      setFetchingMoreTweets(true);
    }
  }, [inView, setFetchingMoreTweets, setSize]);

  // not authenticated
  if (error) {
    return (
      <>
        <Auth hasError />
        <pre className="mt-10 h-screen whitespace-pre-wrap">
          {JSON.stringify({ error }, null, 2)}
        </pre>
      </>
    );
  }

  if (!data) {
    return (
      <div className="mt-24 flex h-[101vh] flex-col justify-start">
        <LoaderWithText />
      </div>
    );
  }

  const watchLaterVideos: WatchLaterPlaylist["items"] = data
    ? ([] as any).concat(
        ...data.map((x) => x?.watchLaterPlaylist?.items),
      )
    : [];

  return (
    <>
      <Auth />

      <h1 className="mx-2 mt-5 text-lg font-semibold sm:mx-0">
        Watch later videos:
      </h1>
      <div className="mx-2 hidden justify-end sm:mx-0 sm:flex">
        <ColToggleGroup
          column={column}
          setColumn={setColumn}
        />
      </div>

      <div
        className={clsx("grid grid-cols-1", {
          "gap-3 sm:grid-cols-2": column === "two",
        })}
      >
        {watchLaterVideos?.map((video) => {
          return (
            <YouTubeEmbed
              key={video?.id}
              channelTitle={video?.snippet?.channelTitle}
              channelId={video?.snippet?.channelId}
              id={video?.id}
              title={video?.snippet?.title}
              publishedAt={video?.snippet?.publishedAt}
              viewCount={video?.statistics?.viewCount}
            />
          );
        })}
      </div>
      <div className="my-4 flex flex-col items-center justify-center">
        {isFetchingMoreTweets ? <LoaderWithText /> : null}
        {data && !error ? (
          <Button
            onClick={() => {
              // fetch next page
              setSize(size + 1);
              setFetchingMoreTweets(true);
            }}
          >
            <span ref={ref}>Load more</span>
          </Button>
        ) : null}
      </div>
    </>
  );
}
