import clsx from "clsx";

import { ColToggleGroup } from "../../features/youtube/components/ColToggleGroup";
import { YouTubeEmbed } from "../../features/youtube/components/YouTubeEmbed";
import { useColumns } from "../../features/youtube/hooks/useColumns";

export default function YoutubePlaylists() {
  const { column, setColumn } = useColumns();

  return (
    <>
      <h1 className="mx-2 mt-5 text-lg font-semibold sm:mx-0">
        Playlists:
      </h1>
      <div className="mx-2 hidden justify-end sm:mx-0 sm:flex">
        <ColToggleGroup
          column={column}
          setColumn={setColumn}
        />
      </div>
      <div
        className={clsx("grid grid-cols-1", {
          "gap-3 sm:grid-cols-2": column === "two",
        })}
      >
        {PLAYLISTS.map((item) => {
          return (
            <YouTubeEmbed
              key={item.videoId}
              id={item.videoId}
              isPlaylist
              playlistCoverId={item.coverId}
              title={item.channelTitle}
            />
          );
        })}
      </div>
    </>
  );
}

interface PlaylistType {
  videoId: string;
  coverId: string;
  channelTitle: string;
}

const PLAYLISTS: PlaylistType[] = [
  {
    videoId: "PL1y1iaEtjSYiiSGVlL1cHsXN_kvJOOhu-",
    coverId: "5JJrJGZ_LjM",
    channelTitle: "CS 253 Web Security",
  },
  {
    videoId: "PLkQkbY7JNJuBoTemzQfjym0sqbOHt5fnV",
    coverId: "mhUQe4BKZXs",
    channelTitle: "System Design",
  },

  {
    videoId: "PLM88opVjBuU7xSRoHhs3hZBz3JmHHBMMN",
    coverId: "S-rF5rkhaJ0",
    channelTitle: "Make an OS with ReactJS & Next.js",
  },
  {
    videoId: "PLQ-uHSnFig5PjfCy7mE77XMGhgky9HV3o",
    coverId: "jVJ9ovLxrKM",
    channelTitle: "Startup School Winter 2020",
  },
  {
    videoId: "PLQ-uHSnFig5NVnJ_cLWM7dLuMQRDeekoX",
    coverId: "rzVbFeiEbds",
    channelTitle: "Startup School 2018",
  },
  {
    videoId: "PLEs8EuAPI73Bj78n7-BIW3s1we0r15yJl",
    coverId: "yvSKcDrNYgw",
    channelTitle: "Школа менеджеров Яндекса. 2017",
  },
  {
    videoId: "PLEs8EuAPI73Bs0R9bcWYtPJ94aWVrPYqd",
    coverId: "BpXVJByOh8g",
    channelTitle: "Управление продуктом. Yandex 2020",
  },
  {
    videoId: "PLnsTB8Q5VgnVzh1S-VMCXiuwJglk5AV--",
    coverId: "s3RrVmv5WwA",
    channelTitle:
      "Technology-enabled Blitzscaling. Greylock",
  },
  {
    videoId: "PLZHQObOWTQDPD3MizzM2xVFitgF8hE_ab",
    coverId: "fNk_zzaMoSs",
    channelTitle: "Essence of linear algebra",
  },
  {
    videoId: "PLP29wDx6QmW5DdwpdwHCRJsEubS5NrQ9b",
    coverId: "fTBwD3sb5mw",
    channelTitle: "16-Bit Virtual Machine",
  },
  {
    videoId: "PLHhi8ymDMrQZad6JDh6HRzY1Wz5WB34w0",
    coverId: "SE5aXH-yf0I",
    channelTitle: "Основы программирования",
  },
  {
    videoId: "PLHhi8ymDMrQZmXEqIIlq2S9-Ibh9b_-rQ",
    coverId: "WBcHgaoHh1k",
    channelTitle: "Node.js",
  },
  {
    videoId: "PLYSZyzpwBEWTBdbfStjqJSGaulqcHoNkT",
    coverId: "41ox41v62jU",
    channelTitle:
      "React.js Unit Testing and Integration Testing Tutorial",
  },
];
