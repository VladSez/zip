import type { AppProps } from "next/app";
import { ToastContainer } from "react-toastify";
import { SWRConfig } from "swr";
import dayjs from "dayjs";
import { SessionProvider } from "next-auth/react";

// https://github.com/ericclemmons/click-to-component
import { ClickToComponent } from "click-to-react-component";

import { Layout } from "../components/Layout";

import relativeTime from "dayjs/plugin/relativeTime";

import "react-lite-youtube-embed/dist/LiteYouTubeEmbed.css";
import "react-toastify/dist/ReactToastify.min.css";
import "focus-visible";
import "../styles/global.css"; // this css file has to be at the bottom all the time

dayjs.extend(relativeTime);

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <SessionProvider
      // Provider options are not required but can be useful in situations where
      // you have a short session maxAge time. Shown here with default values.
      // options={{
      // Stale Time controls how often the useSession in the client should
      // contact the server to sync the session state. Value in seconds.
      // e.g.
      // * 0  - Disabled (always use cache value)
      // * 60 - Sync session state with server if it's older than 60 seconds
      // staleTime: 0,
      // Refetch Interval tells windows / tabs that are signed in to keep sending
      // a keep alive request (which extends the current session expiry) to
      // prevent sessions in open windows from expiring. Value in seconds.
      //
      // Note: If a session has expired when keep alive is triggered, all open
      // windows / tabs will be updated to reflect the user is signed out.
      // refetchInterval: 0,
      // }}
      session={pageProps.session}
    >
      <SWRConfig
        value={{
          // dedupingInterval: 3000,
          // refreshInterval: 6000, // TODO: don't know if i need it
          onError: (error, key) => {
            console.error({ error, key });

            // toast.error(`${error?.message}`);
          },
          errorRetryCount: 5,
          errorRetryInterval: 6000,
        }}
      >
        <Layout>
          <ClickToComponent />
          <Component {...pageProps} />
          <ToastContainer
            position="bottom-left"
            autoClose={2000}
            limit={3} // https://fkhadra.github.io/react-toastify/limit-the-number-of-toast-displayed/
          />
        </Layout>
      </SWRConfig>
    </SessionProvider>
  );
}

export default MyApp;
