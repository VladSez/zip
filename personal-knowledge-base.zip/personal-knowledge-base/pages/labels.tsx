import { LabelsList } from "../features/labels";

export default function ManageLabels() {
  return <LabelsList />;
}
