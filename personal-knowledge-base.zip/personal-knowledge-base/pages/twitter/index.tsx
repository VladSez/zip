import { useEffect, useState } from "react";
import { useRouter } from "next/router";

import clsx from "clsx";
import * as RadixTabs from "@radix-ui/react-tabs";

import { TwitterBookmarksList } from "../../features/twitter/bookmarks";
import { TwitterLikesList } from "../../features/twitter/likes";
import { TwitterList } from "../../features/twitter/list";

import { FeedContainer } from "../../components/FeedContainer";
import { objectEntries, objectKeys } from "ts-extras";

export enum TwitterTabs {
  Likes = "Likes",
  Bookmarks = "Bookmarks",
  List = "List",
}

const twitterCategories = {
  [TwitterTabs.Likes]: <TwitterLikesList />,
  [TwitterTabs.Bookmarks]: <TwitterBookmarksList />,
  [TwitterTabs.List]: <TwitterList />,
} as const;

type TweetTabProps = keyof typeof TwitterTabs;

export default function Twitter() {
  const router = useRouter();
  const [activeTab, setActiveTab] =
    useState<TweetTabProps>();

  useEffect(() => {
    if (!router.isReady) {
      return;
    }

    // set default tab, if not tab in url
    if (!router.query.tab) {
      router.push({
        query: {
          tab: TwitterTabs.Likes, // default tab
        },
      });
      setActiveTab(TwitterTabs.Likes);
    } else {
      // take tab from url
      setActiveTab(router.query.tab as TweetTabProps);
    }
  }, [router]);

  return (
    <FeedContainer>
      <RadixTabs.Root
        defaultValue={router.query.tab as string}
        value={activeTab}
        onValueChange={(tab) => {
          router.push({
            query: {
              tab: tab,
            },
          });
        }}
      >
        <RadixTabs.List
          aria-label="Twitter tabs"
          className="flex space-x-2 bg-blue-100 p-1 sm:rounded-xl"
        >
          {objectKeys(twitterCategories).map((category) => (
            <RadixTabs.Trigger
              key={category}
              className={clsx(
                "w-full p-0.5 py-1.5 sm:p-1 sm:py-2.5",
                "rounded-lg text-sm font-medium leading-5 text-blue-700",
                "ring-white ring-opacity-60 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-black",
                "hover:bg-white/50",
                "transition-colors motion-reduce:transition-none",
                {
                  "bg-white shadow hover:bg-white":
                    activeTab === category,
                },
              )}
              value={category}
            >
              {category}
            </RadixTabs.Trigger>
          ))}
        </RadixTabs.List>

        {objectEntries(twitterCategories).map(
          ([key, value]) => {
            return (
              <RadixTabs.Content
                key={key}
                className="my-5 focus:outline-none focus-visible:ring-2 focus-visible:ring-black"
                value={key}
              >
                {value}
              </RadixTabs.Content>
            );
          },
        )}
      </RadixTabs.Root>
    </FeedContainer>
  );
}
