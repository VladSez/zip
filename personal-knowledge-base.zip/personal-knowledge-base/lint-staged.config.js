module.exports = {
  // Run type-check on changes to TypeScript files
  "**/*.ts?(x)": () => "tsc-files --noEmit",
  // Run ESLint on changes to JavaScript/TypeScript files
  "**/*.(ts|js)?(x)": (filenames) => [
    `yarn eslint ${filenames.join(" ")}`,
    `yarn prettier --write ${filenames.join(" ")}`,
  ],
};
