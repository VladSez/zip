import { object, string, TypeOf } from "yup";

export const labelsSchema = object({
  label: string().required(),
  description: string().optional(),
  color: string().required(),
  type: string().required(),
});

export type Label = TypeOf<typeof labelsSchema>;
