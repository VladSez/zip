// @ts-check
/**
 * @type {import('next').NextConfig}
 **/
const nextConfig = {
  async redirects() {
    return [
      {
        source: "/",
        destination: "/twitter",
        permanent: true,
      },
      {
        source: "/youtube",
        destination: "/youtube/likes",
        permanent: true,
      },
    ];
  },
  eslint: {
    dirs: [
      "pages",
      "components",
      "lib",
      "hooks",
      "features",
      "schemas",
    ],
  },
  images: {
    domains: [
      "abs.twimg.com",
      "pbs.twimg.com",
      "avatars.githubusercontent.com",
    ],
  },
};

module.exports = nextConfig;
