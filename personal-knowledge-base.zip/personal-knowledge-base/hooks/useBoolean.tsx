import { useState } from "react";

export function useBoolean(defaultValue = false) {
  const [value, setValue] = useState<boolean>(defaultValue);

  const setTrue = () => setValue(true);
  const setFalse = () => setValue(false);
  const toggle = () => setValue((x) => !x);

  return {
    value,
    setValue,
    setTrue,
    setFalse,
    toggle,
  };
}
