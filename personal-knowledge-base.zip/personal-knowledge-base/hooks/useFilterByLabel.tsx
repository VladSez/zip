import { useRouter } from "next/dist/client/router";
import useSWR from "swr";
import { defaultFetcher } from "../lib/defaultFetcher";
import { laggy } from "../lib/swrMiddleware";

interface FilteredItemsType<T> {
  items: T;
  canFetchNext?: boolean;
  totalCountOfItems?: number;
}

/**
 *
 * @deprecated because we will need to rethink/refactor filter functionality
 */
export const useFilterByLabel = <
  T extends Array<unknown>,
>() => {
  const router = useRouter();

  const url = `/api/filter-labels?id=${
    router.query.id
  }&from=${router.query.from || 0}&to=${
    router.query.to || 0
  }`;

  const {
    data: {
      items: filteredItems,
      canFetchNext,
      totalCountOfItems,
    } = {},
    isValidating,
    // TODO: fix this
    // @ts-expect-error
    isLagging, // https://github.com/vercel/swr/pull/1160#issuecomment-865327353
  } = useSWR<FilteredItemsType<T>>(url, defaultFetcher, {
    use: [laggy],
  });

  return {
    filteredItems,
    canFetchNext,
    isValidating,
    isLagging,
    totalCountOfItems,
  };
};
