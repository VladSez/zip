import { toast } from "react-toastify";
import useSWR from "swr";
import { LabelsInterface } from "../features/labels/types";
import { defaultFetcher } from "../lib/defaultFetcher";
import { useRouterQuery } from "./useRouterQuery";

export const useLabels = () => {
  const { data, mutate } = useSWR<LabelsInterface>(
    "/api/manage-labels",
    defaultFetcher,
    {
      onError: (error, key) => {
        console.error({ error, key });
        toast.error(`${error?.message}`);
      },
    },
  );

  const { isTwitterPage, isGithubPage, query } =
    useRouterQuery();

  // TODO: this is broken now!!!! FIX IT! now there is no tabId = 2
  // tabId = 2, because this is the only page that has filterable data
  const isGithubPageWithTabId2 =
    query?.tabId === "2" && isGithubPage;

  const canShowFilterLabels =
    isTwitterPage || isGithubPageWithTabId2;

  return { data, mutate, canShowFilterLabels };
};
