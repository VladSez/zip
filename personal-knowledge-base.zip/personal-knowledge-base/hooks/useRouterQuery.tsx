import { useRouter } from "next/dist/client/router";
import { useMemo } from "react";

/**
 *
 * @deprecated this hook should be refactored and preferably not used anymore
 */
export const useRouterQuery = () => {
  const router = useRouter();

  const prevPage = router.query?.prevPage as string;

  const query = useMemo(() => {
    return router.query;
  }, [router.query]);

  const queryId = useMemo(() => {
    return router.query?.id
      ? typeof router.query.id === "string"
        ? router.query.id?.split(",")
        : []
      : [];
  }, [router.query.id]);

  const [, rootPathOfThePage, subpath] =
    router.pathname?.split("/");

  const isTwitterPage = rootPathOfThePage === "twitter";
  const isGithubPage = rootPathOfThePage === "github";

  return {
    query,
    queryId,
    rootPathOfThePage,
    // TODO: this is currently needed only on /twitter pages
    // maybe add check for twitter page?
    prevPageParam: prevPage ? prevPage : subpath,
    isGithubPage,
    isTwitterPage,
  };
};
