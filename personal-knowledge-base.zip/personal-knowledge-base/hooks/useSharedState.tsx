import useSWR from "swr";

export const useSharedState = <T extends unknown>(
  key: string,
  initialData?: T,
) => {
  const { data: state, mutate: setState } = useSWR<T>(key, {
    fallbackData: initialData,
  });

  return { state, setState };
};
