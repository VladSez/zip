import axios from "axios";
import { TwitterApiResponse } from "../../features/twitter/types";
import { TweetApiBookmarksResponse } from "./types/bookmarks";
import {
  getConfig,
  getKeys,
  transformTweets,
} from "./helpers";
import { DEFAULT_TWITTER_VARS } from "./constants";

const url =
  "https://twitter.com/i/api/graphql/lgV7GA3u0OzosBozQrnqhQ/Bookmarks?variables=";

interface cursorProps {
  cursor?: string;
}

// TODO: replace with some generic function?
export const fetchTwitterBookmarks = async ({
  cursor,
}: cursorProps): Promise<TwitterApiResponse> => {
  try {
    const response = await axios(
      getConfig({
        url,
        cursor,
        variables: DEFAULT_TWITTER_VARS,
      }),
    );

    const data: TweetApiBookmarksResponse = response.data;

    if (data?.errors) {
      console.log(JSON.stringify(data.errors, null, 2));
      // try to refetch again
      return fetchTwitterBookmarks({ cursor });
      // or maybe throw an error?
      // but looks like it working with reruning the function

      // throw new Error("twitter error");
    }

    const bookmarksTimeLine =
      data?.data?.bookmark_timeline?.timeline
        ?.instructions?.[0]?.entries;

    const KEYS = bookmarksTimeLine?.map(getKeys);

    const tweets = bookmarksTimeLine?.map(transformTweets);

    const lastIndex = KEYS ? KEYS.length - 1 : 0;

    const nextCursor =
      bookmarksTimeLine?.[lastIndex]?.content?.value;

    return {
      data: tweets?.filter(Boolean) || [], // removes nulls(false values)
      cursor: nextCursor ? nextCursor : null,
    };
  } catch (err) {
    console.error({ err });
    throw err;

    // throw or consider retrying fn
    // return fetchTwitterBookmarks({});
  }
};
