import axios from "axios";

import { TwitterApiResponse } from "../../features/twitter/types";
import { TWITTER_LIST_BY_ID_VARS } from "./constants";
import {
  getConfig,
  getKeys,
  transformTweets,
} from "./helpers";
import { TwitterApiListResponse } from "./types/list";

interface cursorProps {
  cursor?: string;
}

const url =
  "https://mobile.twitter.com/i/api/graphql/lSKmRgdeeC8N5a68TXP1gw/ListLatestTweetsTimeline?variables=";

export const fetchTwitterListById = async ({
  cursor,
}: cursorProps): Promise<TwitterApiResponse> => {
  try {
    const response = await axios(
      getConfig({
        url,
        cursor,
        variables: TWITTER_LIST_BY_ID_VARS({
          listId: "1336756249816395782", // TODO: get listId from query
        }),
      }),
    );

    const data: TwitterApiListResponse = response.data;

    const listTimeLine =
      data?.data?.list?.tweets_timeline?.timeline
        ?.instructions?.[0]?.entries;

    const tweets = listTimeLine?.map(transformTweets);

    const keys = listTimeLine?.map(getKeys);
    const keysLastItem = keys ? keys?.length - 1 : 0;

    const nextCursor =
      listTimeLine?.[keysLastItem]?.content?.value;

    return {
      data: tweets ? tweets?.filter(Boolean) : [],
      cursor: nextCursor ? nextCursor : null,
    };
  } catch (err) {
    console.error({
      err,
      data: JSON.stringify((err as any).response.data),
    });

    throw err;
  }
};
