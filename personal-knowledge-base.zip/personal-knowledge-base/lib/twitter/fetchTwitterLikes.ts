import axios from "axios";

import { TwitterApiResponse } from "../../features/twitter/types";
import { TweetApiLikesResponse } from "./types/likes";
import {
  getConfig,
  getKeys,
  transformTweets,
} from "./helpers";
import { DEFAULT_TWITTER_VARS } from "./constants";

interface cursorProps {
  cursor?: string;
}

const url =
  "https://twitter.com/i/api/graphql/3hYkrRL_IXf4OAXdyoJYGw/Likes?variables=";

// TODO: replace with some generic function?
export const fetchTwitterLikes = async ({
  cursor,
}: cursorProps): Promise<TwitterApiResponse> => {
  try {
    const response = await axios(
      getConfig({
        url,
        cursor,
        variables: DEFAULT_TWITTER_VARS,
      }),
    );
    const data: TweetApiLikesResponse = response.data;

    const likesTimeLine =
      data.data?.user?.result?.timeline?.timeline
        ?.instructions?.[0]?.entries;

    const tweets = likesTimeLine?.map(transformTweets);

    const keys = likesTimeLine?.map(getKeys);
    const keysLastItem = keys ? keys?.length - 1 : 0;

    const nextCursor =
      likesTimeLine?.[keysLastItem]?.content?.value;

    return {
      data: tweets ? tweets.filter(Boolean) : [],
      cursor: nextCursor ? nextCursor : null,
    };
  } catch (err) {
    console.error({
      err,
      data: JSON.stringify((err as any).response.data),
    });

    throw err;
  }
};
