export const DEFAULT_TWITTER_VARS = {
  userId: "846432643579330560",
  count: "10",
  withTweetQuoteCount: false,
  includePromotedContent: false,
  withSuperFollowsUserFields: true,
  withUserResults: true,
  withBirdwatchPivots: false,
  withReactionsMetadata: false,
  withReactionsPerspective: false,
  withSuperFollowsTweetFields: true,
  withClientEventToken: false,
  withBirdwatchNotes: false,
  withVoice: true,
};

export const TWITTER_LIST_BY_ID_VARS = ({
  listId,
}: {
  listId: string;
}) => {
  return {
    listId,
    count: 20,
    withSuperFollowsUserFields: true,
    withDownvotePerspective: false,
    withReactionsMetadata: false,
    withReactionsPerspective: false,
    withSuperFollowsTweetFields: true,
    withBirdwatchPivots: false,
  };
};
