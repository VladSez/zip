export async function defaultFetcher<T = any>(
  url: RequestInfo,
  params?: RequestInit,
): Promise<T> {
  const res = await fetch(url, params);

  // If the status code is not in the range 200-299,
  // we still try to parse and throw it.
  if (!res.ok) {
    // TODO: fix this type
    const error: any = new Error(
      "An error occurred while fetching the data.",
    );

    // TODO: investigate this fiedls
    // Attach extra info to the error object.
    error.info = await res.json();
    error.status = res.status;
    throw error;
  }

  return res.json();
}
