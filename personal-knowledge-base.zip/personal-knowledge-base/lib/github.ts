import { request } from "@octokit/request";

export const requestWithAuth = request.defaults({
  headers: {
    authorization: `token ${process.env.NEXT_PUBLIC_GITHUB_TOKEN}`,
    "If-None-Match": "etag",
    // "If-Modified-Since":
    //   "Sun Dec 24 2017 22:00:00 GMT-0600 (CST)",
  },
});
