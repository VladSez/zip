### Documentation

- [Repo](https://github.com/VladSez/personal-knowledge-base)
- [Production URL](https://personal-knowledge-base.vercel.app/)
- [Supabase DB](https://app.supabase.io/project/iqrltgwyokjpzkzbuwqt/editor/table)
- [Supabase API](https://app.supabase.io/project/iqrltgwyokjpzkzbuwqt/api/default?page=tables-intro)
- [Vercel Dashboard](https://vercel.com/vladsazon27/personal-knowledge-base)
- [Icons](https://iconoir.com/)
- [HeroIcons](https://heroicons.com/)
- [Google Console](<https://console.cloud.google.com/apis/dashboard?project=boxwood-ray-304917&pageState=(%22duration%22:(%22groupValue%22:%22P1D%22,%22customValue%22:null))>)

### Useful Links

- when fetching /api route using swr you have to prepend '/' before api,
  otherwise it will fetch incorrect route when not in the root route '/main' will be good, '/main/dashboard' will break

```js
useSwr("api/get-stuff"); // bad
useSwr("/api/get-stuff"); // good
```

### Local Development

We use [Click to Component](https://github.com/ericclemmons/click-to-component)
Alt+Click in browser to open the source of the React component in VS Code
