import { useFilterByLabel } from "../../hooks/useFilterByLabel";

import { MobileDialog } from "../../components/MobileDialog";
import { ScreenReader } from "../../components/ScreenReader";
import { useLabels } from "../../hooks/useLabels";
import { useBoolean } from "../../hooks/useBoolean";

export const FilterByLabelMobileButton = () => {
  const { canShowFilterLabels } = useLabels();

  const {
    value: isDialogOpen,
    setTrue: openDialog,
    setFalse: closeDialog,
  } = useBoolean();

  const { totalCountOfItems, isLagging } =
    useFilterByLabel();

  return (
    <>
      {canShowFilterLabels ? (
        <button
          type="button"
          onClick={openDialog}
          className="fixed bottom-5 right-5 h-14 w-14 cursor-pointer rounded-full bg-gray-100 shadow-md active:bg-gray-300 lg:hidden"
        >
          {totalCountOfItems ? (
            <div
              title={`Found ${totalCountOfItems} items`}
              className="absolute -top-2 left-0 flex h-5 w-5 items-center justify-center rounded-full bg-red-400 p-0.5 text-xs font-semibold leading-3 text-white"
            >
              {totalCountOfItems}
            </div>
          ) : null}
          <div className="flex justify-center">
            <ScreenReader>
              Button to filter by label
            </ScreenReader>
            <FilterIcon />
          </div>
        </button>
      ) : null}
      <MobileDialog
        isOpen={isDialogOpen}
        closeModal={closeDialog}
        isLagging={isLagging}
        totalCountOfItems={totalCountOfItems}
      />
    </>
  );
};

const FilterIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-6 w-6"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
      />
    </svg>
  );
};
