import clsx from "clsx";
import { useRouter } from "next/dist/client/router";
import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { Button } from "../../components/Button";
import { useLabels } from "../../hooks/useLabels";
import { useRouterQuery } from "../../hooks/useRouterQuery";
import { LabelInterface } from "../labels/types";

type FormValues = {
  [key: string]: boolean;
};

const labelIsApplied = (label: LabelInterface) =>
  label?.ids?.length > 0;

/**
 * @deprecated we need to refactor all the logic behind this component
 * related issues: https://github.com/VladSez/personal-knowledge-base/issues/34
 */
export const FilterByLabelForm = () => {
  const { data } = useLabels();

  const router = useRouter();
  const {
    queryId,
    rootPathOfThePage,
    isTwitterPage,
    isGithubPage,
    prevPageParam,
  } = useRouterQuery();

  // this is needed to return back to the previous page
  // after applying filters(currently relevant only for twitter pages)

  const defaultValues = useMemo(
    () =>
      data?.labels?.reduce((acc, label) => {
        const value = queryId.includes(`id.eq.${label.id}`);
        return { ...acc, [`test_${label.label}`]: value };
      }, {}),
    [data?.labels, queryId],
  );

  const { register, reset } = useForm<FormValues>({
    defaultValues: defaultValues,
  });

  useEffect(() => {
    // sync form state when url changes
    reset(defaultValues);
  }, [defaultValues, reset, router.query.id]);

  const allFormFields = useMemo(
    () =>
      data?.labels?.reduce((acc, label) => {
        return { ...acc, [`test_${label?.label}`]: false };
      }, {}),
    [data?.labels],
  );

  // show labels that have 'type' of the page ('twitter' or 'github')
  const filteredLabels = data?.labels?.filter((x) => {
    if (x.type === "github") {
      return (
        x.type === rootPathOfThePage &&
        router.query?.tabId === "2"
      );
    }
    return x.type === rootPathOfThePage;
  });

  if (!filteredLabels) {
    return null;
  }

  return (
    <>
      {filteredLabels?.length > 0 ? (
        filteredLabels
          ?.filter(labelIsApplied) // show only labels that are applied
          ?.map((label) => {
            const name = `test_${label.label}`;

            return (
              <div
                key={label.id}
                className="ml-2 flex items-baseline"
              >
                <input
                  type="checkbox"
                  id={label.label}
                  // name={label.label}
                  className="h-3.5 w-3.5 rounded-md border-gray-300 text-indigo-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2"
                  {...register(name, {
                    onChange: (e) => {
                      if (e.target.checked) {
                        const query = [
                          ...queryId,
                          `id.eq.${label.id}`,
                        ];

                        router.push(
                          {
                            pathname: isTwitterPage
                              ? `/twitter/filters`
                              : router.pathname,
                            query: {
                              // this is only needed for twitter page
                              ...(isTwitterPage && {
                                prevPage: prevPageParam,
                              }),
                              // this is only needed for github page
                              ...(isGithubPage && {
                                tabId: 2,
                              }),
                              id: query.toString(),
                              from: 0,
                              to: 10,
                            },
                          },
                          undefined,
                          { shallow: true },
                        );
                      } else {
                        const query = queryId.filter(
                          (id) =>
                            id !== `id.eq.${label.id}`,
                        );

                        const filterIsEmpty =
                          query.length === 0;

                        if (filterIsEmpty) {
                          // if filter is empty, redirect to the page you came from
                          router.push(
                            isTwitterPage
                              ? `/twitter/${router.query.prevPage}`
                              : router.pathname,
                            undefined,
                            { shallow: true },
                          );
                        } else {
                          // removing one filter from url(push to the first page)
                          router.push(
                            {
                              pathname: router.pathname,
                              query: {
                                // this is only needed for twitter page
                                ...(isTwitterPage && {
                                  prevPage: prevPageParam,
                                }),
                                // this is only needed for github page
                                ...(isGithubPage && {
                                  tabId: 2,
                                }),
                                id: query.toString(),
                                from: 0,
                                to: 10,
                              },
                            },
                            undefined,
                            { shallow: true },
                          );
                        }
                      }
                    },
                  })}
                />
                <label
                  htmlFor={label.label}
                  className={clsx(
                    "relative bottom-[2px] my-1 ml-1 select-none leading-snug text-gray-600",
                  )}
                >
                  {label.label}
                  <span
                    className={clsx("ml-1 text-gray-900")}
                  >
                    ({label?.ids?.length || 0})
                  </span>
                </label>
              </div>
            );
          })
      ) : (
        <div className="block w-full p-2">No labels</div>
      )}
      {filteredLabels?.length > 0 ? (
        <div className="my-1">
          <Button
            onClick={() => {
              // set all form fields to false
              reset(allFormFields);
              // remove all filters from url
              router.push(
                isTwitterPage
                  ? `/twitter/${router.query.prevPage}`
                  : router.pathname,
                undefined,
                { shallow: true },
              );
            }}
          >
            Reset labels
          </Button>
        </div>
      ) : null}
    </>
  );
};
