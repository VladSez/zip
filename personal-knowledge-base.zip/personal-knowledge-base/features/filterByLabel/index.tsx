import { AddLabelButton } from "../labels/components/AddLabelButton";
import { useLabels } from "../../hooks/useLabels";
import { FilterByLabelForm } from "./FilterByLabelForm";

/**
 * @deprecated we need to refactor all the logic behind this component
 * related issues: https://github.com/VladSez/personal-knowledge-base/issues/34
 */
export const FilterByLabelListContainer = () => {
  const { data, canShowFilterLabels } = useLabels();

  // show filters only on twitter and github(with tabId=2) pages
  if (!canShowFilterLabels) {
    return null;
  }

  if (!data) {
    return <Placeholder />;
  }

  return (
    <div className="custom-scroll-bar sticky top-96 hidden max-h-56 overflow-auto sm:col-span-1 lg:block">
      <div className="mx-2 mb-2 flex items-center text-sm font-semibold uppercase tracking-wide text-gray-900 ">
        <p className="mr-0.5">Filter by label:</p>
        <AddLabelButton />
      </div>

      <FilterByLabelForm />
    </div>
  );
};

const Placeholder = () => {
  return (
    <div className="top-96 hidden max-h-56 w-[250px] overflow-auto lg:block">
      <h5 className="mx-2 mb-4 flex h-[38px] items-center text-sm font-semibold uppercase tracking-wide text-gray-900 ">
        Filters:
      </h5>
      <div className="mx-2 flex animate-pulse space-x-4">
        <div className="flex-1 space-y-2">
          <div className="h-4 w-3/4 rounded bg-gray-300"></div>
          <div className="space-y-2">
            <div className="h-4 rounded bg-gray-300"></div>
            <div className="h-4 w-5/6 rounded bg-gray-300"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
