import { TransformedTweet } from "../../../lib/twitter/types";

export type TransformedTweetNullable =
  TransformedTweet | null;

export interface TwitterApiResponse {
  /**
   * Tweet data.
   */
  data: TransformedTweetNullable[];
  /**
   * Cursor to fetch next batch of tweets.
   */
  cursor?: string | null;
  statusCode?: number;
  message?: unknown;
}

export interface TweetUser {
  user: TransformedTweet["user"] | undefined;
}
