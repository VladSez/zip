import Linkify from "linkify-react";
import { TransformedTweet } from "../../../lib/twitter/types";

import clsx from "clsx";
import { Tooltip } from "../../../components/Tooltip";

import "linkify-plugin-hashtag";
import "linkify-plugin-mention";

interface TweetTextProps {
  text: TransformedTweet["tweetText"];
  className?: string;
  urls: TransformedTweet["urls"];
}

export const TweetText = ({
  text,
  className,
  urls,
}: TweetTextProps) => {
  return (
    <Linkify<any, any>
      tagName="p"
      className={clsx(
        "whitespace-pre-wrap py-2 text-[15px]",
        className,
      )}
      options={{
        className: "text-blue-500 hover:underline",
        rel: "noopener",
        target: "_blank",
        format: {
          url: (value: string) => {
            if (!value.startsWith("https://")) {
              value = `https://${value}`;
            }
            const res = urls?.find((x) => x.url === value);
            return (
              <Tooltip content={res?.expanded_url}>
                <span>{res?.display_url}</span>
              </Tooltip>
            );
          },
        },
        formatHref: {
          mention: (href: string) =>
            "https://mobile.twitter.com" + href,
          hashtag: (href: string) =>
            "https://twitter.com/hashtag/" +
            href.substring(1),
        },
      }}
    >
      {text}
    </Linkify>
  );
};
