import { forwardRef, SetStateAction } from "react";
import { Button } from "../../../components/Button";
import { LoaderWithText } from "../../../components/Loader";

type Props = {
  isFetchingMoreTweets: boolean;
  size: number;
  setSize: (
    size: number | ((_size: number) => number),
  ) => Promise<unknown[] | undefined>;
  setFetchingMoreTweets: (
    value: SetStateAction<boolean>,
  ) => void;
  isDataAvailable: boolean;
};

type Ref = HTMLSpanElement;

export const TweetFeedBottomPageLoader = forwardRef<
  Ref,
  Props
>(
  (
    {
      isFetchingMoreTweets,
      size,
      setSize,
      setFetchingMoreTweets,
      isDataAvailable,
    },
    ref,
  ) => {
    return (
      <div className="flex flex-col items-center justify-center">
        {isFetchingMoreTweets ? <LoaderWithText /> : null}
        {isDataAvailable ? (
          <Button
            onClick={() => {
              // fetch next page
              setSize(size + 1);
              setFetchingMoreTweets(true);
            }}
          >
            <span ref={ref}>Load more</span>
          </Button>
        ) : null}
      </div>
    );
  },
);

TweetFeedBottomPageLoader.displayName =
  "TweetFeedBottomPageLoader";
