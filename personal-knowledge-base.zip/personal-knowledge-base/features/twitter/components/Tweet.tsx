import clsx from "clsx";
import { ExternalLink } from "../../../components/ExternalLink";
import { TransformedTweet } from "../../../lib/twitter/types";
import { TransformedTweetNullable } from "../types";

import { TweetHeader } from "./TweetHeader";
import { TweetMedia } from "./TweetMedia";
import { TweetMeta } from "./TweetMeta";
import { TweetText } from "./TweetText";
import { TweetCards } from "./cards";

interface TweetLikeProps {
  tweet: TransformedTweetNullable;
  isQuotedTweet?: boolean;
}

export const Tweet = ({
  tweet,
  isQuotedTweet = false,
}: TweetLikeProps) => {
  const tweetText =
    tweet?.retweetTweet?.tweetText || tweet?.tweetText;

  const hasThread =
    tweet?.retweetTweet?.threadUrl || tweet?.threadUrl;

  const threadUrl =
    tweet?.retweetTweet?.threadUrl || tweet?.threadUrl;

  const urls = tweet?.retweetTweet?.urls || tweet?.urls;

  const media = tweet?.retweetTweet?.media || tweet?.media;

  const meta = tweet?.retweetTweet || tweet;

  const quotedTweet =
    tweet?.quotedTweet || tweet?.retweetTweet?.quotedTweet;

  return (
    <li
      className={clsx(
        "border-t border-r border-l border-gray-100 p-4 py-3 last:border-b",
        {
          "rounded-2xl border": isQuotedTweet,
        },
      )}
    >
      <article>
        <TweetHeader tweet={tweet} />
        <TweetText text={tweetText} urls={urls} />
        <TweetMedia media={media} />
        {/* Do not show cards, if the tweet has quoted tweet */}
        {!quotedTweet ? <TweetCards tweet={tweet} /> : null}

        {quotedTweet ? (
          <TweetQuoted tweet={quotedTweet} />
        ) : null}

        <TweetMeta
          tweet={meta}
          isQuotedTweet={isQuotedTweet}
        />
        {hasThread ? (
          <div className="mt-4">
            <ExternalLink
              url={threadUrl}
              className="font-normal text-blue-500"
            >
              Show this thread
            </ExternalLink>
          </div>
        ) : null}
      </article>
    </li>
  );
};

const TweetQuoted = ({
  tweet,
}: {
  tweet: TransformedTweet;
}) => {
  const tweetText =
    tweet?.retweetTweet?.tweetText || tweet?.tweetText;

  const urls = tweet?.retweetTweet?.urls || tweet?.urls;

  const hasThread =
    tweet?.retweetTweet?.threadUrl || tweet?.threadUrl;

  const threadUrl =
    tweet?.retweetTweet?.threadUrl || tweet?.threadUrl;

  const media = tweet?.retweetTweet?.media || tweet?.media;

  return (
    <article className="mt-3 rounded-2xl border border-gray-200 p-3">
      <div className="flex gap-2">
        <TweetHeader tweet={tweet} />
      </div>
      <TweetText text={tweetText} urls={urls} />
      <TweetMedia media={media} />

      {hasThread ? (
        <div className="mt-4">
          <ExternalLink
            url={threadUrl}
            className="font-normal text-blue-500"
          >
            Show this thread
          </ExternalLink>
        </div>
      ) : null}
    </article>
  );
};
