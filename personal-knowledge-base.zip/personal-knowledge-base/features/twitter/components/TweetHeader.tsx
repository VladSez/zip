import { TransformedTweetNullable } from "../types";

import { TweetAvatar } from "./TweetAvatar";
import { TweetCreatedAtTime } from "./TweetCreateAtTime";
import { RetweetIcon } from "./TweetRetweet";
import { TweetUserName } from "./TweetUserName";

interface TweetHeaderProps {
  tweet: TransformedTweetNullable;
}

export const TweetHeader = ({
  tweet,
}: TweetHeaderProps) => {
  const user = tweet?.retweetTweet
    ? tweet?.retweetTweet?.user
    : tweet?.user;

  const hasRetweet = Boolean(tweet?.retweetTweet);
  return (
    <>
      <header className="mb-2 flex items-end gap-2">
        <div>
          {hasRetweet ? <RetweetIcon /> : null}
          <TweetAvatar user={user} width={40} height={40} />
        </div>
        <div className="flex flex-col">
          <TweetUserName
            user={user}
            hasRetweet={Boolean(tweet?.retweetTweet)}
            retweetUser={tweet?.user}
          />
          <div className="flex items-center gap-1">
            <TweetUserScreenName>
              @{user?.screenName}
            </TweetUserScreenName>
            <Dot />
            <TweetCreatedAtTime tweet={tweet} />
          </div>
        </div>

        {/* {!isQuotedTweet ? (
          <SelectLabel
            id={String(tweet?.id)}
            itemToBeSaved={{
              ...tweet,
              type: "twitter",
            }}
            type="twitter" // TODO: do we need this?
          />
        ) : null} */}
      </header>
    </>
  );
};

const TweetUserScreenName = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  return (
    <span className="text-sm text-gray-600">
      {children}
    </span>
  );
};

const Dot = () => {
  return <span className="text-gray-600">·</span>;
};
