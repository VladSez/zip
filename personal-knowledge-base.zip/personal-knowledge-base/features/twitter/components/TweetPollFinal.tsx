import clsx from "clsx";

interface TweetPollFinal {
  combinedCountsAndChoices:
    | {
        text: string | undefined;
        count: number;
      }[]
    | undefined;
  totalCount: number | undefined;
  maxCount: number | undefined;
}

export const TweetPollFinal = ({
  combinedCountsAndChoices,
  totalCount = 0,
  maxCount,
}: TweetPollFinal) => {
  return (
    <div>
      <ul>
        {combinedCountsAndChoices?.map((x) => {
          const percent =
            (Number(x?.count) / totalCount) * 100;

          return (
            <li key={x?.text} className="my-1">
              <div
                className={clsx(
                  "relative flex w-full justify-between  text-sm",
                  {
                    "font-bold !text-gray-800":
                      x?.count === maxCount,
                  },
                )}
              >
                <div
                  className={clsx(
                    "absolute -z-10 h-full w-full rounded-md bg-slate-200",
                    {
                      "bg-blue-300": x?.count === maxCount,
                    },
                  )}
                  style={{ width: `${percent}%` }}
                ></div>
                <span className="block p-2">{x?.text}</span>
                <span className="block p-2">
                  {percent?.toFixed(1)}%
                </span>
              </div>
            </li>
          );
        })}
      </ul>
      <div className="mt-2 flex gap-1">
        <span className="inline-flex text-sm text-gray-500">
          {totalCount} votes
        </span>
        <span className="text-gray-500">·</span>
        <span className="inline-flex text-sm text-gray-500">
          Final results
        </span>
      </div>
    </div>
  );
};
