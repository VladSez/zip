import React from "react";

import { TransformedTweet } from "../../../lib/twitter/types";
import { isNonEmptyArray } from "../../../utils/isNotEmptyArray";

import { FourImagesTwitterLayout } from "./media/FourImagesTwitterLayout";
import { GifTwitterMedia } from "./media/GifTwitterMedia";
import { SingleImageTwitterLayout } from "./media/SingleImageTwitterLayout";
import { ThreeImagesTwitterLayout } from "./media/ThreeImagesTwitterLayout";
import { TwoImagesTwitterLayout } from "./media/TwoImagesTwitterLayout";
import { VideoTwitterMedia } from "./media/VideoTwitterMedia";

interface TweetMediaProps {
  media: TransformedTweet["media"] | undefined;
}

export const TweetMedia = ({ media }: TweetMediaProps) => {
  const hasMedia = media && isNonEmptyArray(media);

  const hasMoreThanOneImage = hasMedia
    ? media.length > 1
    : false;

  return (
    <>
      {hasMedia ? (
        <div
          className={
            hasMoreThanOneImage
              ? "grid grid-cols-2 gap-[2px]"
              : "grid grid-cols-1"
          }
        >
          {media.map((m, index) => {
            // media has video
            if (m?.type === "video") {
              return (
                <VideoTwitterMedia
                  media={m}
                  key={m?.media_key}
                />
              );
            }
            // media has GIF
            if (m?.type === "animated_gif") {
              return (
                <GifTwitterMedia
                  media={m}
                  key={m?.media_key}
                />
              );
            }
            // single image layout
            if (media.length === 1) {
              return (
                <SingleImageTwitterLayout
                  media={m}
                  key={m?.media_key}
                />
              );
            }

            // two image layout
            if (media.length === 2) {
              return (
                <TwoImagesTwitterLayout
                  media={m}
                  key={m?.media_key}
                  index={index}
                />
              );
            }

            // three image layout
            if (media.length === 3) {
              return (
                <ThreeImagesTwitterLayout
                  media={m}
                  key={m?.media_key}
                  index={index}
                />
              );
            }

            // four image layout
            if (media.length === 4) {
              return (
                <FourImagesTwitterLayout
                  media={m}
                  key={m?.media_key}
                  index={index}
                />
              );
            }

            // default layout
            return (
              <SingleImageTwitterLayout
                media={m}
                key={m?.media_key}
              />
            );
          })}
        </div>
      ) : null}
    </>
  );
};
