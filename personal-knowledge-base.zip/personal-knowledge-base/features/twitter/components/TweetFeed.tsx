import { LoaderWithText } from "../../../components/Loader";
import { isNonEmptyArray } from "../../../utils/isNotEmptyArray";
import { TransformedTweetNullable } from "../types";
import { Tweet } from "./Tweet";

interface TweetFeedProps {
  tweets: TransformedTweetNullable[];
}

export const TweetFeed = ({ tweets }: TweetFeedProps) => {
  return (
    <ul role="list">
      {isNonEmptyArray(tweets) ? (
        tweets.map((tweet) => {
          return <Tweet tweet={tweet} key={tweet?.id} />;
        })
      ) : (
        <LoaderWithText />
      )}
    </ul>
  );
};
