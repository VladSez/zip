import { TransformedTweet } from "../../../../lib/twitter/types";

import { TweetCardPoll } from "./TweetCardPoll";
import { TweetCardSummary } from "./TweetCardSummary";
import { TweetCardSummaryLarge } from "./TweetCardSummaryLarge";
import { TweetCardVideo } from "./TweetCardVideo";

enum TwitterCards {
  SummaryLarge = "summary_large_image",
  Summary = "summary",
  Player = "player",
}
interface TweetCardsProps {
  tweet: TransformedTweet | null;
}

export const TweetCards = ({ tweet }: TweetCardsProps) => {
  const tweetCardName = tweet?.card?.legacy?.name;
  const hasPoll = tweetCardName?.match(
    /poll[0-9]choice_text_only/,
  );

  return (
    <>
      {tweetCardName === TwitterCards.SummaryLarge ? (
        <TweetCardSummaryLarge card={tweet?.card?.legacy} />
      ) : null}
      {tweetCardName === TwitterCards.Summary ? (
        <TweetCardSummary card={tweet?.card?.legacy} />
      ) : null}
      {tweetCardName === TwitterCards.Player ? (
        <TweetCardVideo card={tweet?.card?.legacy} />
      ) : null}
      {hasPoll ? (
        <TweetCardPoll card={tweet?.card?.legacy} />
      ) : null}
    </>
  );
};
