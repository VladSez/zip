import * as HoverCardPrimitive from "@radix-ui/react-hover-card";
import clsx from "clsx";

import { ExternalLink } from "../../../../components/ExternalLink";
import { TransformedTweet } from "../../../../lib/twitter/types";

import { TweetText } from "../TweetText";
import { TweetAvatar } from "../TweetAvatar";
import { TweetUserMeta } from "../TweetUserMeta";
import { VerifiedIcon } from "../TweetUserName";

interface TweetUser {
  user: TransformedTweet["user"] | undefined;
}

export const TweetCardHover = ({ user }: TweetUser) => {
  return (
    <HoverCardPrimitive.Content
      align="center"
      sideOffset={4}
      className={clsx(
        // " radix-side-top:animate-slide-up radix-side-bottom:animate-slide-down",
        "max-w-md rounded-lg p-4 md:w-full",
        "bg-white shadow-md dark:bg-gray-800",
        "focus:outline-none focus-visible:ring focus-visible:ring-purple-500 focus-visible:ring-opacity-75",
      )}
    >
      <HoverCardPrimitive.Arrow className="fill-current text-white dark:text-gray-800" />

      <div className="flex h-full w-full p-1">
        <div>
          {user?.avatarUrl ? (
            <TweetAvatar user={user} isCardHovered />
          ) : null}
          <ExternalLink
            url={`https://mobile.twitter.com/${user?.screenName}`}
          >
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
              {user?.name}
              {user?.isUserVerified ? (
                <VerifiedIcon />
              ) : null}
            </h3>
          </ExternalLink>
          <span className="text-sm text-gray-600">
            @{user?.screenName}
          </span>
          <TweetText
            text={user?.description}
            className="mt-1 text-sm font-normal text-gray-700 dark:text-gray-400"
            urls={user?.descriptionUrls}
          />
          <TweetUserMeta user={user} />
        </div>
      </div>
    </HoverCardPrimitive.Content>
  );
};
