import dayjs from "dayjs";

import { ExternalLink } from "../../../components/ExternalLink";
import { Tooltip } from "../../../components/Tooltip";
import { TransformedTweet } from "../../../lib/twitter/types";

export const TweetCreatedAtTime = ({
  tweet,
}: {
  tweet: TransformedTweet | null;
}) => {
  const tweetIsMoreThan24HoursOld = dayjs(
    tweet?.createdAt,
  ).isBefore(dayjs().subtract(1, "day"));

  return (
    <ExternalLink url={tweet?.url}>
      <Tooltip
        content={dayjs(tweet?.createdAt).format(
          "DD MMMM YYYY, HH:mm:ss",
        )}
      >
        <time className="cursor-pointer font-normal text-gray-600 transition duration-200 ease-in-out hover:text-gray-800">
          {tweetIsMoreThan24HoursOld
            ? dayjs(tweet?.createdAt).format("MMM D, YYYY")
            : dayjs(tweet?.createdAt).fromNow(true)}
        </time>
      </Tooltip>
    </ExternalLink>
  );
};
