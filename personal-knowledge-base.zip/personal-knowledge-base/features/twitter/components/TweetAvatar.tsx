import * as HoverCardPrimitive from "@radix-ui/react-hover-card";

import { Avatar } from "../../../components/Avatar";
import { ExternalLink } from "../../../components/ExternalLink";

import { TweetUser } from "../types";

import { TweetCardHover } from "./cards/TweetCardHover";

interface TweetAvatarProps extends TweetUser {
  isCardHovered?: boolean;
  width?: number;
  height?: number;
}

export const TweetAvatar = ({
  user,
  isCardHovered = false,
  width = 48,
  height = 48,
}: TweetAvatarProps) => {
  return (
    <HoverCardPrimitive.Root>
      <HoverCardPrimitive.Trigger>
        <ExternalLink
          url={`https://mobile.twitter.com/${user?.screenName}`}
          className="transition-opacity hover:opacity-90"
        >
          <Avatar
            alt={user?.name || ""}
            height={height}
            width={width}
            src={user?.avatarUrl || ""}
          />
        </ExternalLink>
      </HoverCardPrimitive.Trigger>
      {isCardHovered ? null : (
        <TweetCardHover user={user} />
      )}
    </HoverCardPrimitive.Root>
  );
};
