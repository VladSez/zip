import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import useSWRInfinite from "swr/infinite";

import { useBoolean } from "../../hooks/useBoolean";
import { defaultFetcher } from "../../lib/defaultFetcher";
import { TweetFeed } from "./components/TweetFeed";
import { TweetFeedBottomPageLoader } from "./components/TweetFeedBottomPageLoader";
import {
  TransformedTweetNullable,
  TwitterApiResponse,
} from "./types";

const useTwitterLikes = () => {
  const { data, size, setSize, error } =
    useSWRInfinite<TwitterApiResponse>(
      (pageIndex, previousPageData) => {
        // reached the end
        if (previousPageData && !previousPageData.data)
          return null;

        if (pageIndex === 0)
          return `/api/twitter/likes?query=${encodeURIComponent(
            "",
          )}`;
        return `/api/twitter/likes?query=${encodeURIComponent(
          previousPageData?.cursor,
        )}`;
      },
      defaultFetcher,
      {
        refreshInterval: 8000,
      },
    );

  return { data, size, setSize, error };
};

export const TwitterLikesList = () => {
  const {
    value: isFetchingMoreTweets,
    setValue: setFetchingMoreTweets,
  } = useBoolean();

  const { data, size, setSize, error } = useTwitterLikes();

  const { ref, inView } = useInView({
    // adjust if needed
    rootMargin: "1500px",
  });

  useEffect(() => {
    if (inView) {
      setSize((size) => size + 1);
      setFetchingMoreTweets(true);
    } else {
      setFetchingMoreTweets(false);
    }
  }, [inView, setFetchingMoreTweets, setSize]);

  const tweets = data
    ? ([] as TransformedTweetNullable[]).concat(
        ...data.map((x) => x?.data),
      )
    : [];

  return (
    <>
      <TweetFeed tweets={tweets} />
      <TweetFeedBottomPageLoader
        isDataAvailable={Boolean(data && !error)}
        isFetchingMoreTweets={isFetchingMoreTweets}
        size={size}
        setSize={setSize}
        ref={ref}
        setFetchingMoreTweets={setFetchingMoreTweets}
      />
    </>
  );
};
