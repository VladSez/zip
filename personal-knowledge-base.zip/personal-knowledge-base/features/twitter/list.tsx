import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import useSWRInfinite from "swr/infinite";

import { TweetFeed } from "./components/TweetFeed";

import {
  TransformedTweetNullable,
  TwitterApiResponse,
} from "./types";

import { defaultFetcher } from "../../lib/defaultFetcher";

import { useBoolean } from "../../hooks/useBoolean";
import { TweetFeedBottomPageLoader } from "./components/TweetFeedBottomPageLoader";

const useTwitterListById = () => {
  const { data, size, setSize, error } =
    useSWRInfinite<TwitterApiResponse>(
      (pageIndex, previousPageData) => {
        // reached the end
        if (previousPageData && !previousPageData.data)
          return null;

        if (pageIndex === 0)
          return `/api/twitter/listById?query=${encodeURIComponent(
            "",
          )}`;
        return `/api/twitter/listById?query=${encodeURIComponent(
          previousPageData?.cursor,
        )}`;
      },
      defaultFetcher,
      {
        refreshInterval: 8000,
      },
    );

  return { data, size, setSize, error };
};

export const TwitterList = () => {
  // WIP
  // const [activeListId, setActiveListId] = useState();

  const {
    value: isFetchingMoreTweets,
    setValue: setFetchingMoreTweets,
  } = useBoolean();

  // WIP
  // TODO: add types
  // fetching list ids
  // const { data: listIds } = useSWR(
  //   "/api/twitter/lists?query=",
  //   defaultFetcher,
  // );

  // TODO: fetch list by id
  const { data, size, setSize, error } =
    useTwitterListById();

  const { ref, inView } = useInView({
    // adjust if needed
    rootMargin: "1500px",
  });

  useEffect(() => {
    if (inView) {
      setSize((size) => size + 1);
      setFetchingMoreTweets(true);
    }
  }, [inView, setFetchingMoreTweets, setSize]);

  // WIP

  // useEffect(() => {
  //   if (listIds) {
  //     // set default list id
  //     setActiveListId(listIds.data[0]);
  //   }
  // }, [listIds]);

  const tweets = data
    ? ([] as TransformedTweetNullable[]).concat(
        ...data.map((x) => x?.data).filter(Boolean),
      )
    : [];

  if (error) {
    return <pre>{JSON.stringify(error, null, 2)}</pre>;
  }

  return (
    <>
      {/* WIP */}
      {/* <pre>
        {JSON.stringify({ listIds, activeListId }, null, 2)}
      </pre> */}
      {/* <select
        value={activeListId}
        onChange={(e) => setActiveListId(e.target.value)}
      >
        {listIds?.data.map((listId) => (
          <option key={listId} value={listId}>
            {listId}
          </option>
        ))}
      </select> */}
      <TweetFeed tweets={tweets} />

      <TweetFeedBottomPageLoader
        isDataAvailable={Boolean(data && !error)}
        isFetchingMoreTweets={isFetchingMoreTweets}
        size={size}
        setSize={setSize}
        ref={ref}
        setFetchingMoreTweets={setFetchingMoreTweets}
      />
    </>
  );
};
