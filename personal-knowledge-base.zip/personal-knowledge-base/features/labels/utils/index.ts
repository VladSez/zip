export const COLORS = [
  "#ff9093",
  "#faffc2",
  "#ace0fd",
  "#ccf5ba",
  "#baf5ef",
  "#f5baea",
];

export const getDefaultType = (path: string) => {
  if (path === "twitter") {
    return "twitter";
  } else if (path === "github") {
    return "github";
  }
  return "github";
};
