export interface LabelsInterface {
  labels: Array<LabelInterface> | undefined;
}

export interface GithubItem {
  id: string;
  full_name: string;
  description: string;
  stargazers_count: number;
  language: string;
  pushed_at: string;
  type: "github" | "twitter";
  html_url: string;
}

export interface TwitterItem {
  id: string;
  type: "twitter";
}

export interface LabelInterface {
  id: number;
  created_at?: Date;
  updated_at?: Date;
  label: string;
  color: string;
  ids: Array<GithubItem | TwitterItem>; //TODO: add type for twitter
  description?: string;
  type: "github" | "twitter";
}

export interface LabelFormData {
  label: string;
  description?: string;
  color: string;
  type: "github" | "twitter";
}

export interface ActionsProps {
  isDirty?: boolean;
  isSubmitting?: boolean;
  isTheSameColor?: boolean;
}
export interface LabelFormProps {
  actionButtons: ({
    isDirty,
    isSubmitting,
    isTheSameColor,
  }: ActionsProps) => React.ReactNode;
  activeLabel?: LabelInterface | null;
  closeModal: () => void;
}
