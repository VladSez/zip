import { colord, extend, RgbaColor } from "colord";
import { useMemo } from "react";
import namesPlugin from "colord/plugins/names";
import classNames from "classnames";
import { LabelInterface } from "../types";

extend([namesPlugin]);

interface ThreeDots {
  isLightColor: boolean;
}

export const ThreeDots = ({ isLightColor }: ThreeDots) => {
  return (
    <div className="relative inline-flex h-4 w-8 items-center justify-center rounded-lg">
      <i
        className={
          isLightColor ? "bg-gray-900" : "bg-white"
        }
      />
      <i
        className={
          isLightColor ? "bg-gray-900" : "bg-white"
        }
      />
      <i
        className={
          isLightColor ? "bg-gray-900" : "bg-white"
        }
      />
      <style jsx>{`
        i {
          width: 0.25em;
          height: 0.25em;
          border-radius: 50%;
          margin: 0 calc(0.25em / 2 * 0.5);
          display: inline-block;
          animation: loading-blink 1.4s infinite both;
        }
        i:nth-child(2) {
          animation-delay: 0.2s;
        }
        i:nth-child(3) {
          animation-delay: 0.4s;
        }
        @keyframes loading-blink {
          0% {
            opacity: 0.2;
          }
          20% {
            opacity: 1;
          }
          100% {
            opacity: 0.2;
          }
        }
      `}</style>
    </div>
  );
};

export const getBrightness = ({ r, g, b }: RgbaColor) =>
  (r * 299 + g * 587 + b * 114) / 1000;
interface PreviewLabelProps {
  isLoading?: boolean;
  showCloseIcon?: boolean;
  removeLabel?: ({
    selectedLabel,
  }: {
    selectedLabel: LabelInterface;
  }) => Promise<void>;
  label: LabelInterface;
}

export const Label = ({
  isLoading,
  showCloseIcon,
  removeLabel,
  label,
}: PreviewLabelProps) => {
  const rgbaColor = useMemo(() => {
    return label.color?.startsWith("rgba")
      ? label.color
      : colord(label.color).toRgbString();
  }, [label.color]);

  const rgb = colord(rgbaColor).toRgb();
  const isLightColor =
    getBrightness(rgb) > 128 || rgb.a < 0.5;

  return (
    <>
      <div
        className={classNames(
          "relative ml-0 flex w-max cursor-pointer items-center justify-center rounded-lg border border-gray-200 p-1 pl-2 text-sm font-semibold transition duration-300 ease-in-out",
        )}
        style={{ backgroundColor: rgbaColor }}
        title={label.description || ""}
      >
        {isLoading ? (
          <ThreeDots isLightColor={isLightColor} />
        ) : (
          <div
            className={`
            flex
              ${
                isLightColor
                  ? "text-xs text-black"
                  : "text-xs text-white"
              }`}
          >
            <span
              className="mr-1 max-w-[130px] truncate"
              title={label.label || "Preview label"}
            >
              {label.label || "Preview label"}
            </span>
            {showCloseIcon ? (
              <button
                onClick={() => {
                  if (removeLabel) {
                    removeLabel({ selectedLabel: label });
                  }
                }}
                title={`Delete '${label?.label}' label`}
                className="flex h-4 w-4 items-center justify-center rounded-full bg-red-500 shadow-md transition-colors hover:bg-red-600 hover:shadow-inner focus:outline-none focus-visible:ring-2 focus-visible:ring-black"
              >
                <Close />
              </button>
            ) : null}
          </div>
        )}
      </div>
    </>
  );
};

const Close = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-3 w-3 text-white"
      viewBox="0 0 20 20"
      fill="currentColor"
    >
      <path
        fillRule="evenodd"
        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
        clipRule="evenodd"
      />
    </svg>
  );
};
