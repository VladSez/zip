import { Button } from "../../../components/Button";
import { Dialog } from "../../../components/Dialog";
import { useBoolean } from "../../../hooks/useBoolean";
import { LabelForm } from "./LabelForm";

export const AddLabelButton = () => {
  const {
    value: isDialogOpen,
    setTrue: openDialog,
    setFalse: closeDialog,
  } = useBoolean();

  return (
    <>
      <Button
        onClick={() => {
          openDialog();
        }}
        aria-label="Add new label"
      >
        <PlusIcon />
        New
      </Button>
      <Dialog
        isOpen={isDialogOpen}
        closeModal={closeDialog}
        title="Add label"
        body={
          <LabelForm
            closeModal={closeDialog}
            actionButtons={({ isSubmitting }) => {
              return (
                <div className="mt-4 flex justify-end">
                  <button
                    type="button"
                    className="mr-3 inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                    onClick={closeDialog}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="rounded-lg bg-green-500 px-4 py-2 font-semibold text-white shadow-md hover:bg-green-700 focus:outline-none disabled:cursor-not-allowed disabled:bg-opacity-25"
                    disabled={isSubmitting}
                  >
                    Add new label
                  </button>
                </div>
              );
            }}
          />
        }
      />
    </>
  );
};

const PlusIcon = () => {
  return (
    <svg
      width="12"
      height="20"
      fill="currentColor"
      className="mr-1 text-gray-700"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M6 5a1 1 0 011 1v3h3a1 1 0 110 2H7v3a1 1 0 11-2 0v-3H2a1 1 0 110-2h3V6a1 1 0 011-1z"
      ></path>
    </svg>
  );
};
