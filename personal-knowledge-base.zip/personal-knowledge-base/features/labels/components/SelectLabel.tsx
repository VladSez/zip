// import { useRouter } from "next/dist/client/router";
import { toast } from "react-toastify";
import { useLabels } from "../../../hooks/useLabels";
import { defaultFetcher } from "../../../lib/defaultFetcher";
import { Label } from "./Label";
import { Select } from "./Select";
import {
  GithubItem,
  LabelInterface,
  TwitterItem,
} from "../types";
// import { mutate as globalMutate } from "swr";
import { useRouterQuery } from "../../../hooks/useRouterQuery";
import { useMemo } from "react";
import classNames from "classnames";

const defaultLabel = {
  id: Math.random() * 1000,
  label: "Assign label",
  color: "white",
  description: "Add new label",
  ids: [],
  created_at: new Date(),
  updated_at: new Date(),
  type: "github" as "github",
};

interface CommonProps {
  id: string;
}

type ItemProps =
  | { type: "twitter"; itemToBeSaved: any } // TODO: fix type
  | { type: "github"; itemToBeSaved: GithubItem };

type Props = CommonProps & ItemProps;

export const SelectLabel = ({
  id, // TODO: remove id, because now we have it in `itemToBeSaved`
  itemToBeSaved,
}: Props) => {
  const { data, mutate } = useLabels();
  // const router = useRouter();
  const {
    // queryId,
    rootPathOfThePage,
    // isTwitterPage,
    // isGithubPage,
    // prevPageParam,
  } = useRouterQuery();

  const selectedLabels = useMemo(
    () =>
      data?.labels?.filter((label) =>
        label.ids?.find((x) => x.id === String(id)),
      ),
    [data?.labels, id],
  );

  const removeLabel = async ({
    selectedLabel,
  }: {
    selectedLabel: LabelInterface;
  }) => {
    const selectedLabelIds = selectedLabel?.ids
      ? [...selectedLabel.ids]
      : [];

    try {
      await defaultFetcher("/api/manage-labels", {
        method: "PUT",
        body: JSON.stringify({
          id: selectedLabel?.id,
          ids: selectedLabelIds.filter((x) => x.id !== id),
          color: selectedLabel?.color,
          label: selectedLabel?.label,
          description: selectedLabel?.description,
          type: selectedLabel?.type,
        }),
      });

      mutate({
        ...data,
        labels: data?.labels?.map((el) =>
          el.id === selectedLabel.id
            ? {
                ...el,
                ids: selectedLabelIds.filter(
                  (x) => x.id !== id,
                ),
              }
            : el,
        ),
      });

      // TODO: double check this
      // UPD: this functionality is not used anymore

      // if (router.query.id) {
      //   const url = `/api/filter-labels?id=${
      //     router.query.id
      //   }&from=${router.query.from || 0}&to=${
      //     router.query.to || 10
      //   }`;

      //   // revalidate filter-label,
      //   // when deleting label
      //   await globalMutate(url);

      //   // TODO:
      //   // MAYBE RESET LAGGY DATA(this method exists in middleware),
      //   // WHEN REMOVING LABEL?

      //   const query = queryId.filter(
      //     (id) => id !== `id.eq.${selectedLabel.id}`,
      //   );

      //   const filterIsEmpty = query.length === 0;

      //   // update url, when deleting label
      //   if (filterIsEmpty) {
      //     // if filter is empty, redirect to the page you came from
      //     router.push(
      //       isTwitterPage
      //         ? `/twitter/${router.query.prevPage}`
      //         : router.pathname,
      //       undefined,
      //       { shallow: true },
      //     );
      //   }
      //   // means that current label has latest 'labelled' item
      //   // (remove label id from url and redirect to first page)
      //   if (selectedLabel?.ids.length === 1) {
      //     const query = queryId.filter(
      //       (id) => id !== `id.eq.${selectedLabel.id}`,
      //     );

      //     // removing one filter from url(push to the first page)
      //     router.push(
      //       {
      //         pathname: router.pathname,
      //         query: {
      //           // this is only needed for twitter page
      //           ...(isTwitterPage && {
      //             prevPage: prevPageParam,
      //           }),
      //           // this is only needed for github page
      //           ...(isGithubPage && {
      //             tabId: 2,
      //           }),
      //           id: query.toString(),
      //           from: router.query.from,
      //           to: router.query.to,
      //         },
      //       },
      //       undefined,
      //       { shallow: true },
      //     );
      //   }
      // }

      toast.success(
        `Label '${selectedLabel.label}' was removed!`,
        {
          icon: "🚀",
        },
      );
    } catch (e) {
      if (e instanceof Error) {
        console.error(e);
        toast.error(e?.message);
      }
    }
  };

  const attachLabelToItem = async ({
    selectedLabel,
    itemToBeSaved,
  }: {
    selectedLabel: LabelInterface;
    itemToBeSaved: GithubItem | TwitterItem;
  }) => {
    const selectedLabelIds = selectedLabel?.ids
      ? [...selectedLabel.ids]
      : [];

    try {
      await defaultFetcher("/api/manage-labels", {
        method: "PUT",
        body: JSON.stringify({
          id: selectedLabel?.id,
          ids: [...selectedLabelIds, itemToBeSaved],
          color: selectedLabel?.color,
          label: selectedLabel?.label,
          description: selectedLabel?.description,
          type: selectedLabel?.type,
        }),
      });

      // in mutate here, we add a new label
      mutate({
        ...data,
        labels: data?.labels?.map((label) => {
          return label?.id === selectedLabel?.id
            ? {
                ...label,
                ids: [...selectedLabelIds, itemToBeSaved],
              }
            : label;
        }),
      });

      toast.success(
        `Label '${selectedLabel.label}' was assigned!`,
        {
          icon: "🚀",
        },
      );
    } catch (e) {
      if (e instanceof Error) {
        console.error(e);
        toast.error(e?.message);
      }
    }
  };

  const handleSelectChange = (label: LabelInterface) => {
    attachLabelToItem({
      selectedLabel: label,
      itemToBeSaved,
    });
  };

  // TODO: not sure if this is the best way to do this
  // if (!data) {
  //   return (
  //     <div className="flex items-center">
  //       <div className="w-36 h-[24px] m-1 bg-gray-300 rounded-2xl animate-pulse-fast"></div>
  //     </div>
  //   );
  // }

  const filteredOptions = data?.labels?.filter((label) => {
    const labelIsApplied = selectedLabels?.find(
      (selectedLabel) => selectedLabel.id === label.id,
    );

    // do not show already applied labels in select options
    if (labelIsApplied) {
      return false;
    }
    // TODO: refactor?
    // shows 'twitter' or 'github' labels
    // depends on which route you are
    return label.type === rootPathOfThePage;
  });
  return (
    <div className={classNames("flex flex-wrap")}>
      <div className="m-1 ml-0">
        <Select
          selectedLabel={defaultLabel}
          isLoading={false}
          handleSelectChange={handleSelectChange}
          options={filteredOptions}
        />
      </div>
      {selectedLabels?.map((label) => {
        return (
          <div className="m-1" key={label.id}>
            <Label
              label={label}
              showCloseIcon
              removeLabel={removeLabel}
              // isLoading={isLoading}
            />
          </div>
        );
      })}
    </div>
  );
};
