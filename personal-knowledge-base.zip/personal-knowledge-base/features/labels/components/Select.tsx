import { Listbox, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { Label } from "./Label";
import { LabelInterface } from "../types";
import clsx from "clsx";
import { isNonEmptyArray } from "../../../utils/isNotEmptyArray";

interface SelectProps {
  handleSelectChange: (label: LabelInterface) => void;
  isLoading: boolean;
  selectedLabel: LabelInterface;
  options: Array<LabelInterface> | undefined;
}

export const Select = ({
  options,
  isLoading,
  handleSelectChange,
  selectedLabel,
}: SelectProps) => {
  const hasOptions = options && isNonEmptyArray(options);

  return (
    <Listbox
      value={selectedLabel}
      onChange={handleSelectChange}
    >
      <div>
        <Listbox.Button className="relative flex items-center gap-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-black">
          <Label
            label={selectedLabel}
            isLoading={isLoading}
          />
        </Listbox.Button>
        <Transition
          as={Fragment}
          leave="transition ease-in duration-100"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <Listbox.Options className="absolute z-20 mt-1 max-h-56 w-max max-w-max overflow-auto rounded-md bg-white text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm md:w-48">
            {hasOptions ? (
              options.map((label) => (
                <Listbox.Option
                  key={label.label}
                  className={({ active }) =>
                    clsx(
                      "relative block w-full cursor-pointer select-none p-1 py-0.5",
                      {
                        "bg-indigo-100 text-white": active,
                      },
                    )
                  }
                  value={label}
                >
                  <div className="block w-full p-2">
                    <Label label={label} />
                  </div>
                </Listbox.Option>
              ))
            ) : (
              <div className="block w-full p-2">
                No labels
              </div>
            )}
          </Listbox.Options>
        </Transition>
      </div>
    </Listbox>
  );
};
