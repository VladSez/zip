import { colord } from "colord";
import React, {
  Dispatch,
  SetStateAction,
  useCallback,
  useMemo,
  useRef,
} from "react";
import { RgbaStringColorPicker } from "react-colorful";
import useOnClickOutside from "use-onclickoutside";
import { useBoolean } from "../../../hooks/useBoolean";

interface ColorPickerProps {
  onChange: Dispatch<SetStateAction<string>>;
  color: string;
}

export const ColorPicker = ({
  color,
  onChange,
}: ColorPickerProps) => {
  const popover = useRef<HTMLDivElement>(null);

  const { value: isOpen, setValue: setOpen } = useBoolean();

  const close = useCallback(
    () => setOpen(false),
    [setOpen],
  );

  const rgbaColor = useMemo(() => {
    return color.startsWith("rgba")
      ? color
      : colord(color).toRgbString();
  }, [color]);

  useOnClickOutside(popover, close);

  return (
    <div className="relative mt-2 ml-1">
      <div
        className="h-8 w-8 cursor-pointer rounded-md border-2 border-white drop-shadow"
        style={{ backgroundColor: rgbaColor }}
        onClick={() => setOpen(true)}
      />

      {isOpen && (
        <div
          className="absolute -left-16 bottom-8 sm:bottom-8 sm:left-8"
          ref={popover}
        >
          <RgbaStringColorPicker
            color={rgbaColor}
            onChange={onChange}
          />
        </div>
      )}
    </div>
  );
};
