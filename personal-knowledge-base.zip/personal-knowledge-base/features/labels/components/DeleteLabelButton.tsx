import { toast } from "react-toastify";
import { Button } from "../../../components/Button";
import { Dialog } from "../../../components/Dialog";
import { useBoolean } from "../../../hooks/useBoolean";
import { useLabels } from "../../../hooks/useLabels";
import { defaultFetcher } from "../../../lib/defaultFetcher";
import { LabelInterface } from "../types";

interface DeleteLabelButtonProps {
  activeLabel: LabelInterface | null;
  onClick: () => void;
}

export const DeleteLabelButton = ({
  activeLabel,
  onClick,
}: DeleteLabelButtonProps) => {
  const { data, mutate } = useLabels();

  const {
    value: isDialogOpen,
    setTrue: openDialog,
    setFalse: closeDialog,
  } = useBoolean();

  const deleteLabel = async (el: LabelInterface) => {
    try {
      await defaultFetcher("/api/manage-labels", {
        method: "DELETE",
        body: JSON.stringify({
          id: el?.id,
        }),
      });

      const filtered = data?.labels?.filter(
        (x) => x.id !== el?.id,
      );

      if (filtered) {
        mutate({
          ...data,
          labels: filtered,
        });
      }
      toast.success(
        `Successfully deleted '${el?.label}' label`,
        {
          icon: "🚀",
        },
      );
    } catch (e) {
      if (e instanceof Error) {
        toast.error(e?.message);
      }
    } finally {
      closeDialog();
    }
  };
  return (
    <>
      <Button
        onClick={() => {
          openDialog();
          onClick();
        }}
      >
        Delete
      </Button>
      <Dialog
        isOpen={isDialogOpen}
        closeModal={closeDialog}
        title="Confirm delete"
        body={
          <>
            <div className="mt-4 mb-8">
              <p className="text-sm text-gray-600">
                {`Are you sure you want to delete '${activeLabel?.label}' label?`}
              </p>
            </div>
            <div className="mt-4 flex justify-end">
              <button
                type="button"
                className="mr-3 inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                onClick={closeDialog}
              >
                Cancel
              </button>
              <button
                type="button"
                className="rounded-lg bg-red-500 px-4 py-2 font-semibold text-white shadow-md hover:bg-red-700 focus:outline-none"
                onClick={() => {
                  if (activeLabel) {
                    deleteLabel(activeLabel);
                  }
                }}
              >
                Delete
              </button>
            </div>
          </>
        }
      />
    </>
  );
};
