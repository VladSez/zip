import cn from "classnames";
import { random } from "colord";
import React, { useState } from "react";
import { HexColorInput } from "react-colorful";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { Button } from "../../../components/Button";
import { useLabels } from "../../../hooks/useLabels";
import { useRouterQuery } from "../../../hooks/useRouterQuery";
import { defaultFetcher } from "../../../lib/defaultFetcher";
import { ColorPicker } from "./ColorPicker";
import { Label } from "./Label";
import { LabelFormData, LabelFormProps } from "../types";
import { COLORS, getDefaultType } from "../utils";

export const LabelForm = ({
  actionButtons,
  activeLabel,
  closeModal,
}: LabelFormProps) => {
  const { data, mutate } = useLabels();

  const defaultColor = COLORS[
    Math.floor(Math.random() * COLORS.length)
  ] as string;

  const { rootPathOfThePage, isTwitterPage, isGithubPage } =
    useRouterQuery();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isDirty, isSubmitting },
  } = useForm<LabelFormData>({
    defaultValues: {
      label: activeLabel?.label || "",
      description: activeLabel?.description || "",
      color: defaultColor,
      type: activeLabel?.type
        ? activeLabel.type
        : getDefaultType(rootPathOfThePage || ""),
    },
  });

  const [activeColor, setColor] = useState(
    activeLabel?.color || defaultColor,
  );

  const onSubmit = async (input: LabelFormData) => {
    // edit label
    if (activeLabel) {
      try {
        await defaultFetcher("/api/manage-labels", {
          method: "PUT",
          body: JSON.stringify({
            id: activeLabel?.id,
            label: input?.label,
            description: input?.description,
            color: activeColor,
            ids: Array.isArray(activeLabel?.ids)
              ? [...activeLabel?.ids]
              : [],
            type: input?.type,
          }),
        });

        if (data) {
          mutate({
            ...data,
            labels: data?.labels?.map((x) =>
              x.id === activeLabel.id
                ? {
                    ...x,
                    color: activeColor,
                    description: input?.description,
                    label: input?.label,
                    type: input?.type,
                  }
                : x,
            ),
          });
        }
        toast.success(
          `Label '${activeLabel.label}' is updated!`,
          {
            icon: "🚀",
          },
        );
        closeModal();
      } catch (e) {
        if (e instanceof Error) {
          toast.error(e?.message);
        }
      }
    } else {
      // add label
      try {
        await defaultFetcher("/api/manage-labels", {
          method: "POST",
          body: JSON.stringify({
            label: input?.label,
            description: input?.description,
            color: activeColor,
            type: input?.type,
          }),
        });
        if (data && data.labels) {
          mutate({
            ...data,
            labels: [
              ...data.labels,
              {
                color: activeColor,
                created_at: new Date(),
                description: input?.description,
                id: Math.random() * 1000,
                ids: [],
                label: input?.label,
                updated_at: new Date(),
                type: input?.type,
              },
            ],
          });

          toast.success("New label is saved!", {
            icon: "🚀",
          });
        }
        closeModal();
      } catch (e) {
        if (e instanceof Error) {
          toast.error(e?.message);
        }
      }
    }
  };

  const labelName = watch("label");
  const description = watch("description");

  const isTheSameColor = activeColor === activeLabel?.color;

  const previewLabel = {
    id: Math.random() * 1000,
    color: activeColor,
    label: labelName,
    description,
    ids: [],
    type: "github" as "github",
  };

  return (
    <>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className=""
        id="form1"
      >
        <div className="my-2 flex items-center">
          <span className="mr-2">Preview:</span>
          <Label label={previewLabel} />
        </div>
        <div className="my-4">
          <div className="relative my-6">
            <label htmlFor="label">Label Name</label>
            <input
              {...register("label", {
                required: "field is required",
                validate: (value) => {
                  const duplicateNames =
                    data?.labels?.filter(
                      (x) => x.label === value,
                    );

                  const allowEditedNameToBeSubmitted =
                    activeLabel?.label === value;

                  const isNotDuplicate =
                    duplicateNames?.length === 0;

                  return (
                    isNotDuplicate ||
                    allowEditedNameToBeSubmitted ||
                    "name already exists"
                  );
                },
              })}
              id="label"
              placeholder="Label Name (required)"
              autoComplete="off"
              className={cn(
                "mt-2 block w-full rounded-md border border-gray-300 p-2 px-3 shadow-sm sm:text-sm ",
                {
                  "border-red-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-300":
                    errors?.label?.message,
                },
              )}
            />
            <span className="absolute text-sm text-red-500">
              {errors?.label?.message}
            </span>
          </div>
          <div className="my-6 ">
            <label htmlFor="description">Description</label>
            <input
              {...register("description")}
              id="description"
              autoComplete="off"
              placeholder="Description (optional)"
              className="mt-2 block w-full rounded-md border border-gray-300 p-2 px-3 shadow-sm sm:text-sm"
            />
          </div>
          <div className="my-6 flex flex-col">
            <label htmlFor="color">Color:</label>
            <div className="flex items-center">
              <HexColorInput
                color={activeColor}
                onChange={(e) => {
                  setColor(e);
                }}
                prefixed
                id="color"
                className="mt-2 block w-24 rounded-md border border-gray-300 p-2 px-3 shadow-sm sm:text-sm"
              />
              <ColorPicker
                color={activeColor}
                onChange={setColor}
              />
              <Button
                className="mt-2"
                onClick={() =>
                  setColor(random().lighten(0.3).toHex())
                }
              >
                Random color
              </Button>
            </div>
            <div className="mt-2 flex">
              {COLORS.map((color) => (
                <button
                  key={color}
                  type="button"
                  style={{ backgroundColor: color }}
                  className={cn("m-1 h-8 w-8 rounded-md", {
                    "border-2 border-black":
                      activeColor === color,
                  })}
                  onClick={() => {
                    setColor(color);
                  }}
                ></button>
              ))}
            </div>
          </div>
          <fieldset>
            <legend>Type:</legend>

            <div className="flex items-center py-1">
              <input
                {...register("type", {
                  required: "type is required",
                })}
                onChange={() => {
                  // TODO: this is a workaround,
                  // because of some strange behavior with radio input default value?
                  setValue("type", "github", {
                    shouldDirty: true,
                  });
                }}
                type="radio"
                value="github"
                id="githubLabel"
                disabled={isTwitterPage}
              />

              <label
                className={cn(
                  "relative bottom-[3px] ml-1",
                  {
                    "opacity-50": isTwitterPage,
                  },
                )}
                htmlFor="githubLabel"
              >
                github
              </label>
            </div>
            <div className="flex items-center py-1">
              <input
                {...register("type", {
                  required: "type is required",
                })}
                onChange={() => {
                  // TODO: this is a workaround,
                  // because of some strange behavior with radio input default value?
                  setValue("type", "twitter", {
                    shouldDirty: true,
                  });
                }}
                type="radio"
                value="twitter"
                id="twitterLabel"
                disabled={isGithubPage}
              />
              <label
                className={cn(
                  "relative bottom-[3px] ml-1",
                  {
                    "opacity-50": isGithubPage,
                  },
                )}
                htmlFor="twitterLabel"
              >
                twitter
              </label>
            </div>
            <span className="absolute text-sm text-red-500">
              {errors?.type?.message}
            </span>
          </fieldset>
        </div>

        <div className="mt-12">
          {actionButtons({
            isDirty,
            isSubmitting,
            isTheSameColor,
          })}
        </div>
      </form>
    </>
  );
};
