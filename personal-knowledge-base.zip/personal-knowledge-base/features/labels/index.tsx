import { useState } from "react";
import { Header } from "../../components/Header";
import { LoaderWithText } from "../../components/Loader";
import { ScreenReader } from "../../components/ScreenReader";
import { useLabels } from "../../hooks/useLabels";
import { isNonEmptyArray } from "../../utils/isNotEmptyArray";
import { AddLabelButton } from "./components/AddLabelButton";
import { DeleteLabelButton } from "./components/DeleteLabelButton";
import { EditLabelButton } from "./components/EditLabelButton";
import { Label } from "./components/Label";
import { LabelInterface } from "./types";

export const LabelsList = () => {
  const { data } = useLabels();

  const [activeLabel, setLabel] =
    useState<LabelInterface | null>(null);

  if (!data) {
    return (
      <div className="mt-24 flex h-[101vh] flex-col justify-start">
        <LoaderWithText />
      </div>
    );
  }

  const hasLabels =
    data?.labels && isNonEmptyArray(data.labels);

  return (
    <div className="h-screen w-full max-w-full">
      <div className="mt-4 flex flex-col sm:m-4 sm:ml-0">
        <div className="flex">
          <Header>Labels</Header>
          <AddLabelButton />
        </div>

        <div className="mt-5 mb-10 w-full overflow-hidden rounded-lg shadow-md">
          <div className="w-full overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
                  >
                    Label
                  </th>
                  {/* <th
                    scope="col"
                    className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase"
                  >
                    Description
                  </th> */}
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
                  >
                    Type
                  </th>
                  <th
                    scope="col"
                    className="relative px-6 py-3"
                  >
                    <ScreenReader>Edit</ScreenReader>
                  </th>
                  <th
                    scope="col"
                    className="relative px-6 py-3"
                  >
                    <ScreenReader>Delete</ScreenReader>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {hasLabels ? (
                  data?.labels?.map((label) => (
                    <tr key={label.id}>
                      <td className="whitespace-nowrap px-6 py-4">
                        <Label label={label} />
                      </td>
                      {/* <td className="px-6 py-4 whitespace-nowrap">
                        <p className="text-left whitespace-pre-wrap">
                          {label?.description}
                        </p>
                      </td> */}
                      <td className="whitespace-nowrap px-6 py-4">
                        <p className="whitespace-pre-wrap text-left">
                          {label?.type}
                        </p>
                      </td>
                      <td className="p-2 text-center">
                        <EditLabelButton
                          activeLabel={activeLabel}
                          onClick={() => setLabel(label)}
                        />
                      </td>

                      <td className="p-2 text-center">
                        <DeleteLabelButton
                          activeLabel={activeLabel}
                          onClick={() => setLabel(label)}
                        />
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="p-2">No labels</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
