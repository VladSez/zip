import {
  NotificationEvents,
  NotificationResponseItem,
} from "../types";

export const FILTERS = {
  [NotificationEvents.All]: (x: NotificationResponseItem) =>
    x,
  [NotificationEvents.Issue]: (
    x: NotificationResponseItem,
  ) => x?.subject?.type === NotificationEvents.Issue,
  [NotificationEvents.PullRequest]: (
    x: NotificationResponseItem,
  ) => x?.subject?.type === NotificationEvents.PullRequest,
  [NotificationEvents.Release]: (
    x: NotificationResponseItem,
  ) => x?.subject?.type === NotificationEvents.Release,
  [NotificationEvents.Discussion]: (
    x: NotificationResponseItem,
  ) => x?.subject?.type === NotificationEvents.Discussion,
} as const;

export const DEFAULT_PAGE = "1";
