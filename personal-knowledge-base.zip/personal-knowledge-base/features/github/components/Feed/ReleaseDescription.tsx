import { StarredByUsersResponseItem } from "../../types";
import { getFeedReleaseUrl } from "../../utils";
import { GithubHtmlRenderer } from "../common/HtmlRenderer";

interface ReleaseDescriptionProps {
  release: any;
  item: StarredByUsersResponseItem;
}
export const ReleaseDescription = ({
  item,
  release,
}: ReleaseDescriptionProps) => {
  return (
    <div className="my-4 whitespace-normal py-2 text-left text-sm">
      <h4 className="mb-2">
        <a
          href={getFeedReleaseUrl(item)}
          className="font-bold text-blue-600 hover:text-blue-800"
          target="_blank"
          rel="noopener noreferrer"
        >
          {release?.tag_name}
        </a>
      </h4>
      <GithubHtmlRenderer
        html={release.short_description_html}
      />
      {release?.is_short_description_html_truncated ? (
        <a
          href={getFeedReleaseUrl(item)}
          className="mt-2 inline-block text-blue-600 hover:text-blue-900"
          target="_blank"
          rel="noopener noreferrer"
        >
          Read more
        </a>
      ) : null}
    </div>
  );
};
