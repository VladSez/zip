import { ExternalLink } from "../../../../components/ExternalLink";
import {
  FeedItemType,
  StarredByUsersResponseItem,
} from "../../types";
import { getFeedDefaultUrl } from "../../utils";
import { GithubMeta } from "../common/GithubMeta";
import { Text } from "../common/Text";

interface DefaultDescriptionProps {
  data: FeedItemType;
  item: StarredByUsersResponseItem;
}
export const DefaultDescription = ({
  data,
  item,
}: DefaultDescriptionProps) => {
  return (
    <>
      <ExternalLink url={getFeedDefaultUrl(item)}>
        {data?.full_name}
      </ExternalLink>
      <Text>{data?.description}</Text>
      <footer className="mt-6">
        <GithubMeta
          starCount={data?.stargazers_count}
          language={data?.language}
          updatedAt={data?.pushed_at}
        />
      </footer>
    </>
  );
};
