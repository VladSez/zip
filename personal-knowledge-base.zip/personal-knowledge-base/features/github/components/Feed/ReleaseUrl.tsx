interface ReleaseUrlProps {
  tagName: string;
  repoName: string;
  releaseRrl: string;
  defaultUrl: string;
}

export const ReleaseUrl = ({
  tagName,
  repoName,
  releaseRrl,
  defaultUrl,
}: ReleaseUrlProps) => {
  return (
    <>
      <a
        href={releaseRrl}
        className="font-medium text-gray-900 hover:text-blue-600"
        target="_blank"
        rel="noopener noreferrer"
      >
        {tagName}
      </a>
      <span className="font-normal"> of</span>{" "}
      <a
        href={defaultUrl}
        className="font-medium text-gray-900 hover:text-blue-600"
        target="_blank"
        rel="noopener noreferrer"
      >
        {repoName}
      </a>
    </>
  );
};
