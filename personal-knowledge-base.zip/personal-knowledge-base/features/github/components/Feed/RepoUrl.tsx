interface RepoUrlProps {
  repoName: string;
  defaultUrl: string;
}

export const RepoUrl = ({
  repoName,
  defaultUrl,
}: RepoUrlProps) => {
  return (
    <a
      href={defaultUrl}
      className="break-words font-medium text-gray-900 hover:text-blue-600"
      target="_blank"
      rel="noopener noreferrer"
    >
      {repoName}
    </a>
  );
};
