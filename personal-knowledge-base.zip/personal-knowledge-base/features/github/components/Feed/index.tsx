import { useRouter } from "next/dist/client/router";
import useSWR from "swr";
import { LoaderWithText } from "../../../../components/Loader";
import { Pagination } from "../../../../components/Pagination";
import { requestWithAuth } from "../../../../lib/github";
import { DEFAULT_PAGE } from "../../constants";
import {
  RECEIVED_EVENT,
  StarredByUsersResponse,
} from "../../types";
import { FeedItem } from "./FeedItem";

const GITHUB_USER_NAME = "VladSez";

export const useGithubFeed = () => {
  const router = useRouter();
  const page =
    (router.query.page as string) || DEFAULT_PAGE;

  const {
    data: { data } = {},
    error,
    mutate,
  } = useSWR<StarredByUsersResponse>(
    ["GET /users/{username}/received_events", page],
    () =>
      requestWithAuth(
        "GET /users/{username}/received_events",
        {
          page: Number(page),
          username: GITHUB_USER_NAME,
        },
      ),
  );

  return { data, error, mutate };
};

export const Feed = () => {
  const { data, error } = useGithubFeed();

  if (error) {
    console.error(error);
    return <pre>{JSON.stringify({ error }, null, 2)}</pre>;
  }

  if (!data) {
    return (
      <div className="mt-10 flex flex-col items-center justify-start sm:h-screen">
        <LoaderWithText />
      </div>
    );
  }

  return (
    <>
      <Pagination />

      <ul role="list">
        {data?.map((item) => {
          // TODO: don't know yet how to handle this event :)
          if (item.type === RECEIVED_EVENT.MemberEvent) {
            return null;
          }
          // TODO: fix
          // @ts-expect-error
          const release = item?.payload?.release;

          return (
            <FeedItem
              item={item}
              release={release}
              key={item.id}
            />
          );
        })}
      </ul>
      <div className="m-3 my-5 flex cursor-pointer rounded-md bg-gray-100 p-3 text-sm text-gray-700">
        <BulbIcon />
        <p className="text-sm text-gray-700">
          <span className="font-bold">Pro tip: </span>
          The feed shows you events from people you follow
          and repositories you watch or star.
        </p>
      </div>
      <div className="mt-6 mb-10">
        <Pagination shouldScrollToTop />
      </div>
    </>
  );
};

const BulbIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="mr-[2px] h-6 w-6 pb-1"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
      />
    </svg>
  );
};
