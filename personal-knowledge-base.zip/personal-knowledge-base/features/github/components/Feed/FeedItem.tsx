import useSWRImmutable from "swr/immutable";
import { LoaderWithText } from "../../../../components/Loader";
import { requestWithAuth } from "../../../../lib/github";
import {
  RECEIVED_EVENT,
  StarredByUsersResponseItem,
  ReleaseType,
  FeedItemType,
} from "../../types";
import {
  formatFeedReceivedEventType,
  getFeedDefaultUrl,
  getFeedReleaseUrl,
  getFeedUserUrl,
} from "../../utils";
import { List } from "../common/List";
import { TimeAgo } from "../common/TimeAgo";
import { DefaultDescription } from "./DefaultDescription";
import { ReleaseDescription } from "./ReleaseDescription";
import { ReleaseUrl } from "./ReleaseUrl";
import { RepoUrl } from "./RepoUrl";
import { UserUrl } from "./UserUrl";
import { Avatar } from "../../../../components/Avatar";
import { Tooltip } from "../../../../components/Tooltip";

const useGithubFeedItem = (url: string | undefined) => {
  const { data: { data } = {}, error } =
    useSWRImmutable<FeedItem>(
      url ? url : null,
      requestWithAuth,
      {
        onError: (error, key) => {
          console.error({ error, key });
        },
      },
    );

  return { data, error };
};

interface FeedItemProps {
  release: ReleaseType;
  item: StarredByUsersResponseItem;
}

interface FeedItem {
  data: FeedItemType;
}

export const FeedItem = ({
  release,
  item,
}: FeedItemProps) => {
  const { data, error } = useGithubFeedItem(
    item?.repo?.url,
  );

  if (error) {
    return null;
  }

  if (!data) {
    return (
      <div className="my-10 flex flex-col items-center justify-start sm:h-screen">
        <LoaderWithText />
      </div>
    );
  }

  return (
    <li
      className="my-3 mb-0 flex border-t border-b border-gray-300 p-4 pb-0 sm:rounded-2xl sm:border"
      key={item?.id}
    >
      <aside className="min-w-[40px]">
        <Tooltip
          content={`Click to open ${item.actor.login}'s stars page`}
        >
          <a
            href={`https://github.com/${item.actor.login}?tab=stars`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Avatar
              src={item.actor.avatar_url}
              alt={`Picture of ${item?.actor?.display_login}`}
              width={35}
              height={35}
            />
          </a>
        </Tooltip>
      </aside>
      <section className="mt-2 ml-2 w-[calc(100%-40px)]">
        <header>
          <List>
            <li className="text-left text-xs">
              <UserUrl
                userName={item.actor.login}
                userUrl={getFeedUserUrl(item)}
              />
              <span className="text-gray-600">
                {formatFeedReceivedEventType(item?.type)}{" "}
              </span>
              {item.type === RECEIVED_EVENT.ReleaseEvent ? (
                <ReleaseUrl
                  releaseRrl={getFeedReleaseUrl(item)}
                  defaultUrl={getFeedDefaultUrl(item)}
                  tagName={release.tag_name}
                  repoName={item.repo.name}
                />
              ) : (
                <RepoUrl
                  defaultUrl={getFeedDefaultUrl(item)}
                  repoName={item.repo.name}
                />
              )}
              {" · "}
              <TimeAgo time={item?.created_at} />
            </li>
          </List>
        </header>
        <section className="my-4">
          {release?.short_description_html ? (
            <ReleaseDescription
              release={release}
              item={item}
            />
          ) : (
            <DefaultDescription data={data} item={item} />
          )}
        </section>
      </section>
    </li>
  );
};
