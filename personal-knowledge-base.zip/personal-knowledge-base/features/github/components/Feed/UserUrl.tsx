interface UserUrlProps {
  userName: string;
  userUrl: string;
}

export const UserUrl = ({
  userName,
  userUrl,
}: UserUrlProps) => {
  return (
    <a
      href={userUrl}
      className="font-medium text-gray-900 hover:text-blue-600"
      target="_blank"
      rel="noopener noreferrer"
    >
      {userName}{" "}
    </a>
  );
};
