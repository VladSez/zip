import clsx from "clsx";
import { useRouter } from "next/router";

import { Tooltip } from "../../../../components/Tooltip";
import { useGithubNotificationsManager } from "./hooks/useGithubNotificationsManager";

interface NotificationCountProps {
  onClick?: () => void;
  className?: string;
}

export const NotificationCount = ({
  onClick,
  className,
}: NotificationCountProps) => {
  const router = useRouter();

  const { updateStaleData, notifications } =
    useGithubNotificationsManager();

  const notificationCount = notifications?.length || 0;

  return (
    <Tooltip
      content={`${notificationCount} new notifications`}
    >
      <button
        onClick={async (e) => {
          // closes the menu on mobile navigation
          onClick && onClick();

          // prevents `Collapsible` to collapse,
          // when clicking on the notification count
          e.stopPropagation();

          // updates github notifications count
          await updateStaleData();

          // redirect
          router.replace(
            "/github?tab=Notifications&filterBy=All&page=1",
          );
        }}
        className={clsx(
          "flex h-5 w-5 cursor-pointer items-center justify-center rounded-full bg-blue-500 text-xs font-normal text-white",
          className,
        )}
      >
        {notificationCount}
      </button>
    </Tooltip>
  );
};
