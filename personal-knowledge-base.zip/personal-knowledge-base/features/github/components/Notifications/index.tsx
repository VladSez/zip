import { useRouter } from "next/dist/client/router";

import { ButtonGroup } from "../../../../components/ButtonGroup";
import { LoaderWithText } from "../../../../components/Loader";
import { Pagination } from "../../../../components/Pagination";
import { NotificationItem } from "./NotificationItem";

import { FILTERS } from "../../constants";
import { Filters, NotificationEvents } from "../../types";
import { NotificationEventsAndCommit } from "../common/Badge";
import { FilterByButton } from "../common/FilterByButton";

import { useGithubNotificationsManager } from "./hooks/useGithubNotificationsManager";
import { isNonEmptyArray } from "../../../../utils/isNotEmptyArray";

export const Notifications = () => {
  const router = useRouter();

  let {
    error,
    areNotificationsStale,
    updateStaleData,
    cache, // TODO: fix types
  } = useGithubNotificationsManager();

  if (error) {
    console.error(error);
    return <pre>{JSON.stringify({ error }, null, 2)}</pre>;
  }

  if (!cache) {
    return (
      <div className="mt-10 flex flex-col items-center justify-start sm:h-screen">
        <LoaderWithText />
      </div>
    );
  }

  const filterCallback =
    FILTERS[
      (router.query.filterBy as Filters) ||
        NotificationEvents.All
    ];

  const dataFilteredByNotificationEvent =
    cache.filter(filterCallback);

  return (
    <>
      <p className="text-center">Filter by:</p>
      <ButtonGroup
        className="flex flex-wrap items-center justify-center p-2"
        ariaLabel="filter options for notifications"
      >
        {(
          Object.values(NotificationEvents) as Array<
            keyof typeof NotificationEvents
          >
        ).map((eventType) => {
          return (
            <FilterByButton
              key={eventType}
              filterBy={eventType}
              queryKey="filterBy"
            />
          );
        })}
      </ButtonGroup>
      {areNotificationsStale ? (
        <div className="my-2 rounded-xl border border-gray-200 p-4">
          <p className="text-xl font-bold text-yellow-500">
            Stale cache data!
          </p>
          <button onClick={updateStaleData}>
            Click to update stale cache data
          </button>
        </div>
      ) : null}
      <Pagination shouldScrollToTop />
      <ul role="list">
        {isNonEmptyArray(
          dataFilteredByNotificationEvent,
        ) ? (
          dataFilteredByNotificationEvent.map((item) => {
            const type = item?.subject
              ?.type as NotificationEventsAndCommit;

            return (
              <NotificationItem
                item={item}
                type={type}
                key={item.id}
              />
            );
          })
        ) : (
          <p className="font-bold text-gray-600">
            No {router?.query?.filterBy || "Data"}
          </p>
        )}
      </ul>
      {dataFilteredByNotificationEvent.length > 5 ? (
        <div className="mt-6 mb-10">
          <Pagination shouldScrollToTop />
        </div>
      ) : null}
    </>
  );
};
