import { useMemo } from "react";
import useSWRImmutable from "swr/immutable";
import { ExternalLink } from "../../../../components/ExternalLink";

import { GithubBox } from "../common/GithubBox";
import {
  Badge,
  NotificationEventsAndCommit,
} from "../common/Badge";
import { List } from "../common/List";
import { Text } from "../common/Text";
import { TimeAgo } from "../common/TimeAgo";

import {
  NotificationEvents,
  NotificationResponseItem,
} from "../../types";

import { requestWithAuth } from "../../../../lib/github";

interface NotificationProps {
  item: NotificationResponseItem;
  type: NotificationEventsAndCommit;
}

const useGithubNotificationItem = (
  url: string | undefined,
) => {
  const { data: { data } = {}, error } = useSWRImmutable(
    url ? url : null,
    requestWithAuth,
  );

  if (error) {
    console.error(error);
  }

  return { data, error };
};

const useGithubNotificationItemDiscussionUrl = (
  discussionTitle: string | undefined,
  type: NotificationEventsAndCommit,
  item: NotificationResponseItem,
) => {
  // there is no rest api for this, so we have to use graphql
  const { data: { data } = {}, error } = useSWRImmutable(
    type === NotificationEvents.Discussion
      ? ["POST /graphql", item]
      : null,
    (_, item) =>
      requestWithAuth("https://api.github.com/graphql", {
        method: "POST",
        query: `{
          search(query: "${discussionTitle} repo:${item.repository.full_name} in:title", type: DISCUSSION, first: 10) {
            edges {
              node {
                ...on Discussion{
                  url
                }
              }
            }
          }
        }`,
      }),
  );
  if (error) {
    console.error(error);
  }

  const discussionUrl: string = useMemo(() => {
    return data?.data?.search?.edges?.[0]?.node?.url;
  }, [data?.data?.search?.edges]);

  return { discussionUrl };
};

export const NotificationItem = ({
  item,
  type,
}: NotificationProps) => {
  // get the url for the notification
  const { data, error } = useGithubNotificationItem(
    item?.subject?.url,
  );

  // escape double quote chars(this is needed for graphql query)
  // taken from here https://gist.github.com/getify/3667624#gistcomment-560608
  const escapedDiscussionTitleString =
    item.subject.title.replace(/\x22/g, "\\\x22");

  // get the url for the 'discussion' notification
  const { discussionUrl } =
    useGithubNotificationItemDiscussionUrl(
      escapedDiscussionTitleString,
      type,
      item,
    );

  const url: string = useMemo(() => {
    return type === NotificationEvents.Discussion
      ? discussionUrl
      : data?.html_url;
  }, [data, discussionUrl, type]);

  if (error) {
    return null;
  }

  return (
    <GithubBox key={item?.id}>
      <header>
        <ExternalLink url={url}>
          {item?.repository?.full_name}
        </ExternalLink>
      </header>
      <section>
        <Text>{item?.subject?.title}</Text>
      </section>
      <footer className="mt-3">
        <List>
          <li>
            <Badge type={type}></Badge>
          </li>
          <li>
            <TimeAgo time={item.updated_at} />
          </li>
        </List>
      </footer>
    </GithubBox>
  );
};
