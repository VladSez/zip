import useSWR from "swr";

import { requestWithAuth } from "../../../../../lib/github";
import { DEFAULT_PAGE } from "../../../constants";
import { NotificationResponse } from "../../../types";

export const useGithubNotificationsFirstPageHeaders =
  () => {
    // fetch "last-modified" header from the first page of notifications
    // (because on the page=1 the header is most recent)
    const { data: { headers: firstPageHeaders } = {} } =
      useSWR<NotificationResponse>(
        "GET /notifications page=1 headers",
        () =>
          requestWithAuth("GET /notifications", {
            page: Number(DEFAULT_PAGE),
            all: true,
            per_page: 25,
          }),
        {
          refreshInterval: 15000,
          refreshWhenHidden: true,
        },
      );

    const lastModifiedHeader =
      firstPageHeaders?.["last-modified"];

    const newNotificationLastModifiedTime =
      lastModifiedHeader
        ? new Date(lastModifiedHeader).toISOString()
        : "";

    return { newNotificationLastModifiedTime };
  };
