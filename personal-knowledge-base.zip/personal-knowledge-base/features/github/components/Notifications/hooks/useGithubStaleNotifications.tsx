import dayjs from "dayjs";
import { useEffect } from "react";
import useSWR from "swr";

import { useSharedState } from "../../../../../hooks/useSharedState";
import { requestWithAuth } from "../../../../../lib/github";
import {
  NotificationResponse,
  NotificationResponseItem,
} from "../../../types";
import { useGithubNotificationsFirstPageHeaders } from "./useGithubNotificationsFirstPageHeaders";

export const useGithubStaleNotifications = () => {
  const {
    state: notificationLastModifiedTime,
    setState: setNotificationLastModifiedTime,
  } = useSharedState<string>("notificationlastModifedTime");

  // fetch "last-modified" header from the first page of notifications
  // (because on the page=1 the header is most recent)
  const { newNotificationLastModifiedTime } =
    useGithubNotificationsFirstPageHeaders();

  // on initial load, save the "last-modified" header to state
  useEffect(() => {
    if (!notificationLastModifiedTime) {
      setNotificationLastModifiedTime(
        newNotificationLastModifiedTime,
      );
    }
  }, [
    notificationLastModifiedTime,
    newNotificationLastModifiedTime,
    setNotificationLastModifiedTime,
  ]);

  const areNotificationsStale =
    notificationLastModifiedTime &&
    newNotificationLastModifiedTime !==
      notificationLastModifiedTime;

  // fetch notifications only if last-modified header is different from the last time
  // TODO: extract to separate hook
  const notificationsSinceLastTime =
    useSWR<NotificationResponse>(
      areNotificationsStale
        ? "GET /notifications /since"
        : null,
      () =>
        requestWithAuth("GET /notifications", {
          // TODO: when clicking 'update stale data' button,
          //  we should use newNotificationLastModifiedTime :)
          // for now we clear swr cache in updateStaleNotificationsCount(), seems to work
          since: notificationLastModifiedTime,
        }),
      {
        refreshInterval: 15000,
        refreshWhenHidden: true,
      },
    );

  const {
    data: { data: notifications = [] } = {},
    mutate,
  } = notificationsSinceLastTime;

  const updateStaleNotificationsCount = async () => {
    setNotificationLastModifiedTime(
      newNotificationLastModifiedTime,
    );

    // TODO:think about better solution?
    // this mutate clear's SWR cache

    mutate(
      {
        ...notificationsSinceLastTime.data,
        data: [],
      } as any, // TODO: investigate type
      false,
    );
  };

  const excludeAlreadySeenNotifications = (
    x: NotificationResponseItem,
  ) =>
    !dayjs(x.updated_at).isSame(
      notificationLastModifiedTime,
    );

  const filteredNotifications = notifications.filter(
    excludeAlreadySeenNotifications,
  );

  const hasNotifications = filteredNotifications.length > 0;

  return {
    updateStaleNotificationsCount,
    notifications: filteredNotifications,
    hasNotifications,

    areNotificationsStale:
      Boolean(areNotificationsStale) && hasNotifications,

    lastUpdated: notificationLastModifiedTime,
    newNotificationLastModifiedTime:
      newNotificationLastModifiedTime,
  };
};
