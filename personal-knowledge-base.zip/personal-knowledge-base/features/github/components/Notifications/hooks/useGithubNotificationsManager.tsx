import { useEffect } from "react";
import { useSWRConfig } from "swr";
import { useRouter } from "next/dist/client/router";

import { useSharedState } from "../../../../../hooks/useSharedState";
import { requestWithAuth } from "../../../../../lib/github";
import { DEFAULT_PAGE } from "../../../constants";
import { NotificationResponse } from "../../../types";

import { useGithubNotifications } from "./useGithubNotifications";
import { useGithubStaleNotifications } from "./useGithubStaleNotifications";

export const useGithubNotificationsManager = () => {
  const router = useRouter();
  const page =
    (router.query.page as string) || DEFAULT_PAGE;

  const { data, error } = useGithubNotifications();
  const {
    updateStaleNotificationsCount,
    areNotificationsStale,
    notifications,
    hasNotifications,
  } = useGithubStaleNotifications();

  const { state: cache, setState: setCache } =
    useSharedState<{
      [key: string]: NotificationResponse["data"];
    }>("githubNotificationsCache", {});

  const dataIsNotInCache = !cache?.[page];

  const { mutate: globalMutate } = useSWRConfig();

  useEffect(() => {
    if (dataIsNotInCache && data) {
      setCache((cache) => ({
        ...cache,
        [page]: data,
      }));
    }
  }, [data, dataIsNotInCache, page, setCache]);

  const pageCache = cache?.[page];

  const updateStaleData = async () => {
    // 1. you are on the first page and clicked 'update stale data' ->
    // updateStaleNotificationsCount() and cache
    // 2. if you are NOT on the first page and you clicked 'update stale data' button ->
    // updateSlateNotifications() and cached notifications and redirect to first page
    // 3.if you clicked on notifications on the left nav bar ->
    // -> redirect to first notifications page, updateSlateNotifications(), and update cached notifications

    // "optimistic" update for the current page :)
    if (data) {
      setCache((cache) => ({
        ...cache,
        [page]: data,
      }));
    }

    // TODO: should we use 'await' here?
    // update's notifications count
    updateStaleNotificationsCount();

    //
    // this is the only way to revalidate 'unmounted' keys in swr, i have found so far :)
    // TODO: replace hardcoded numbers with 'visited pages'
    // or also we can try this
    // https://swr.vercel.app/docs/advanced/cache#mutate-multiple-keys-from-regex
    // just remember, to pass a 'fetcher' function as a second parameter

    // convert object to array of 'visited' page numbers
    // {'1': {}, '2': {}} -> ['1', '2']
    const visitedPages = cache ? Object.keys(cache) : [];

    console.log("KEYS in update stale data", visitedPages);

    const promises = await Promise.allSettled(
      visitedPages.map((page) => {
        return globalMutate(
          `GET /notifications ${page}`,
          // we can also experiment with updating data from fetcherGithub
          requestWithAuth("GET /notifications", {
            page: Number(page),
            all: true,
            per_page: 25,
          }),
        );
      }),
    );

    const newDataWithPageNumber = (
      promises.filter(
        (x) => x.status === "fulfilled",
      ) as PromiseFulfilledResult<NotificationResponse>[]
    ).map((x, index) => ({
      data: x.value,
      page: visitedPages[index],
    }));

    const normalizedData = newDataWithPageNumber.reduce<
      Record<number, NotificationResponse["data"]>
    >((acc, el) => {
      if (el?.page) {
        return { ...acc, [el.page]: el.data?.data };
      }
      return acc;
    }, {});

    // update the cache of all visited pages
    setCache(normalizedData);

    console.log({ newDataWithPageNumber, normalizedData });
  };

  return {
    data,
    error,
    notifications,
    areNotificationsStale,
    updateStaleData,
    cache: pageCache,
    page,
    hasNotifications,
  };
};
