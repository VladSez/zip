import { useRouter } from "next/dist/client/router";
import useSWR from "swr";
import { GHTabs } from "../../../index";

import { requestWithAuth } from "../../../../../lib/github";
import { DEFAULT_PAGE } from "../../../constants";
import { NotificationResponse } from "../../../types";

export const useGithubNotifications = () => {
  const router = useRouter();
  const page =
    (router.query.page as string) || DEFAULT_PAGE;

  // pls, note this is a temporary solution
  // probably the swr is not used here correctly
  // because this request is running everytime when page in query changes
  // this is happenning on Feed, Starred repos, Hacker news
  const isGithubNotificationTab =
    router.query.tab === GHTabs.Notifications;

  const { data: { data } = {}, error } =
    // TODO: refetch only in notification Tab
    useSWR<NotificationResponse>(
      isGithubNotificationTab
        ? `GET /notifications ${page}`
        : null,
      () =>
        requestWithAuth("GET /notifications", {
          page: Number(page),
          all: true,
          per_page: 25,
        }),
    );

  return {
    data,
    error,
  };
};
