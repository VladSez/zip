interface LanguageLinkProps {
  lang: string;
}
export const LanguageLink = ({
  lang,
}: LanguageLinkProps) => {
  return (
    <a
      href={`https://github.com/topics/${lang}`}
      target="_blank"
      rel="noopener noreferrer"
      className="font-medium text-gray-900 hover:text-blue-600"
    >
      {lang}
    </a>
  );
};
