interface GithubBoxProps {
  children: React.ReactNode;
}

export const GithubBox = ({ children }: GithubBoxProps) => {
  return (
    <li className="relative my-3 border-t border-b border-gray-200 p-4  transition-all sm:rounded-2xl  sm:border">
      {children}
    </li>
  );
};
