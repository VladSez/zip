import { Button } from "../../../../components/Button";
import classNames from "classnames";
import { Directions, Filters, Sorts } from "../../types";
import { useRouter } from "next/dist/client/router";
import { HNFilters } from "../../../hackerNews/types";
import { DEFAULT_PAGE } from "../../constants";

interface FilterByButtonProps {
  filterBy: Filters | Directions | Sorts | HNFilters;
  children?: React.ReactNode;
  queryKey: string;
}
export const FilterByButton = ({
  filterBy,
  children,
  queryKey,
}: FilterByButtonProps) => {
  const router = useRouter();

  return (
    <Button
      aria-label={`Filter by ${filterBy}`}
      className={classNames({
        "bg-blue-300 text-blue-900 hover:bg-blue-300":
          (router?.query?.[queryKey] as string) ===
          filterBy,
      })}
      onClick={() => {
        router.push({
          pathname: router.pathname,
          query: {
            ...router.query,
            [queryKey]: filterBy,
            page: DEFAULT_PAGE, // always set page to 1, when changing filters
          },
        });
      }}
    >
      {filterBy === "PullRequest"
        ? "Pull Request"
        : children || filterBy}
    </Button>
  );
};
