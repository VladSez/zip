import { Tooltip } from "../../../../components/Tooltip";
import { LanguageLink } from "./LanguageLink";
import { List } from "./List";
import { StarCount } from "./StarCount";
import { TimeAgo } from "./TimeAgo";

interface GithubMetaProps {
  starCount: number;
  language: string | null;
  updatedAt: string | null;
}

export const GithubMeta = ({
  starCount,
  language,
  updatedAt,
}: GithubMetaProps) => {
  return (
    <List>
      <Tooltip content="Number of stars">
        <li className="font-medium text-gray-600">
          <StarCount starCount={starCount} />
        </li>
      </Tooltip>
      {language ? <LanguageLink lang={language} /> : null}
      <li className="text-gray-500">
        Updated: <TimeAgo time={updatedAt} />
      </li>
    </List>
  );
};
