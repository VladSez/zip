import clsx from "clsx";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import { Tooltip } from "../../../../components/Tooltip";

dayjs.extend(relativeTime);

interface TimeAgoProps {
  time: string | null;
  className?: string;
}
export const TimeAgo = ({
  time,
  className,
}: TimeAgoProps) => {
  return (
    <Tooltip
      content={
        time
          ? dayjs(time).format("DD MMMM YYYY, HH:mm:ss")
          : ""
      }
    >
      <time
        dateTime={time ? time : ""}
        className={clsx(
          "cursor-pointer text-gray-600 transition duration-200 ease-in-out hover:text-gray-800",
          className,
        )}
      >
        {dayjs().from(time, true)}
        <span> ago</span>
      </time>
    </Tooltip>
  );
};
