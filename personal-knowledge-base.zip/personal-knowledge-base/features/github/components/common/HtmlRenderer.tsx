import parse, {
  domToReact,
  HTMLReactParserOptions,
} from "html-react-parser";
import { Element } from "domhandler/lib/node";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      tt: React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      >;
    }
  }
}

export const htmlRenderOptions: HTMLReactParserOptions = {
  replace: (domNode) => {
    if (domNode instanceof Element && domNode.attribs) {
      if (domNode.name === "ul") {
        return (
          <ul role="list" className="overflow-x-auto pl-4">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </ul>
        );
      }
      if (domNode.name === "li") {
        return (
          <li className="list-disc py-2 text-gray-600">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </li>
        );
      }
      if (domNode.name === "a") {
        return (
          <a
            className="text-blue-700"
            target="_blank"
            rel="noopener noreferrer"
            href={domNode.attribs.href}
          >
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </a>
        );
      }
      if (domNode.name === "h1") {
        return (
          <h1 className="border-b border-gray-300 py-2 text-lg font-bold text-gray-600">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </h1>
        );
      }
      if (domNode.name === "h2") {
        return (
          <h2 className="mb-2 border-b border-gray-300 py-2 text-base font-bold text-gray-600">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </h2>
        );
      }
      if (domNode.name === "h3") {
        return (
          <h3 className="py-2 text-base font-bold text-gray-600">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </h3>
        );
      }
      if (domNode.name === "tt") {
        return (
          <tt className="rounded-lg bg-gray-100 p-1 px-2 text-blue-700">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </tt>
        );
      }
      if (domNode.name === "code") {
        return (
          <code className="rounded-lg bg-gray-100 p-1 px-2 font-semibold text-black">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </code>
        );
      }

      if (domNode.attribs.class === "pl-ent") {
        return (
          <span className="text-blue-600">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </span>
        );
      }

      if (domNode.attribs.class === "pl-c1") {
        return (
          <span className="text-red-800">
            {domToReact(
              domNode.children,
              htmlRenderOptions,
            )}
          </span>
        );
      }
      if (domNode.name === "pre") {
        return (
          <>
            <pre className="my-2 rounded-lg bg-gray-100 p-3 font-semibold text-gray-700">
              {domToReact(
                domNode.children,
                htmlRenderOptions,
              )}
            </pre>
          </>
        );
      }
    }
  },
};

interface GithubHtmlRendererProps {
  html: string;
}
export const GithubHtmlRenderer = ({
  html,
}: GithubHtmlRendererProps) => {
  return (
    <>{html ? parse(html, htmlRenderOptions) : null}</>
  );
};
