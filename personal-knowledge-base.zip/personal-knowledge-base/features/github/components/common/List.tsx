import classNames from "classnames";

interface ListProps {
  children: React.ReactNode;
  className?: string;
}
export const List = ({
  children,
  className,
}: ListProps) => {
  return (
    <ul
      className={classNames(
        className,
        "flex items-center space-x-2 text-xs font-normal text-gray-600",
      )}
    >
      {children}
    </ul>
  );
};
