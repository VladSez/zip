interface TextProps {
  children: React.ReactNode;
}
export const Text = ({ children }: TextProps) => {
  return (
    <p className="mt-0.5 text-left text-sm text-gray-600">
      {children}
    </p>
  );
};
