import cn from "classnames";
import { NotificationEvents } from "../../types";

const SpecialNotificationEvent = {
  Commit: "Commit",
} as const;

export type NotificationEventsAndCommit =
  | keyof typeof NotificationEvents
  | "Commit";
interface HeaderProps {
  type: NotificationEventsAndCommit;
  className?: string;
}

const mapType = (type: NotificationEventsAndCommit) => {
  if (type === "PullRequest") {
    return "Pull Request";
  }
  return type;
};

export const Badge = ({ type, className }: HeaderProps) => {
  return (
    <span
      className={cn(
        "inline-flex rounded-full px-2 text-xs font-semibold leading-5",
        className,
        {
          "bg-blue-100 text-blue-800":
            type === NotificationEvents.PullRequest,
          "bg-pink-200 text-pink-900":
            type === NotificationEvents.Release,
          "bg-yellow-100 text-yellow-800":
            type === NotificationEvents.Discussion,
          "bg-green-100 text-green-800":
            type === NotificationEvents.Issue,
          "bg-red-200 text-red-900":
            type === SpecialNotificationEvent.Commit,
        },
      )}
    >
      {mapType(type)}
    </span>
  );
};
