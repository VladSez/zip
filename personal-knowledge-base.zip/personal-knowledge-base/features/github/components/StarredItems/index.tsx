import { useRouter } from "next/router";
import { useState } from "react";
import { objectKeys } from "ts-extras";
import { DEFAULT_PAGE } from "../../constants";

import { StarredGistsList } from "./StarredGistsList";
import { StarredReposList } from "./StarredReposList";

const StarredOptions = {
  Repos: "Repos",
  Gists: "Gists",
} as const;

type StarredOptionsType = keyof typeof StarredOptions;

export const StarredItems = () => {
  const [activeListId, setActiveListId] =
    useState<StarredOptionsType>(StarredOptions.Repos);
  const router = useRouter();

  return (
    <>
      <div className="flex justify-end">
        <select
          className="
        mt-1
        rounded-md
        border
        border-gray-300
        px-2
        py-2
        shadow-sm
        "
          value={activeListId}
          onChange={(e) => {
            setActiveListId(
              e.target.value as StarredOptionsType,
            );
            // set page to 1, when changing lists
            router.push({
              pathname: router.pathname,
              query: {
                ...router.query,
                page: DEFAULT_PAGE,
              },
            });
          }}
        >
          {objectKeys(StarredOptions).map((key) => (
            <option key={key} value={key}>
              {key}
            </option>
          ))}
        </select>
      </div>
      {activeListId === StarredOptions.Repos && (
        <StarredReposList />
      )}
      {activeListId === StarredOptions.Gists && (
        <StarredGistsList />
      )}
    </>
  );
};
