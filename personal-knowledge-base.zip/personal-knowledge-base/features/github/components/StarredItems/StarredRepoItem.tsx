import { ExternalLink } from "../../../../components/ExternalLink";
import { SelectLabel } from "../../../labels/components/SelectLabel";
import { GithubItem } from "../../../labels/types";
import { StarredResponseItem } from "../../types";
import { GithubBox } from "../common/GithubBox";
import { GithubMeta } from "../common/GithubMeta";
import { Text } from "../common/Text";

interface StarItemProps {
  item: StarredResponseItem;
}
export const StarredRepoItem = ({
  item,
}: StarItemProps) => {
  const url = item?.html_url;

  const itemToBeSaved = {
    id: String(item.id),
    full_name: item.full_name,
    description: item?.description,
    stargazers_count: item.stargazers_count,
    language: item?.language,
    pushed_at: item.pushed_at,
    type: "github",
    html_url: item?.html_url,
  } as GithubItem;

  return (
    <GithubBox>
      <header className="relative flex flex-wrap items-center space-x-2">
        <ExternalLink url={url}>
          {item?.full_name}
        </ExternalLink>
        <SelectLabel
          id={String(item?.id)}
          itemToBeSaved={itemToBeSaved}
          type="github"
        />
      </header>
      <div className="py-3">
        <Text>{item?.description}</Text>
      </div>

      <footer className="mt-2">
        <GithubMeta
          starCount={item?.stargazers_count}
          language={item?.language}
          updatedAt={item?.pushed_at}
        />
      </footer>
    </GithubBox>
  );
};
