import { useRouter } from "next/router";
import useSWR from "swr";

import { LoaderWithText } from "../../../../components/Loader";
import { Pagination } from "../../../../components/Pagination";

import { requestWithAuth } from "../../../../lib/github";
import { isNonEmptyArray } from "../../../../utils/isNotEmptyArray";
import { DEFAULT_PAGE } from "../../constants";
import { StarredGistsResponse } from "../../types";
import { StarredGistItem } from "./StarredGistItem";

export const useGithubStarredGists = () => {
  const router = useRouter();

  const page =
    (router.query.page as string) || DEFAULT_PAGE;

  const { data: { data: starredGists } = {}, error } =
    useSWR<StarredGistsResponse>(
      ["GET /gists/starred", page],
      () =>
        requestWithAuth("GET /gists/starred", {
          page: Number(page),
          per_page: 7,
        }),
    );

  return { starredGists, error };
};

export const StarredGistsList = () => {
  const { starredGists, error } = useGithubStarredGists();

  if (error) {
    console.error(error);
    return <pre>{JSON.stringify({ error }, null, 2)}</pre>;
  }

  if (!starredGists) {
    return (
      <div className="mt-10 flex flex-col items-center justify-start sm:h-screen">
        <LoaderWithText />
      </div>
    );
  }

  const isStarredGistsNotEmpty =
    isNonEmptyArray(starredGists);

  return (
    <>
      <Pagination
        canFetchNextPage={isStarredGistsNotEmpty}
      />
      <ul role="list">
        {isStarredGistsNotEmpty ? (
          starredGists.map((gist) => (
            <StarredGistItem gist={gist} key={gist.id} />
          ))
        ) : (
          <li>
            <p>No more data</p>
          </li>
        )}
      </ul>
      {isStarredGistsNotEmpty ? (
        <Pagination shouldScrollToTop />
      ) : null}
    </>
  );
};
