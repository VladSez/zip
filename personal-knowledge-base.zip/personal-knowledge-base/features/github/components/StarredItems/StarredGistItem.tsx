// TODO: follow this
//  https://github.com/react-syntax-highlighter/react-syntax-highlighter/issues/439

// @ts-expect-error
import { PrismAsyncLight as SyntaxHighlighter } from "react-syntax-highlighter";
// @ts-expect-error
import { ghcolors } from "react-syntax-highlighter/dist/cjs/styles/prism";

import useSWRImmutable from "swr/immutable";
import { objectEntries } from "ts-extras";

import { Avatar } from "../../../../components/Avatar";
import { ExternalLink } from "../../../../components/ExternalLink";
import { StarredGistsResponseItem } from "../../types";
import { TimeAgo } from "../common/TimeAgo";

function fetcher(...args: Parameters<typeof fetch>) {
  return fetch(...args).then((res) => res.text());
}

const useGithubGist = (url: string | undefined) => {
  const { data, error } = useSWRImmutable<string>(
    url ? url : null,
    fetcher,
    {
      onError: (error, key) => {
        console.error({ error, key });
      },
    },
  );

  return { data, error };
};

interface StarredGistItemProps {
  gist: StarredGistsResponseItem;
}

export const StarredGistItem = ({
  gist,
}: StarredGistItemProps) => {
  return (
    <>
      {objectEntries(gist.files).map(([fileName, file]) => {
        return (
          <GistContent
            key={fileName}
            file={file}
            gist={gist}
          />
        );
      })}
    </>
  );
};

interface GistFileContentProps {
  file: StarredGistsResponseItem["files"][0];
  gist: StarredGistsResponseItem;
}
const GistContent = ({
  file,
  gist,
}: GistFileContentProps) => {
  const { data } = useGithubGist(file?.raw_url);

  const avatarUrl = gist?.owner?.avatar_url;

  return (
    <li className="my-8">
      <header className="flex items-center gap-2">
        <div>
          {avatarUrl ? (
            <Avatar
              src={gist?.owner?.avatar_url}
              alt={`Avatar of ${gist?.owner?.login}`}
              width={35}
              height={35}
            />
          ) : null}
        </div>
        <div>
          <div className="space-x-1">
            <ExternalLink
              url={`https://gist.github.com/${gist?.owner?.login}`}
              className={"font-normal text-blue-700"}
            >
              {gist?.owner?.login}
            </ExternalLink>
            <span className={"text-blue-700"}>/</span>
            <ExternalLink
              url={gist?.html_url}
              className={"font-medium text-blue-700"}
            >
              {file?.filename}
            </ExternalLink>
          </div>
          <div className="space-x-1 text-xs text-gray-600">
            <span>Created</span>
            <TimeAgo time={gist?.created_at} />
          </div>
          {gist?.description ? (
            <p className="mt-1 text-xs text-gray-600">
              {gist.description}
            </p>
          ) : null}
        </div>
      </header>
      {/* TODO: maybe use next/dynamic to reduce the bundle size? */}
      {/* To render markdown we can try smth like this:
            https://github.com/remarkjs/react-markdown#use-custom-components-syntax-highlight
              
            so when file is markdown we use react-markdown, otherwise just `SynataxHighlighter`? 
          */}
      <SyntaxHighlighter
        language={file?.language?.toLowerCase()}
        style={ghcolors}
        customStyle={{
          height: "300px",
          marginTop: "16px",
        }}
      >
        {data || "Loading..."}
      </SyntaxHighlighter>
    </li>
  );
};
