import { useRouter } from "next/dist/client/router";
import useSWR from "swr";

import { ButtonGroup } from "../../../../components/ButtonGroup";
import { LoaderWithText } from "../../../../components/Loader";
import { Pagination } from "../../../../components/Pagination";

import { requestWithAuth } from "../../../../lib/github";
import { DEFAULT_PAGE } from "../../constants";
import {
  Direction,
  Directions,
  Sort,
  Sorts,
  StarredResponse,
} from "../../types";
import { FilterByButton } from "../common/FilterByButton";
import { StarredRepoItem } from "./StarredRepoItem";

export const useGithubStarredRepos = () => {
  const router = useRouter();

  const direction =
    (router.query.direction as Directions) ||
    Direction.desc;
  const sort = (router.query.sort as Sorts) || Sort.created;
  const page =
    (router.query.page as string) || DEFAULT_PAGE;

  const { data: { data: starredRepos } = {}, error } =
    useSWR<StarredResponse>(
      ["GET /user/starred", page, direction, sort],
      () =>
        requestWithAuth("GET /user/starred", {
          page: Number(page),
          direction,
          sort,
        }),
    );

  return { starredRepos, error };
};

export const StarredReposList = () => {
  const { starredRepos, error } = useGithubStarredRepos();

  if (error) {
    console.error(error);
    return <pre>{JSON.stringify({ error }, null, 2)}</pre>;
  }

  if (!starredRepos) {
    return (
      <div className="mt-10 flex flex-col items-center justify-start sm:h-screen">
        <LoaderWithText />
      </div>
    );
  }

  return (
    <>
      <Filters />
      <div className="mt-4">
        <Pagination />
      </div>
      <ul role="list">
        {starredRepos.map((item) => {
          return (
            <StarredRepoItem item={item} key={item.id} />
          );
        })}
      </ul>
      {starredRepos.length > 5 ? (
        <div className="mt-6 mb-10">
          <Pagination shouldScrollToTop />
        </div>
      ) : null}
    </>
  );
};

const Filters = () => {
  return (
    <div className="space-y-2">
      <div>
        <p className="text-center">Direction: </p>
        <ButtonGroup
          className="text-center"
          ariaLabel="direction options: ascending or descending"
        >
          <FilterByButton
            filterBy={Direction.desc}
            queryKey="direction"
          >
            Newest
          </FilterByButton>
          <FilterByButton
            filterBy={Direction.asc}
            queryKey="direction"
          >
            Oldest
          </FilterByButton>
        </ButtonGroup>
      </div>
      <div>
        <p className="text-center">Sort by when:</p>
        <ButtonGroup
          className="text-center"
          ariaLabel="sorting options: created (when the repository was starred) or updated(when it was last pushed to)"
        >
          <FilterByButton
            filterBy={Sort.created}
            queryKey="sort"
          >
            repo was starred
          </FilterByButton>
          <FilterByButton
            filterBy={Sort.updated}
            queryKey="sort"
          >
            repo was last updated
          </FilterByButton>
        </ButtonGroup>
      </div>
    </div>
  );
};
