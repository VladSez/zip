import { Endpoints } from "@octokit/types";

export type NotificationResponse =
  Endpoints["GET /notifications"]["response"];

export type NotificationResponseItem =
  NotificationResponse["data"][0];

export type StarredResponse =
  Endpoints["GET /user/starred"]["response"];

export type StarredResponseItem =
  StarredResponse["data"][0];

export type StarredByUsersResponse =
  Endpoints["GET /users/{username}/received_events"]["response"];

export type StarredByUsersResponseItem =
  StarredByUsersResponse["data"][0];

export type StarredGistsResponse =
  Endpoints["GET /gists/starred"]["response"];

export type StarredGistsResponseItem =
  StarredGistsResponse["data"][0];

export type Category =
  | "starred"
  | "notifications"
  | "starredByUsers";

export enum RECEIVED_EVENT {
  WatchEvent = "WatchEvent",
  ForkEvent = "ForkEvent",
  ReleaseEvent = "ReleaseEvent",
  CreateEvent = "CreateEvent",
  MemberEvent = "MemberEvent",
  PublicEvent = "PublicEvent",
}

export enum NotificationEvents {
  All = "All",
  PullRequest = "PullRequest",
  Release = "Release",
  Discussion = "Discussion",
  Issue = "Issue",
}

export type Filters = keyof typeof NotificationEvents;

export enum Direction {
  asc = "asc",
  desc = "desc",
}

export type Directions = keyof typeof Direction;

export enum Sort {
  created = "created",
  updated = "updated",
}
export type Sorts = keyof typeof Sort;

// these type were auto-generated using typehole extension

export interface ReleaseType {
  url: string;
  assets_url: string;
  upload_url: string;
  html_url: string;
  id: number;
  author: Author;
  node_id: string;
  tag_name: string;
  target_commitish: string;
  name: string;
  draft: boolean;
  prerelease: boolean;
  created_at: string;
  published_at: string;
  assets: any[];
  tarball_url: string;
  zipball_url: string;
  body: string;
  mentions_count?: number;
  mentions?: Mention[];
  short_description_html: string;
  is_short_description_html_truncated: boolean;
}
interface Mention {
  avatar_url: string;
  login: string;
  profile_name: null | string | string;
  profile_url: string;
  avatar_user_actor: boolean;
}
interface Author {
  login: string;
  id: number;
  node_id: string;
  avatar_url: string;
  gravatar_id: string;
  url: string;
  html_url: string;
  followers_url: string;
  following_url: string;
  gists_url: string;
  starred_url: string;
  subscriptions_url: string;
  organizations_url: string;
  repos_url: string;
  events_url: string;
  received_events_url: string;
  type: string;
  site_admin: boolean;
}

export interface FeedItemType {
  id: number;
  node_id: string;
  name: string;
  full_name: string;
  private: boolean;
  owner: Owner;
  html_url: string;
  description: null | string;
  fork: boolean;
  url: string;
  forks_url: string;
  keys_url: string;
  collaborators_url: string;
  teams_url: string;
  hooks_url: string;
  issue_events_url: string;
  events_url: string;
  assignees_url: string;
  branches_url: string;
  tags_url: string;
  blobs_url: string;
  git_tags_url: string;
  git_refs_url: string;
  trees_url: string;
  statuses_url: string;
  languages_url: string;
  stargazers_url: string;
  contributors_url: string;
  subscribers_url: string;
  subscription_url: string;
  commits_url: string;
  git_commits_url: string;
  comments_url: string;
  issue_comment_url: string;
  contents_url: string;
  compare_url: string;
  merges_url: string;
  archive_url: string;
  downloads_url: string;
  issues_url: string;
  pulls_url: string;
  milestones_url: string;
  notifications_url: string;
  labels_url: string;
  releases_url: string;
  deployments_url: string;
  created_at: string;
  updated_at: string;
  pushed_at: string;
  git_url: string;
  ssh_url: string;
  clone_url: string;
  svn_url: string;
  homepage: null | string;
  size: number;
  stargazers_count: number;
  watchers_count: number;
  language: null | string;
  has_issues: boolean;
  has_projects: boolean;
  has_downloads: boolean;
  has_wiki: boolean;
  has_pages: boolean;
  forks_count: number;
  mirror_url: null;
  archived: boolean;
  disabled: boolean;
  open_issues_count: number;
  license: License | License2 | null;
  allow_forking: boolean;
  is_template: boolean;
  topics: string[];
  visibility: string;
  forks: number;
  open_issues: number;
  watchers: number;
  default_branch: string;
  permissions: Permissions;
  temp_clone_token: string;
  organization?: Owner;
  network_count: number;
  subscribers_count: number;
}
interface Permissions {
  admin: boolean;
  maintain: boolean;
  push: boolean;
  triage: boolean;
  pull: boolean;
}
interface License2 {
  key: string;
  name: string;
  spdx_id: string;
  url: string;
  node_id: string;
}
interface License {
  key: string;
  name: string;
  spdx_id: string;
  url: null;
  node_id: string;
}
interface Owner {
  login: string;
  id: number;
  node_id: string;
  avatar_url: string;
  gravatar_id: string;
  url: string;
  html_url: string;
  followers_url: string;
  following_url: string;
  gists_url: string;
  starred_url: string;
  subscriptions_url: string;
  organizations_url: string;
  repos_url: string;
  events_url: string;
  received_events_url: string;
  type: string;
  site_admin: boolean;
}
