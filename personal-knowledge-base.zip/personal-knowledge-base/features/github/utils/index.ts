import {
  RECEIVED_EVENT,
  StarredByUsersResponseItem,
} from "../types";

export const formatFeedReceivedEventType = (
  type: string | null,
) => {
  // TODO: refactor to use RECEIVED_EVENT enum?
  if (type === RECEIVED_EVENT.WatchEvent) {
    return "starred";
  }
  if (type === RECEIVED_EVENT.ForkEvent) {
    return "forked";
  }
  if (type === RECEIVED_EVENT.ReleaseEvent) {
    return "released";
  }
  if (type === RECEIVED_EVENT.CreateEvent) {
    return "created";
  }
  if (type === RECEIVED_EVENT.PublicEvent) {
    return "made public";
  }
  return null;
};

export const getFeedReleaseUrl = (
  x: StarredByUsersResponseItem,
) => {
  if (x?.type === "ReleaseEvent") {
    // @ts-expect-error
    return x.payload.release.html_url as string;
  }
  return "";
};

export const getFeedDefaultUrl = (
  x: StarredByUsersResponseItem,
) => {
  if (x?.repo?.name) {
    return `https://github.com/${x.repo.name}`;
  }
  return "";
};

export const getFeedUserUrl = (
  x: StarredByUsersResponseItem,
) => {
  if (x?.actor?.login) {
    return `https://github.com/${x.actor.login}`;
  }
  return "";
};
