import clsx from "clsx";
import { useRouter } from "next/dist/client/router";
import { useEffect, useState } from "react";
import * as RadixTabs from "@radix-ui/react-tabs";
import { objectEntries, objectKeys } from "ts-extras";

import { Feed } from "./components/Feed";
import { Notifications } from "./components/Notifications";
import { StarredItems } from "./components/StarredItems";

import {
  Direction,
  NotificationEvents,
  Sort,
} from "./types";
import { DEFAULT_PAGE } from "./constants";

export enum GHTabs {
  Feed = "Feed",
  Notifications = "Notifications",
  "Starred Repos" = "Starred Repos",
}

type GithubTabProps = keyof typeof GHTabs;

const githubCategories = {
  [GHTabs.Feed]: <Feed />,
  [GHTabs.Notifications]: <Notifications />,
  [GHTabs["Starred Repos"]]: <StarredItems />,
} as const;

export const GithubTabs = () => {
  const [activeTab, setActiveTab] =
    useState<GithubTabProps>();

  const router = useRouter();

  useEffect(() => {
    if (!router.isReady) {
      return;
    }

    // if no tab in url, set default tab
    if (!router.query.tab) {
      router.push({
        query: {
          tab: GHTabs["Feed"], // default tab
          page: DEFAULT_PAGE,
        },
      });
      setActiveTab(GHTabs["Feed"]);
    } else {
      // take tab from url
      setActiveTab(router.query.tab as GithubTabProps);
    }
  }, [router]);

  return (
    <RadixTabs.Root
      defaultValue={router.query.tab as string}
      value={activeTab}
      onValueChange={(tab) => {
        const currentTab = tab as GithubTabProps;

        if (currentTab === GHTabs["Starred Repos"]) {
          router.push({
            query: {
              tab: GHTabs["Starred Repos"],
              direction: Direction.desc,
              sort: Sort.created,
              page: DEFAULT_PAGE,
            },
          });
        } else if (currentTab === GHTabs["Notifications"]) {
          router.push({
            query: {
              tab: GHTabs["Notifications"],
              filterBy: NotificationEvents.All,
              page: DEFAULT_PAGE,
            },
          });
        } else {
          router.push({
            query: {
              tab: GHTabs["Feed"],
              page: DEFAULT_PAGE,
            },
          });
        }
      }}
    >
      <RadixTabs.List
        aria-label="Twitter tabs"
        className="flex space-x-2 bg-blue-100 p-1 sm:rounded-xl"
      >
        {objectKeys(githubCategories).map((category) => (
          <RadixTabs.Trigger
            key={category}
            className={clsx(
              "w-full p-0.5 py-1.5 sm:p-1 sm:py-2.5",
              "rounded-lg text-sm font-medium leading-5 text-blue-700",
              "ring-white ring-opacity-60 focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-black",
              "hover:bg-white/50",
              "transition-colors motion-reduce:transition-none",
              {
                "bg-white shadow hover:bg-white":
                  activeTab === category,
              },
            )}
            value={category}
          >
            {category}
          </RadixTabs.Trigger>
        ))}
      </RadixTabs.List>

      {objectEntries(githubCategories).map(
        ([key, value]) => {
          return (
            <RadixTabs.Content
              key={key}
              className="my-5 focus:outline-none focus-visible:ring-2 focus-visible:ring-black"
              value={key}
            >
              {value}
            </RadixTabs.Content>
          );
        },
      )}
    </RadixTabs.Root>
  );
};
