import {
  signIn,
  signOut,
  useSession,
} from "next-auth/react";
import { useEffect } from "react";

interface AuthProps {
  hasError?: boolean;
}

export function Auth({ hasError = false }: AuthProps) {
  const { data: session } = useSession();

  useEffect(() => {
    if (session?.error === "RefreshAccessTokenError") {
      signIn(); // Force sign in to hopefully resolve error
    }
  }, [session]);

  return (
    <>{!session || hasError ? <SignIn /> : <SignOut />}</>
  );
}

const SignIn = () => {
  return (
    <div className="mx-2 mt-5 flex justify-between sm:mx-0">
      <span className="text-sm font-medium">
        You are NOT signed in into youtube account
      </span>
      <a
        href={`/api/auth/signin`}
        onClick={(e) => {
          e.preventDefault();
          signIn();
        }}
      >
        Sign in
      </a>
    </div>
  );
};

const SignOut = () => {
  return (
    <div className="mx-2 mt-5 flex justify-between sm:mx-0">
      <span className="text-sm font-medium">
        You are signed in into youtube account
      </span>
      <a
        href={`/api/auth/signout`}
        onClick={(e) => {
          e.preventDefault();
          signOut();
        }}
      >
        Sign out
      </a>
    </div>
  );
};
