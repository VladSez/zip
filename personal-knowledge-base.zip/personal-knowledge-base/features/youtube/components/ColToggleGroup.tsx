import * as ToggleGroup from "@radix-ui/react-toggle-group";
import clsx from "clsx";
import { Dispatch, SetStateAction } from "react";

import { Tooltip } from "../../../components/Tooltip";
import { ColumnsType } from "../hooks/useColumns";

interface ColToggleGroupProps {
  setColumn: Dispatch<SetStateAction<ColumnsType>>;
  column: ColumnsType;
}

export function ColToggleGroup({
  column,
  setColumn,
}: ColToggleGroupProps) {
  return (
    <ToggleGroup.Root
      type="single"
      defaultValue="one"
      aria-label="Choose number of columns in grid"
      value={column}
      onValueChange={(value) => {
        if (!value) {
          // if you click on the same item twice, it will be set to ''
          // this check prevents that
          setColumn((state) => state);
        } else {
          setColumn(value as ColumnsType);
        }
      }}
      className="inline-flex rounded-md shadow"
    >
      <Tooltip content="List">
        <ToggleGroup.Item
          value="one"
          aria-label="List"
          className={clsx(
            "rounded-tl-md rounded-bl-md p-1 transition-colors",
            {
              "bg-slate-200 text-slate-600":
                column === "one",
              "bg-white text-slate-800": column !== "one",
            },
          )}
        >
          <ListIcon />
        </ToggleGroup.Item>
      </Tooltip>
      <Tooltip content="Grid">
        <ToggleGroup.Item
          value="two"
          aria-label="Grid"
          className={clsx(
            "rounded-tr-md rounded-br-md p-1 transition-colors",
            {
              "bg-slate-200 text-slate-600":
                column === "two",
              "bg-white text-slate-800": column !== "two",
            },
          )}
        >
          <GridIcon />
        </ToggleGroup.Item>
      </Tooltip>
    </ToggleGroup.Root>
  );
}

const GridIcon = () => {
  return (
    <svg
      className="h-5 w-5"
      strokeWidth="1.5"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M14 20.4V14.6C14 14.2686 14.2686 14 14.6 14H20.4C20.7314 14 21 14.2686 21 14.6V20.4C21 20.7314 20.7314 21 20.4 21H14.6C14.2686 21 14 20.7314 14 20.4Z"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      <path
        d="M3 20.4V14.6C3 14.2686 3.26863 14 3.6 14H9.4C9.73137 14 10 14.2686 10 14.6V20.4C10 20.7314 9.73137 21 9.4 21H3.6C3.26863 21 3 20.7314 3 20.4Z"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      <path
        d="M14 9.4V3.6C14 3.26863 14.2686 3 14.6 3H20.4C20.7314 3 21 3.26863 21 3.6V9.4C21 9.73137 20.7314 10 20.4 10H14.6C14.2686 10 14 9.73137 14 9.4Z"
        stroke="currentColor"
        strokeWidth="1.5"
      />
      <path
        d="M3 9.4V3.6C3 3.26863 3.26863 3 3.6 3H9.4C9.73137 3 10 3.26863 10 3.6V9.4C10 9.73137 9.73137 10 9.4 10H3.6C3.26863 10 3 9.73137 3 9.4Z"
        stroke="currentColor"
        strokeWidth="1.5"
      />
    </svg>
  );
};

const ListIcon = () => {
  return (
    <svg
      className="h-5 w-5"
      strokeWidth="1.5"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M8 6L20 6"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4 6.01L4.01 5.99889"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4 12.01L4.01 11.9989"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M4 18.01L4.01 17.9989"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8 12L20 12"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8 18L20 18"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
