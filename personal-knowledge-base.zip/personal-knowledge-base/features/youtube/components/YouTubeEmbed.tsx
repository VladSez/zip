import clsx from "clsx";
import LiteYouTubeEmbed from "react-lite-youtube-embed";

import { useBoolean } from "../../../hooks/useBoolean";

import { TimeAgo } from "../../github/components/common/TimeAgo";
import { formatNumberToCompact } from "../../twitter/components/TweetMeta";

interface YoutubeEmbedProps {
  id: string | null | undefined;
  title: string | null | undefined;

  channelTitle?: string | null;
  channelId?: string | null;
  viewCount?: string | null;
  publishedAt?: string | null;
  isPlaylist?: boolean | null;
  playlistCoverId?: string | null;
}

export const YouTubeEmbed = ({
  id,
  title,
  channelTitle,
  viewCount,
  publishedAt,
  channelId,
  isPlaylist = false,
  playlistCoverId,
}: YoutubeEmbedProps) => {
  const { value: isFrameLoaded, setValue: setFrame } =
    useBoolean();

  const className = clsx(
    "hover:bg-red-500  transition-colors absolute left-1/2 top-1/2 w-[68px] h-[48px] bg-slate-900/80 rounded-xl -translate-x-1/2 -translate-y-1/2",
    { "opacity-0 pointer-events-none": isFrameLoaded },
  );

  return (
    <article className="my-5">
      <div className="relative">
        {/* https://github.com/ibrahimcesar/react-lite-youtube-embed */}
        <LiteYouTubeEmbed
          id={id || ""}
          title={title || ""}
          cookie={true}
          poster="hqdefault"
          playerClass={className}
          onIframeAdded={() => {
            setFrame(true);
          }}
          playlist={isPlaylist || false}
          playlistCoverId={playlistCoverId || ""}
          params="start=1" // start from the beginning of the video every time
        />
        {!isFrameLoaded ? <PlayIcon /> : null}
      </div>
      <div className="mx-3 mt-2 sm:mx-0">
        <header>
          <h6 className="my-1 font-medium">{title}</h6>
        </header>
        <section>
          <a
            href={
              channelId
                ? `https://www.youtube.com/channel/${channelId}`
                : ""
            }
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-gray-500"
          >
            {channelTitle}
          </a>
        </section>
        {viewCount && publishedAt ? (
          <footer className="flex space-x-1">
            <p className="text-sm text-gray-500">
              {formatNumberToCompact(Number(viewCount))}{" "}
              views
            </p>
            <span className="text-gray-600 ">{"·"}</span>

            <TimeAgo
              className="text-sm text-gray-500 hover:text-gray-500"
              time={publishedAt}
            />
          </footer>
        ) : null}
      </div>
    </article>
  );
};

const PlayIcon = () => {
  return (
    <svg
      className="fake-youtube-play-btn pointer-events-none absolute left-1/2 top-1/2 z-0 h-7 w-7 -translate-x-1/2 -translate-y-1/2 cursor-pointer text-white"
      strokeWidth="1.5"
      viewBox="0 0 24 24"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M6.90588 4.53682C6.50592 4.2998 6 4.58808 6 5.05299V18.947C6 19.4119 6.50592 19.7002 6.90588 19.4632L18.629 12.5162C19.0211 12.2838 19.0211 11.7162 18.629 11.4838L6.90588 4.53682Z"
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
