import { GaxiosResponse } from "gaxios";
import { youtube_v3 } from "googleapis";
import useSWRInfinite from "swr/infinite";
import { defaultFetcher } from "../../../lib/defaultFetcher";

type WatchLaterProps = {
  watchLaterPlaylist: GaxiosResponse<youtube_v3.Schema$VideoListResponse>["data"];
};

export const useYoutubeWatchLaterVideos = () => {
  const { data, size, setSize, error } =
    useSWRInfinite<WatchLaterProps>(
      (pageIndex, previousPageData) => {
        // first page
        if (pageIndex === 0) {
          return `/api/youtube/watch-later`;
        }
        // hit the end
        if (
          !previousPageData?.watchLaterPlaylist
            ?.nextPageToken
        ) {
          return null;
        }

        return `/api/youtube/watch-later?cursor=${encodeURIComponent(
          previousPageData?.watchLaterPlaylist
            ?.nextPageToken,
        )}`;
      },
      defaultFetcher,
    );

  return { data, size, setSize, error };
};
