import { GaxiosResponse } from "gaxios";
import { youtube_v3 } from "googleapis";
import useSWRInfinite from "swr/infinite";

import { defaultFetcher } from "../../../lib/defaultFetcher";

export type youtubeLikedVideosType =
  GaxiosResponse<youtube_v3.Schema$VideoListResponse>["data"];

type YoutubeVideo = {
  youtube: youtubeLikedVideosType;
};

export const useYoutubeLikeVideos = () => {
  const { data, size, setSize, error } =
    useSWRInfinite<YoutubeVideo>(
      (pageIndex, previousPageData) => {
        // first page
        if (pageIndex === 0) {
          return `/api/youtube/likes`;
        }
        // hit the end
        if (!previousPageData?.youtube?.nextPageToken) {
          return null;
        }

        return `/api/youtube/likes?cursor=${encodeURIComponent(
          previousPageData?.youtube?.nextPageToken,
        )}`;
      },
      defaultFetcher,
    );

  return { data, size, setSize, error };
};
