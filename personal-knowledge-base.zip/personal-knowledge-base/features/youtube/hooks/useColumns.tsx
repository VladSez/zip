import { useState } from "react";

export type ColumnsType = "one" | "two";

export enum COLUMNS {
  ONE = "one",
  TWO = "two",
}

export const useColumns = () => {
  const [column, setColumn] = useState<ColumnsType>(
    COLUMNS.ONE,
  );

  return { column, setColumn };
};
