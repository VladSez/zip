export enum HackerNewsFilters {
  topstories = "topstories",
  newstories = "newstories",
  beststories = "beststories",
  askstories = "askstories",
  showstories = "showstories",
  jobstories = "jobstories",
}

export type HNFilters = keyof typeof HackerNewsFilters;

export interface HackerNewsDataWithIndex {
  id: number;
  index: number;
}

export interface HackerNewsItemResponse {
  by: string;
  descendants: number;
  id: number;
  kids?: number[];
  score: number;
  time: number;
  title: string;
  type: string;
  url?: string;
  text?: string;
}

export interface HackerNewsItemProps {
  id?: number;
}
