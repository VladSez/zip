import { useRouter } from "next/router";
import useSWR from "swr";
import { defaultFetcher } from "../../../lib/defaultFetcher";

export const useHackerNews = () => {
  const router = useRouter();

  // DOCS: https://github.com/HackerNews/API
  const { data, error } = useSWR<Array<number>>(
    () =>
      router.query.filter
        ? `https://hacker-news.firebaseio.com/v0/${router.query.filter}.json?print=pretty`
        : null,
    defaultFetcher,
  );

  return { data, error };
};
