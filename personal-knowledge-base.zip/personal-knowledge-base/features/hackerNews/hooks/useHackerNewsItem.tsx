import useSWRImmutable from "swr/immutable";

import { defaultFetcher } from "../../../lib/defaultFetcher";
import { HackerNewsItemResponse } from "../types";

export const useHackerNewsItem = (
  id: number | undefined,
) => {
  const { data } = useSWRImmutable<HackerNewsItemResponse>(
    id
      ? `https://hacker-news.firebaseio.com/v0/item/${id}.json`
      : null,
    defaultFetcher,
    {
      suspense: true,
      onError: (error, key) => {
        console.error({ error, key });
      },
      revalidateOnMount: false,
    },
  );

  const { host } = data?.url
    ? new URL(data.url)
    : { host: "#" };

  const formattedHost = host.replace(/^www\./, "");

  return { data, host: formattedHost };
};
