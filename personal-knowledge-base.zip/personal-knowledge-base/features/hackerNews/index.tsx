import { useRouter } from "next/router";
import { Suspense, useEffect } from "react";
import { ErrorBoundary } from "react-error-boundary";

import { FeedContainer } from "../../components/FeedContainer";
import { LoaderWithText } from "../../components/Loader";
import { Pagination } from "../../components/Pagination";
import { HackerNewsItem } from "./components/HackerNewsItem";
import { Filters } from "./components/Filters";

import { useHackerNews } from "./hooks/useHackerNews";
import { HackerNewsFilters } from "./types";
import { paginateData } from "./utils";
import { DEFAULT_PAGE } from "../github/constants";

const ITEMS_PER_PAGE = 15;

const addIndex = (id: number, index: number) => ({
  id,
  index: index + 1,
});

const isServer = typeof window === "undefined";

export const HackerNewsList = () => {
  const router = useRouter();
  const { data, error } = useHackerNews();

  const page =
    Number(router.query?.page) || Number(DEFAULT_PAGE);

  useEffect(() => {
    if (!router.isReady) {
      return;
    }

    if (!router.query.filter) {
      router.replace({
        query: {
          ...router.query,
          filter: HackerNewsFilters.topstories, // default filter: ;
          page: 1,
        },
      });
    }
  }, [router]);

  if (error) {
    return (
      <pre className="mt-10 h-screen whitespace-pre-wrap">
        {JSON.stringify({ error }, null, 2)}
      </pre>
    );
  }

  if (!data) {
    return (
      <div className="mt-24 flex h-[101vh] flex-col justify-start">
        <LoaderWithText />
      </div>
    );
  }

  const dataWithIndex = data?.map(addIndex);

  const maxPage = Math.ceil(
    dataWithIndex?.length / ITEMS_PER_PAGE,
  );

  const paginatedData = paginateData(
    dataWithIndex,
    ITEMS_PER_PAGE,
  );

  // show error if exceeds max page
  if (page > maxPage) {
    return (
      <FeedContainer>
        <Filters />
        <p className="mx-10 my-3 sm:mx-0">
          Page does not exist
        </p>
      </FeedContainer>
    );
  }

  const currentPageData = paginatedData?.[page];

  const startIndexOfCurrentPage =
    currentPageData?.[0]?.index;

  if (isServer) {
    return null;
  }
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <Suspense
        fallback={
          <div className="mt-24 flex h-[101vh] flex-col justify-start">
            <LoaderWithText />
          </div>
        }
      >
        <FeedContainer>
          <Filters />

          <section className="my-4 mx-7 mt-6 sm:mx-0">
            <ol
              start={startIndexOfCurrentPage}
              className="mt-3 list-inside"
            >
              {currentPageData?.map((item) => {
                if (!item) {
                  return null;
                }

                return (
                  <HackerNewsItem
                    id={item?.id}
                    key={item?.id}
                  />
                );
              })}
            </ol>
          </section>
          <div className="my-6 mb-10 flex justify-center">
            <Pagination
              shouldScrollToTop
              maxPage={maxPage}
            />
          </div>
        </FeedContainer>
      </Suspense>
    </ErrorBoundary>
  );
};

interface ErrorFallbackProps {
  error: Error;
  resetErrorBoundary: () => void;
}

function ErrorFallback({
  error,
  resetErrorBoundary,
}: ErrorFallbackProps) {
  return (
    <div role="alert" className="my-10">
      <p className="text-red-700">Something went wrong:</p>
      <pre>{error.message}</pre>
      <button onClick={resetErrorBoundary}>
        Try again
      </button>
    </div>
  );
}
