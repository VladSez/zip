import { ButtonGroup } from "../../../components/ButtonGroup";
import { FilterByButton } from "../../github/components/common/FilterByButton";
import { HackerNewsFilters } from "../types";

export const Filters = () => {
  return (
    <ButtonGroup
      ariaLabel="filters for hacker news"
      className="flex justify-center"
    >
      <FilterByButton
        filterBy={HackerNewsFilters.topstories}
        queryKey="filter"
      >
        Top
      </FilterByButton>

      <FilterByButton
        filterBy={HackerNewsFilters.beststories}
        queryKey="filter"
      >
        Best
      </FilterByButton>

      <FilterByButton
        filterBy={HackerNewsFilters.newstories}
        queryKey="filter"
      >
        New
      </FilterByButton>
      <FilterByButton
        filterBy={HackerNewsFilters.askstories}
        queryKey="filter"
      >
        Ask
      </FilterByButton>
      <FilterByButton
        filterBy={HackerNewsFilters.showstories}
        queryKey="filter"
      >
        Show
      </FilterByButton>
      <FilterByButton
        filterBy={HackerNewsFilters.jobstories}
        queryKey="filter"
      >
        Jobs
      </FilterByButton>
    </ButtonGroup>
  );
};
