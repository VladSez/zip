import dayjs from "dayjs";
import { Tooltip } from "../../../components/Tooltip";

import { useHackerNewsItem } from "../hooks/useHackerNewsItem";
import { HackerNewsItemProps } from "../types";

const isServer = typeof window === "undefined";

export const HackerNewsItem = ({
  id,
}: HackerNewsItemProps) => {
  const { data, host } = useHackerNewsItem(id);

  if (isServer || !id || !data) {
    return null;
  }
  return (
    <li
      key={data.id}
      className="my-2 list-decimal text-left"
    >
      <a
        target="_blank"
        rel="noreferrer"
        href={
          data?.url
            ? data.url
            : `https://news.ycombinator.com/item?id=${data.id}`
        }
      >
        {data.title}
      </a>
      {data?.url ? (
        <a
          className="text-xs text-gray-500"
          target="_blank"
          rel="noreferrer"
          href={
            data?.url
              ? `https://news.ycombinator.com/from?site=${host}`
              : ``
          }
        >
          {" "}
          ({host})
        </a>
      ) : null}
      <br />
      <footer>
        <span className="text-xs text-gray-500">
          {data?.score || 0} points by
        </span>{" "}
        <a
          className="text-xs text-gray-500"
          target="_blank"
          rel="noreferrer"
          href={`https://news.ycombinator.com/user?id=${data.by}`}
        >
          {data?.by}
        </a>
        <span className="text-xs text-gray-400">
          {" | "}
        </span>
        <Time time={data?.time} />
        <span className="text-xs text-gray-400">
          {" | "}
        </span>
        <a
          className="text-xs text-gray-500"
          target="_blank"
          rel="noreferrer"
          href={`https://news.ycombinator.com/item?id=${data.id}`}
        >
          {data?.descendants || 0} comments
        </a>
      </footer>
    </li>
  );
};

const Time = ({ time }: { time: number | undefined }) => {
  if (!time) {
    return null;
  }

  const dateFromUnixTimestamp = time
    ? dayjs.unix(time).format("DD MMMM YYYY, HH:mm:ss")
    : "";

  return (
    <Tooltip content={dateFromUnixTimestamp}>
      <time
        dateTime={dateFromUnixTimestamp}
        className="cursor-pointer text-xs text-gray-500"
      >
        {dayjs.unix(time).fromNow()}
      </time>
    </Tooltip>
  );
};
