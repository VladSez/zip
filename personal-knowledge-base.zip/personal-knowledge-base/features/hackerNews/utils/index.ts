import { isNonEmptyArray } from "../../../utils/isNotEmptyArray";
import { HackerNewsDataWithIndex } from "../types";

type PaginatedHackerNewsDataWithIndex = {
  [key: number]: Array<HackerNewsDataWithIndex>;
};

export function paginateData(
  items: Array<HackerNewsDataWithIndex>,
  itemsPerPage: number,
): PaginatedHackerNewsDataWithIndex {
  if (isNonEmptyArray(items)) {
    let count = 1;
    const result: PaginatedHackerNewsDataWithIndex = {};

    for (let i = 0; i < items.length; i += itemsPerPage) {
      result[count] = items.slice(i, i + itemsPerPage);
      count++;
    }

    return result;
  }
  // TODO: not sure if this is needed, because we need to return `{}`
  return [];
}
