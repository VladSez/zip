// https://github.com/sindresorhus/ts-extras/blob/main/source/is-empty.ts

// https://www.typescriptlang.org/docs/handbook/2/conditional-types.html
// https://twitter.com/mpocock1/status/1504802045794078723

export function isNonEmptyArray<T>(
  // if Arg is not an Array, show error
  value: T extends unknown[]
    ? T
    : "You can only pass an array to this function",
) {
  return Array.isArray(value) && value.length > 0;
}
