module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./features/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      boxShadow: {
        blue: "0 1px 5px 0 rgb(107 178 246)",
      },
      gridTemplateColumns: {
        custom: "1fr min(58ch, calc(100% - 64px)) 1fr", // https://www.joshwcomeau.com/css/full-bleed/
      },
      animation: {
        "spin-fast": "spin 0.5s linear infinite",
        "pulse-fast":
          "pulse 1s cubic-bezier(0.4, 0, 0.6, 1) infinite",
      },
    },
  },
  plugins: [],
};
