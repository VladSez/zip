interface ScreenReaderProps {
  children: React.ReactNode;
}

export const ScreenReader = ({
  children,
}: ScreenReaderProps) => {
  return <span className="sr-only">{children}</span>;
};
