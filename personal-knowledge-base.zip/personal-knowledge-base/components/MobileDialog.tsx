import { Dialog, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { AddLabelButton } from "../features/labels/components/AddLabelButton";
import { ThreeDots } from "../features/labels/components/Label";
import { FilterByLabelForm } from "../features/filterByLabel/FilterByLabelForm";

interface MobileDialogProps {
  isOpen: boolean;
  closeModal: () => void;
  totalCountOfItems?: number;
  isLagging?: boolean;
}

export const MobileDialog = ({
  isOpen,
  closeModal,
  isLagging,
  totalCountOfItems,
}: MobileDialogProps) => {
  return (
    <>
      <Transition appear show={isOpen} as={Fragment}>
        <Dialog
          as="div"
          className="fixed inset-0 z-10 overflow-y-auto"
          onClose={closeModal}
        >
          <div className="flex min-h-screen items-end justify-center text-center sm:items-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <Dialog.Overlay className="fixed inset-0 bg-gray-200 bg-opacity-80" />
            </Transition.Child>

            {/* This element is to trick the browser into centering the modal contents. */}
            <span
              className="inline-block h-screen align-middle"
              aria-hidden="true"
            >
              &#8203;
            </span>
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <div className="w-full max-w-md transform overflow-hidden rounded-t-3xl bg-white p-6 text-left align-middle transition-all sm:rounded-3xl">
                <div className="flex items-center">
                  <Dialog.Title
                    as="h3"
                    className="mx-2 text-lg font-medium leading-6 text-gray-900"
                  >
                    Filter by label:
                  </Dialog.Title>
                  <AddLabelButton />
                </div>
                <div className="my-5 mb-12 h-60 overflow-auto rounded-md border border-gray-100 p-2">
                  <FilterByLabelForm />
                </div>
              </div>
            </Transition.Child>
          </div>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 scale-95"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <button
              type="button"
              className="fixed left-2/4 bottom-4 h-10 w-[400px] max-w-[90%] -translate-x-1/2 items-center justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-medium text-blue-900 shadow-blue transition-all hover:bg-blue-200 disabled:cursor-not-allowed disabled:bg-blue-100 sm:top-[72.5%] sm:-translate-x-1/2 sm:-translate-y-1/2 sm:shadow-none"
              onClick={closeModal}
              disabled={isLagging}
            >
              {isLagging ? (
                <ThreeDots isLightColor={true} />
              ) : !totalCountOfItems ? (
                <div>Close</div>
              ) : (
                <div>
                  Found {totalCountOfItems || 0} items
                </div>
              )}
            </button>
          </Transition.Child>
        </Dialog>
      </Transition>
    </>
  );
};
