interface HeaderProps {
  children: React.ReactNode;
}

export const Header = ({ children }: HeaderProps) => {
  return (
    <h1 className="m-2 font-bold text-gray-800">
      {children}
    </h1>
  );
};
