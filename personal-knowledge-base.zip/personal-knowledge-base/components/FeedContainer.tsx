interface FeedContainerProps {
  children: React.ReactNode;
}

export const FeedContainer = ({
  children,
}: FeedContainerProps) => {
  return (
    <div className="mt-2 min-h-[101vh] md:m-4 lg:mx-0">
      {children}
    </div>
  );
};
