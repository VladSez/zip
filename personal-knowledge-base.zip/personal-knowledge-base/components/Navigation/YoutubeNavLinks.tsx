import clsx from "clsx";
import Link from "next/link";
import { useRouter } from "next/router";
import { objectEntries } from "ts-extras";

import { Collapsible } from "../Collapsible";
import { YoutubeIcon } from "../icons/NavigationIcons";

import { NavigationProps } from "./types";

const YouTubeCategories = {
  Likes: `/youtube/likes`,
  "Watch Later": `/youtube/watch-later`,
  Playlists: `/youtube/playlists`,
} as const;

export const YoutubeNavLinks = ({
  closePopoverPanel,
}: NavigationProps) => {
  const router = useRouter();

  const isYoutubeCategoryActive =
    router.pathname === YouTubeCategories.Likes ||
    router.pathname === YouTubeCategories["Watch Later"] ||
    router.pathname === YouTubeCategories.Playlists;

  return (
    <Collapsible
      defaultOpen={isYoutubeCategoryActive}
      trigger={() => {
        return (
          <span
            className={clsx(
              "flex w-full cursor-pointer items-center text-gray-600 transition-all hover:text-gray-900",
              {
                "font-medium !text-blue-700":
                  isYoutubeCategoryActive,
              },
            )}
          >
            <YoutubeIcon />
            Youtube
          </span>
        );
      }}
      content={() => {
        return (
          <ul role="list" className="mt-2 ml-14 space-y-2">
            {objectEntries(YouTubeCategories).map(
              ([key, value]) => {
                return (
                  <SubLinkYoutube
                    key={value}
                    path={value}
                    title={key}
                    closePopoverPanel={closePopoverPanel}
                  />
                );
              },
            )}
          </ul>
        );
      }}
    />
  );
};

interface SubLinkYoutubeProps {
  path: string;
  title: string;
  closePopoverPanel?: () => void;
}
const SubLinkYoutube = ({
  closePopoverPanel,
  path,
  title,
}: SubLinkYoutubeProps) => {
  const router = useRouter();

  return (
    <li key={path}>
      <Link href={path}>
        <a
          onClick={closePopoverPanel}
          className={clsx(
            "flex w-full cursor-pointer items-center text-sm text-gray-600",
            {
              "font-medium !text-blue-700":
                router.pathname === path,
            },
          )}
        >
          {title}
        </a>
      </Link>
    </li>
  );
};
