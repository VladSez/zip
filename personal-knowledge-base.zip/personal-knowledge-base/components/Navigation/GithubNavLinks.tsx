import clsx from "clsx";
import Link from "next/link";
import { useRouter } from "next/router";
import { objectEntries } from "ts-extras";

import { GHTabs } from "../../features/github";
import { useGithubNotificationsManager } from "../../features/github/components/Notifications/hooks/useGithubNotificationsManager";
import { NotificationCount } from "../../features/github/components/Notifications/NotificationCount";
import { Collapsible } from "../Collapsible";
import { GithubIcon } from "../icons/NavigationIcons";

import { NavigationProps } from "./types";

const GithubCategories = {
  [GHTabs.Feed]: "?tab=Feed&page=1",
  [GHTabs.Notifications]:
    "?tab=Notifications&filterBy=All&page=1",
  [GHTabs["Starred Repos"]]:
    "?tab=Starred+Repos&direction=desc&sort=created&page=1",
} as const;

export const GithubNavLinks = ({
  closePopoverPanel,
}: NavigationProps) => {
  const router = useRouter();
  const { hasNotifications } =
    useGithubNotificationsManager();

  return (
    <Collapsible
      defaultOpen={router.pathname === "/github"}
      trigger={({ isOpen }) => {
        return (
          <span
            className={clsx(
              "relative flex w-full cursor-pointer items-center text-gray-600 transition-all hover:text-gray-900",
              {
                "font-medium !text-blue-700":
                  router.pathname === "/github",
              },
            )}
          >
            <GithubIcon />
            Github
            {hasNotifications && !isOpen ? (
              <NotificationCount
                onClick={closePopoverPanel}
                className="relative bottom-2 ml-1"
              />
            ) : null}
          </span>
        );
      }}
      content={() => {
        return (
          <ul role="list" className="mt-2 ml-14 space-y-2">
            {objectEntries(GithubCategories).map(
              ([title, link]) => {
                const isActiveTab =
                  router.query.tab === title;
                const isNotificationsTab =
                  title === GHTabs["Notifications"];

                if (isNotificationsTab) {
                  return (
                    <li key={title} className="flex">
                      <Link href={`/github${link}`}>
                        <a
                          onClick={closePopoverPanel}
                          className={clsx(
                            "flex cursor-pointer items-center text-sm text-gray-600",
                            {
                              "font-medium !text-blue-700":
                                isActiveTab,
                            },
                          )}
                        >
                          {title}
                        </a>
                      </Link>
                      {hasNotifications ? (
                        <NotificationCount
                          onClick={closePopoverPanel}
                          className="relative bottom-2 ml-1"
                        />
                      ) : null}
                    </li>
                  );
                }
                return (
                  <li key={title}>
                    <Link href={`/github${link}`}>
                      <a
                        onClick={closePopoverPanel}
                        className={clsx(
                          "flex w-full cursor-pointer items-center text-sm text-gray-600",
                          {
                            "font-medium !text-blue-700":
                              isActiveTab,
                          },
                        )}
                      >
                        {title}
                      </a>
                    </Link>
                  </li>
                );
              },
            )}
          </ul>
        );
      }}
    />
  );
};
