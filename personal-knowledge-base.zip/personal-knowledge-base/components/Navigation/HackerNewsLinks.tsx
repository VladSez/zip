import clsx from "clsx";
import Link from "next/link";
import { useRouter } from "next/router";
import { mutate } from "swr";

import { defaultFetcher } from "../../lib/defaultFetcher";
import { HackerNewsIcon } from "../icons/NavigationIcons";

import { NavigationProps } from "./types";

export const HackerNewsLinks = ({
  closePopoverPanel,
}: NavigationProps) => {
  const router = useRouter();

  return (
    <Link href="/hackernews?filter=topstories&page=1">
      <a
        onMouseEnter={() => {
          mutate(
            `https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty`,
            defaultFetcher(
              `https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty`,
            ),
          );
        }}
        onClick={closePopoverPanel}
        className={clsx(
          "ml-6 flex w-full cursor-pointer items-center text-gray-600 transition-all hover:text-gray-900",
          {
            "font-medium !text-blue-700":
              router.pathname === "/hackernews",
          },
        )}
      >
        <HackerNewsIcon />
        Hacker News
      </a>
    </Link>
  );
};
