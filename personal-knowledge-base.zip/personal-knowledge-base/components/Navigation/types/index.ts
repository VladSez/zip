export type NavigationProps = {
  /**
   * Propagate onClick event from Popover.Panel to child components.
   */
  closePopoverPanel?: () => void;
};
