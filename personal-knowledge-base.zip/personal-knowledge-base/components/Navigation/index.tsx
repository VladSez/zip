import { ActiveLink } from ".././ActiveLink";
import { LabelIcon } from ".././icons/NavigationIcons";

import { GithubNavLinks } from "./GithubNavLinks";
import { HackerNewsLinks } from "./HackerNewsLinks";
import { TwitterNavLinks } from "./TwitterNavLinks";
import { YoutubeNavLinks } from "./YoutubeNavLinks";

import { NavigationProps } from "./types";

export const Navigation = ({
  closePopoverPanel,
}: NavigationProps) => {
  return (
    <>
      <h5 className="mb-4 text-sm font-semibold uppercase tracking-wide text-gray-900 ">
        Navigation:
      </h5>
      <nav>
        <ul>
          <li className="my-3">
            <TwitterNavLinks
              closePopoverPanel={closePopoverPanel}
            />
          </li>

          <li className="relative my-3">
            <GithubNavLinks
              closePopoverPanel={closePopoverPanel}
            />
          </li>

          <li className="my-3">
            <YoutubeNavLinks
              closePopoverPanel={closePopoverPanel}
            />
          </li>

          <li className="my-3">
            <ActiveLink
              href="/labels"
              activeClassName="font-semibold !text-blue-700"
              onClick={
                closePopoverPanel
                  ? closePopoverPanel
                  : undefined
              }
            >
              <a className="ml-6 flex w-full cursor-pointer items-center text-gray-600 transition-all hover:text-gray-900">
                <LabelIcon />
                Labels
              </a>
            </ActiveLink>
          </li>

          <li className="my-3">
            <HackerNewsLinks
              closePopoverPanel={closePopoverPanel}
            />
          </li>
        </ul>
      </nav>
    </>
  );
};
