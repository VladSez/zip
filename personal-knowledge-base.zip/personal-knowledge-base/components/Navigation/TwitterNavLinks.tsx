import clsx from "clsx";
import Link from "next/link";
import { useRouter } from "next/router";
import { mutate } from "swr";
import { objectKeys } from "ts-extras";

import { TwitterTabs } from "../../pages/twitter";
import { Collapsible } from "../Collapsible";
import { TwitterIcon } from "../icons/NavigationIcons";
import { defaultFetcher } from "../../lib/defaultFetcher";

import { NavigationProps } from "./types";

export const TwitterNavLinks = ({
  closePopoverPanel,
}: NavigationProps) => {
  const router = useRouter();

  return (
    <Collapsible
      defaultOpen={router.pathname === "/twitter"}
      trigger={() => {
        return (
          <span
            className={clsx(
              "flex w-full cursor-pointer items-center text-gray-600 transition-all hover:text-gray-900",
              {
                "font-medium !text-blue-700":
                  router.pathname === "/twitter",
              },
            )}
          >
            <TwitterIcon />
            Twitter
          </span>
        );
      }}
      content={() => {
        return (
          <ul role="list" className="mt-2 ml-14 space-y-2">
            {objectKeys(TwitterTabs).map((category) => {
              return (
                <SubLinkTwitter
                  key={category}
                  category={category}
                  closePopoverPanel={closePopoverPanel}
                />
              );
            })}
          </ul>
        );
      }}
    />
  );
};

interface SubLinkTwitterProps {
  category: string;
  closePopoverPanel?: () => void;
}

const SubLinkTwitter = ({
  closePopoverPanel,
  category,
}: SubLinkTwitterProps) => {
  const router = useRouter();

  return (
    <li key={category}>
      <Link href={`/twitter?tab=${category}`}>
        <a
          onMouseEnter={() => {
            // PREFETCHING DATA
            // TODO: investigate further
            mutate(
              `/api/twitter/${category.toLowerCase()}?query=${encodeURIComponent(
                "",
              )}`,
              defaultFetcher(
                `/api/twitter/${category.toLowerCase()}?query=${encodeURIComponent(
                  "",
                )}`,
              ),
            );
          }}
          onClick={closePopoverPanel}
          className={clsx(
            "flex w-full cursor-pointer items-center text-sm text-gray-600",
            {
              "font-medium !text-blue-700":
                router.query.tab === category,
            },
          )}
        >
          {category}
        </a>
      </Link>
    </li>
  );
};
