// import { FilterByLabelListContainer } from "../features/filterByLabel";

import { Navigation } from "./Navigation";

export const DesktopNav = () => {
  return (
    <aside className="sticky top-32 ml-4 hidden md:flex md:justify-center">
      <section className="ml-3 w-[250px]">
        <Navigation />
        {/* <div className="mt-8">
          <FilterByLabelListContainer />
        </div> */}
      </section>
    </aside>
  );
};
