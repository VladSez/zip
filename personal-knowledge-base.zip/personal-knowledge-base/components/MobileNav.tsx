import { Popover, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { ScreenReader } from "./ScreenReader";
import Link from "next/link";
import { Navigation } from "./Navigation";

export const MobileNav = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex h-14 items-center justify-between border-b border-gray-200 bg-white bg-opacity-[.55] backdrop-blur-sm backdrop-filter md:hidden">
      <Link href="/twitter" passHref>
        <a className="ml-3 flex items-center">
          <Logo />
          Knowledge base
        </a>
      </Link>
      <div className="mr-3">
        <PopoverButton />
      </div>
    </header>
  );
};

const PopoverButton = () => {
  return (
    <Popover>
      <Popover.Button
        className={`group inline-flex items-center rounded-md py-2 text-base font-medium text-white hover:text-opacity-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-black focus-visible:ring-opacity-75`}
      >
        <MenuIcon />
        <ScreenReader>Menu navigation</ScreenReader>
      </Popover.Button>
      {/* 
        Transition 'enter' phase is not working,
        that's most probably related to the Collapsible component from radix-ui
      */}
      <Transition
        as={Fragment}
        enter="transition ease-out duration-200"
        enterFrom="opacity-0 translate-y-1"
        enterTo="opacity-100 translate-y-0"
        leave="transition ease-in duration-150"
        leaveFrom="opacity-100 translate-y-0"
        leaveTo="opacity-0 translate-y-1"
      >
        <div className="relative">
          <Popover.Panel className="absolute -right-3 z-50 mt-2 w-screen">
            {({ close }) => (
              <div className="rounded-lg shadow-lg">
                <div className="grid bg-white p-7 lg:grid-cols-2">
                  <Navigation closePopoverPanel={close} />
                </div>
              </div>
            )}
          </Popover.Panel>
        </div>
      </Transition>
    </Popover>
  );
};

const Logo = () => {
  return (
    <svg
      viewBox="0 0 128 128"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="mr-2 h-7 w-7"
    >
      <circle
        cx="64"
        cy="64"
        r="64"
        fill="url(#paint0_linear_201:5)"
      />
      <defs>
        <linearGradient
          id="paint0_linear_201:5"
          x1="64"
          y1="0"
          x2="64"
          y2="128"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#8F00FF" />
          <stop offset="1" stopColor="#FF00E5" />
        </linearGradient>
      </defs>
    </svg>
  );
};

const MenuIcon = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="h-6 w-6 fill-current text-gray-900"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M4 6h16M4 12h16M4 18h16"
      />
    </svg>
  );
};
