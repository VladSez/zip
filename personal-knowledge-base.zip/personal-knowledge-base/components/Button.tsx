import classNames from "classnames";

interface ButtonProps
  extends React.ComponentPropsWithoutRef<"button"> {
  onClick?: React.Dispatch<React.SetStateAction<any>>;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  type?: "button" | "reset" | "submit";
}

export const Button = ({
  onClick,
  children,
  className,
  disabled,
  type = "button",
  ...rest
}: ButtonProps) => {
  return (
    <>
      <button
        onClick={onClick}
        className={classNames(
          "m-1 inline-flex items-center rounded-md border border-gray-300 bg-white px-2 py-1 text-sm font-medium text-gray-700 shadow-sm transition duration-200 ease-in-out hover:bg-gray-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-black",
          className,
          { "cursor-not-allowed opacity-50": disabled },
        )}
        disabled={disabled}
        type={type}
        {...rest}
      >
        {children}
      </button>
    </>
  );
};
