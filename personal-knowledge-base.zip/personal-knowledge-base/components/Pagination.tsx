import { ButtonGroup } from "./ButtonGroup";
import { Button } from "./Button";
import { useRouter } from "next/dist/client/router";

import { DEFAULT_PAGE } from "../features/github/constants";

interface PaginationProps {
  canFetchNextPage?: boolean;
  shouldScrollToTop?: boolean;
  maxPage?: number;
}
const scrollToTop = () => {
  if (typeof window !== undefined) {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }
};

export const Pagination = ({
  canFetchNextPage = true,
  shouldScrollToTop = false,
  maxPage,
}: PaginationProps) => {
  const router = useRouter();

  const page = router.query?.page
    ? Number(router.query.page)
    : Number(DEFAULT_PAGE);

  return (
    <ButtonGroup
      className="text-center"
      ariaLabel="pagination buttons"
    >
      <Button
        onClick={() => {
          router.push({
            query: {
              ...router.query,
              page: Math.max(1, page - 1), // do not go below 1
            },
          });

          if (shouldScrollToTop && page !== 1) {
            scrollToTop();
          }
        }}
        aria-label={`Go to previous page`}
        disabled={page === 1}
      >
        Previous
      </Button>
      Page:{page}
      <Button
        onClick={() => {
          if (maxPage) {
            router.push({
              query: {
                ...router.query,
                page: Math.min(maxPage, page + 1),
              },
            });
          } else {
            router.push({
              query: {
                ...router.query,
                page: page + 1,
              },
            });
          }
          if (shouldScrollToTop) {
            scrollToTop();
          }
        }}
        disabled={!canFetchNextPage || page === maxPage}
        aria-label={`Go to next page`}
      >
        Next
      </Button>
    </ButtonGroup>
  );
};
