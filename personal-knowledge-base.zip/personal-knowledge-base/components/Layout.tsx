import { MobileNav } from "./MobileNav";
import Head from "next/head";
import { DesktopNav } from "./DesktopNav";

import {
  SkipNavLink,
  SkipNavContent,
} from "@reach/skip-nav";
import "@reach/skip-nav/styles.css";

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout = ({ children }: LayoutProps) => {
  return (
    <>
      <Head>
        <title>Knowledge base</title>
        <link rel="shortcut icon" href="/Ellipse.png" />
      </Head>
      <div className="mt-14 grid min-h-screen grid-cols-1 sm:grid-cols-custom md:mt-0 lg:gap-8">
        <div>
          <SkipNavLink />
          <DesktopNav />
        </div>
        <MobileNav />
        <main>
          <SkipNavContent>{children}</SkipNavContent>
        </main>
      </div>
    </>
  );
};
