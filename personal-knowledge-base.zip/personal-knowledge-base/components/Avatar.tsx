import clsx from "clsx";
import Image, { ImageProps } from "next/image";
import { useCallback, useState } from "react";

interface AvatarProps {
  alt: string;
  height: number;
  width: number;
  src: string | undefined;
}

export const Avatar = ({
  alt = "",
  src,
  width = 48,
  height = 48,
}: AvatarProps) => {
  if (!src) {
    return null;
  }
  return (
    <BlurImageAvatar
      alt={alt}
      height={height}
      width={width}
      src={src}
      className="rounded-full"
    />
  );
};

export const BlurImageAvatar = ({
  alt = "",
  height,
  width,
  src,
  className,
}: ImageProps) => {
  const [isLoading, setLoading] = useState(true);

  const onLoadingComplete = useCallback(
    () => setLoading(false),
    [],
  );

  return (
    <div
      className={clsx(
        "relative h-10 w-10",
        "rounded-full bg-slate-100 shadow",
        "transition duration-700 ease-in-out",
        "group-hover:opacity-75",
        isLoading ? "blur-sm" : "blur-0",
        className,
      )}
    >
      <Image
        layout="fill"
        alt={alt}
        src={src}
        height={height}
        width={width}
        className={className}
        onLoadingComplete={onLoadingComplete}
      />
    </div>
  );
};
