import { useRouter } from "next/dist/client/router";
import Link, { LinkProps } from "next/link";
import {
  Children,
  cloneElement,
  JSXElementConstructor,
  ReactElement,
} from "react";
import { useRouterQuery } from "../hooks/useRouterQuery";

interface ActiveLinkProps extends LinkProps {
  children: React.ReactNode;
  activeClassName?: string;
  onClick?: () => void;
}

// TODO: not sure if this component is still needed
// we have replace it with clsx :)
export const ActiveLink = ({
  children,
  activeClassName,
  onClick,
  ...props
}: ActiveLinkProps) => {
  const { pathname } = useRouter();
  const { prevPageParam } = useRouterQuery();

  const child = Children.only(children);

  // @ts-expect-error
  const childClassName = child.props.className || "";

  // pages/index.js will be matched via props.href
  // pages/about.js will be matched via props.href
  // pages/[slug].js will be matched via props.as

  // this is needed to highlight active link,
  // when url has query params(during filtering)

  const hrefHasQueryParam = prevPageParam
    ? props.href.toString().includes(prevPageParam)
    : false;

  const className: string =
    pathname === props.href ||
    pathname === props.as ||
    hrefHasQueryParam
      ? `${activeClassName} ${childClassName}`.trim()
      : childClassName;

  return (
    <Link {...props}>
      {cloneElement(
        child as ReactElement<
          any,
          string | JSXElementConstructor<any>
        >,
        {
          className,
          onClick,
        },
      )}
    </Link>
  );
};
