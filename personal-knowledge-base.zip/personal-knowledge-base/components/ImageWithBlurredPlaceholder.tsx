import clsx from "clsx";
import NextImage, { ImageProps } from "next/image";
import React, { useCallback, useState } from "react";

export const ImageWithBlurredPlaceholder = ({
  alt = "",
  height,
  width,
  src,
  layout,
  className,
  objectFit,
}: ImageProps) => {
  const [isLoading, setLoading] = useState(true);

  const onLoadingComplete = useCallback(
    () => setLoading(false),
    [],
  );

  // https://github.com/leerob/image-gallery-supabase-tailwind-nextjs/blob/main/pages/index.tsx#L43
  return (
    <div
      className={clsx(
        "flex w-fit overflow-hidden",
        className,
      )}
    >
      <NextImage
        layout={layout}
        objectFit={objectFit}
        alt={alt}
        src={src}
        height={height}
        width={width}
        className={clsx(
          "bg-slate-100 transition duration-700 ease-in-out",
          "group-hover:opacity-75",
          isLoading
            ? "scale-110 blur-2xl"
            : "scale-100 blur-0",
          className,
        )}
        onLoadingComplete={onLoadingComplete}
      />
    </div>
  );
};
