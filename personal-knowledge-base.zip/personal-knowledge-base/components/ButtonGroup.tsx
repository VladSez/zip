import classNames from "classnames";

interface ButtonGroupProps {
  children: React.ReactNode;
  ariaLabel: string;
  className?: string;
}

export const ButtonGroup = ({
  children,
  ariaLabel,
  className = "",
}: ButtonGroupProps) => {
  return (
    <div
      role="group"
      aria-label={ariaLabel}
      className={classNames(className)}
    >
      {children}
    </div>
  );
};
