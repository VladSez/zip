interface VideoProps {
  ratio: number;
  url: string;
  loop?: boolean;
  type?: "gif" | "video";
}

export const Video = ({
  ratio,
  url,
  loop = false,
  type = "video",
}: VideoProps) => {
  // video component example
  // https://github.com/vercel/swr-site/blob/master/components/video.js

  if (!url) {
    return <figcaption>No video</figcaption>;
  }

  // TODO: change to `figure` and `figcaption`?
  // https://developer.mozilla.org/en-US/docs/Web/HTML/Element/figure
  return (
    <div className="relative mt-3 mb-2">
      {type === "gif" ? (
        <div className="absolute top-2 right-2 z-10 rounded bg-gray-800 bg-opacity-70 px-1 py-0.5 text-center text-xs font-semibold uppercase text-white">
          gif
        </div>
      ) : null}
      <div
        style={{
          paddingBottom: ratio * 100 + "%", // keeps aspect ratio
        }}
      />
      <video
        className="absolute top-0 left-0 h-full w-full rounded-2xl"
        muted
        playsInline
        controls
        loop={loop}
        preload="auto"
      >
        {/* #t=0.001 is needed to show thumbnail on ios devices */}
        <source src={`${url}#t=0.001`} type="video/mp4" />
      </video>
    </div>
  );
};
