import * as TooltipPrimitive from "@radix-ui/react-tooltip";
import clsx from "clsx";

interface TooltipProps
  extends TooltipPrimitive.TooltipProps {
  content: React.ReactNode;
}

// DOCS: https://www.radix-ui.com/docs/primitives/components/tooltip
export function Tooltip({
  children,
  content,
  open,
  defaultOpen,
  onOpenChange,
  ...props
}: TooltipProps) {
  return (
    <TooltipPrimitive.Root
      open={open}
      defaultOpen={defaultOpen}
      onOpenChange={onOpenChange}
    >
      <TooltipPrimitive.Trigger asChild>
        {children}
      </TooltipPrimitive.Trigger>
      <TooltipPrimitive.Content
        side="top"
        align="center"
        sideOffset={4}
        className={clsx(
          "items-center rounded-md px-3 py-2",
          "bg-slate-800 text-slate-50 dark:bg-gray-200",
          "text-xs leading-none",
          "max-w-sm overflow-hidden break-words",
        )}
        {...props}
      >
        {content}
        <TooltipPrimitive.Arrow
          offset={5}
          width={11}
          height={4.5}
          className="-mt-0.5 fill-current text-slate-800 dark:text-gray-200"
        />
      </TooltipPrimitive.Content>
    </TooltipPrimitive.Root>
  );
}
