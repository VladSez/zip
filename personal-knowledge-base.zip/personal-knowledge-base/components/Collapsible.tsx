import { useCallback, useMemo, useState } from "react";
import clsx from "clsx";
import AnimateHeight from "react-animate-height";

// TODO: replace with https://reactjs.org/docs/hooks-reference.html#useid
import { useId } from "@reach/auto-id";

const DATA_STATE = {
  OPEN: "open",
  CLOSE: "close",
} as const;

type CallbackProps = {
  isOpen: boolean;
};

interface CollapsibleProps {
  trigger: ({ isOpen }: CallbackProps) => React.ReactNode;
  content: ({ isOpen }: CallbackProps) => React.ReactNode;
  defaultOpen?: boolean;
}

export const Collapsible = ({
  trigger,
  content,
  defaultOpen = false,
}: CollapsibleProps) => {
  const id = useId();
  const ariaControlsId = `collapse-panel-${id}`;

  const [isOpen, setIsOpen] = useState(defaultOpen);

  const dataState = useMemo(
    () => (isOpen ? DATA_STATE.OPEN : DATA_STATE.CLOSE),
    [isOpen],
  );

  const height = useMemo(
    () => (isOpen ? "auto" : 0),
    [isOpen],
  );

  const handleCollapse = useCallback(() => {
    setIsOpen(!isOpen);
  }, [isOpen]);

  return (
    <div data-state={dataState}>
      <button
        type="button"
        onClick={handleCollapse}
        aria-expanded={isOpen}
        aria-controls={ariaControlsId}
        data-state={dataState}
        className={clsx(
          "custom-collapse",
          "group flex w-full select-none items-center justify-between rounded-md text-left text-base font-medium",
          "bg-white text-gray-900 dark:bg-gray-800 dark:text-gray-100",
        )}
      >
        <ArrowRight />
        {trigger({
          isOpen,
        })}
      </button>

      {/* https://github.com/tailwindlabs/headlessui/issues/918#issuecomment-1085229040 */}

      {/* https://github.com/Stanko/react-animate-height
          this library animates the height of the content during open/close transitions
      */}
      <AnimateHeight
        id={ariaControlsId}
        duration={300}
        height={height}
      >
        {content({
          isOpen,
        })}
      </AnimateHeight>
    </div>
  );
};

const ArrowRight = () => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      className="collapse-arrow mr-2 h-5 w-5 text-gray-500 transition-transform"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth={2}
      aria-hidden="true"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M9 5l7 7-7 7"
      />
    </svg>
  );
};
