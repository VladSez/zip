import clsx from "clsx";

interface ExternalLinkProps {
  children: React.ReactNode;
  url: string | undefined;
  className?: string;
}
export const ExternalLink = ({
  children,
  url,
  className,
}: ExternalLinkProps) => {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={clsx(
        "cursor-pointer text-left text-sm font-bold text-gray-800 transition duration-200 ease-in-out hover:underline",
        className,
      )}
    >
      {children}
    </a>
  );
};
